package com.troy.browser.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.troy.browser.TroyApp
import com.troy.browser.data.HistoryEntity
import com.troy.browser.databinding.ActivityListBinding
import com.troy.browser.util.Formatters
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class HistoryActivity : AppCompatActivity() {
    private lateinit var appliedTheme: String
    private lateinit var b: ActivityListBinding
    private val dao get() = (application as TroyApp).db.history()
    private var query = ""

    private val adapter = EntryAdapter(
        onClick = { r -> r.url?.let { openInBrowser(it) } },
        onAction = { r -> (r.tag as? HistoryEntity)?.let { lifecycleScope.launch { dao.delete(it.id); reload() } } },
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        appliedTheme = ThemeManager.apply(this)
        super.onCreate(savedInstanceState)
        b = ActivityListBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.title.text = "Histórico"
        b.empty.text = "Nenhum site visitado"
        b.list.layoutManager = LinearLayoutManager(this)
        b.list.adapter = adapter
        b.btnBack.setOnClickListener { finish() }
        b.btnClearAll.setOnClickListener {
            UiUtil.confirm(this, "Limpar histórico", "Remover todo o histórico de navegação?", "Limpar") { lifecycleScope.launch { dao.clear(); reload() } }
        }
        b.searchInput.addTextChangedListener { query = it?.toString().orEmpty().trim(); lifecycleScope.launch { reload() } }
        lifecycleScope.launch { dao.observe().collectLatest { reload() } }
    }

    override fun onResume() {
        super.onResume()
        if (ThemeManager.changed(this, appliedTheme)) recreate()
    }

    private suspend fun reload() {
        val list = if (query.isEmpty()) dao.observe().let { it.first() } else dao.search(query)
        adapter.submit(list.map { EntryRow(it.title.ifBlank { it.url }, "${Formatters.date(it.visitedAt)} · ${it.url}", it.url, it) })
        b.empty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun openInBrowser(url: String) {
        startActivity(Intent(this, MainActivity::class.java).setAction(Intent.ACTION_VIEW).setData(Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
        finish()
    }
}
