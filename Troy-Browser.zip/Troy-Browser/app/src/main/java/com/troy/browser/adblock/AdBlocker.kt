package com.troy.browser.adblock

import android.content.Context
import android.webkit.WebResourceResponse
import com.troy.browser.data.AllowedSiteEntity
import com.troy.browser.data.AppDatabase
import com.troy.browser.settings.Prefs
import com.troy.browser.util.Net
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.ByteArrayInputStream
import java.io.File
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Bloqueio por domínio em duas camadas (anúncios e rastreadores), com exceções por site.
 *
 * Regras de segurança, para nunca atrapalhar vídeos:
 *  - nunca bloqueia o documento principal;
 *  - nunca bloqueia URLs de mídia (mp4, webm, m3u8, mpd, segmentos, áudio, legendas, chaves);
 *  - nunca bloqueia requisições que pedem vídeo/áudio;
 *  - nunca bloqueia recursos do próprio domínio da página (primeira parte);
 *  - não aplica nenhum filtro cosmético (não esconde nem remove elementos da página).
 */
class AdBlocker(private val context: Context, private val prefs: Prefs, private val db: AppDatabase) {
    @Volatile private var adHosts: Set<String> = emptySet()
    @Volatile private var trackerHosts: Set<String> = emptySet()
    @Volatile private var allowed: Set<String> = emptySet()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val session = AtomicLong(0)
    private val sessionAds = AtomicLong(0)
    private val sessionTrackers = AtomicLong(0)
    private val pendingTotal = AtomicInteger(0)

    /** Incrementa a cada mudança de configuração que exige recarregar a página. */
    val version = AtomicInteger(0)
    fun notifyChanged() { version.incrementAndGet() }

    val enabled: Boolean get() = prefs.adBlockEnabled
    val trackersEnabled: Boolean get() = prefs.blockTrackers
    val totalBlocked: Long get() = prefs.blockedCount + pendingTotal.get()
    val sessionBlocked: Long get() = session.get()
    val sessionAdsBlocked: Long get() = sessionAds.get()
    val sessionTrackersBlocked: Long get() = sessionTrackers.get()
    val adHostCount: Int get() = adHosts.size
    val trackerHostCount: Int get() = trackerHosts.size

    private val mediaPath = Regex("""\.(mp4|m4v|webm|mov|mkv|m3u8|mpd|m4s|ts|aac|mp3|m4a|ogg|opus|vtt|srt|key)(?=$|[?#])""", RegexOption.IGNORE_CASE)
    private val essential = Regex("""(/hls/|/dash/|/manifest|/playlist|/video|/media/|/player|/api/|/graphql|/stream)""", RegexOption.IGNORE_CASE)
    private val imagePath = Regex("""\.(gif|png|jpe?g|webp|avif|svg|ico)(?=$|[?#])""", RegexOption.IGNORE_CASE)
    private val scriptPath = Regex("""\.(js|mjs)(?=$|[?#])""", RegexOption.IGNORE_CASE)
    private val cssPath = Regex("""\.css(?=$|[?#])""", RegexOption.IGNORE_CASE)

    fun load() {
        scope.launch {
            val updated = File(context.filesDir, "filters.txt")
            val baseAds = readAsset("filters_ads.txt")
            adHosts = parse(baseAds) + if (updated.exists() && updated.length() > 0) parse(updated.readText()) else emptySet()
            trackerHosts = parse(readAsset("filters_trackers.txt"))
            allowed = db.allow().all().toSet()
        }
    }

    private fun readAsset(name: String): String = context.assets.open(name).bufferedReader().use { it.readText() }

    private fun parse(text: String): Set<String> = text.lineSequence()
        .map { it.substringBefore('#').trim() }
        .filter { it.isNotEmpty() }
        .mapNotNull { line ->
            val parts = line.split(Regex("\\s+"))
            val h = if (parts.size >= 2) parts[1] else parts[0]
            h.lowercase().takeIf { it.contains('.') && !it.contains('/') && it != "localhost" }
        }.toHashSet()

    /** Baixa uma lista de anúncios atualizada. Retorna a quantidade de domínios ou lança exceção. */
    suspend fun updateLists(): Int = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(LIST_URL).header("User-Agent", Net.USER_AGENT).build()
        Net.client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) error("HTTP ${r.code}")
            val text = r.body?.string().orEmpty()
            val parsed = parse(text)
            if (parsed.size < 100) error("Lista recebida inválida")
            File(context.filesDir, "filters.txt").writeText(parsed.joinToString("\n") { "0.0.0.0 $it" })
            adHosts = parse(readAsset("filters_ads.txt")) + parsed
            prefs.filterListUpdatedAt = System.currentTimeMillis()
            adHosts.size
        }
    }

    fun isAllowedSite(host: String?): Boolean = host != null && matches(allowed, host)
    fun allowedSites(): List<String> = allowed.sorted()

    fun setSiteAllowed(host: String, allow: Boolean) {
        val h = host.lowercase().removePrefix("www.")
        scope.launch {
            if (allow) db.allow().insert(AllowedSiteEntity(h)) else db.allow().delete(h)
            allowed = db.allow().all().toSet()
            version.incrementAndGet()
        }
    }

    private fun matches(set: Set<String>, host: String): Boolean {
        var h = host.lowercase().removePrefix("www.")
        while (h.contains('.')) {
            if (set.contains(h)) return true
            h = h.substringAfter('.')
        }
        return false
    }

    fun shouldBlock(url: String, host: String?, pageHost: String?, isMainFrame: Boolean, accept: String?): Boolean {
        if (!enabled || isMainFrame || host == null) return false
        if (isAllowedSite(pageHost)) return false
        if (pageHost != null && sameSite(host, pageHost)) return false
        if (mediaPath.containsMatchIn(url)) return false
        if (accept != null && (accept.startsWith("video/") || accept.startsWith("audio/"))) return false
        if (essential.containsMatchIn(url) && pageHost != null && sameSite(host, pageHost)) return false
        val isAd = matches(adHosts, host)
        val isTracker = !isAd && trackersEnabled && matches(trackerHosts, host)
        if (!isAd && !isTracker) return false
        session.incrementAndGet()
        if (isAd) sessionAds.incrementAndGet() else sessionTrackers.incrementAndGet()
        // Evita gravar nas preferências a cada requisição: grava em lotes
        if (pendingTotal.incrementAndGet() >= 25) flushCounter()
        return true
    }

    /** Persiste o contador total de bloqueios. */
    fun flushCounter() {
        val n = pendingTotal.getAndSet(0)
        if (n > 0) prefs.blockedCount = prefs.blockedCount + n
    }

    /** Resposta vazia coerente com o tipo do recurso, para não deixar imagens quebradas nem erros de script. */
    fun blockedResponse(url: String, accept: String?): WebResourceResponse {
        val headers = mapOf("Access-Control-Allow-Origin" to "*", "Cache-Control" to "no-store")
        return when {
            imagePath.containsMatchIn(url) || accept?.startsWith("image/") == true ->
                WebResourceResponse("image/gif", null, 200, "OK", headers, ByteArrayInputStream(PIXEL))
            scriptPath.containsMatchIn(url) || accept?.contains("javascript") == true ->
                WebResourceResponse("application/javascript", "utf-8", 200, "OK", headers, ByteArrayInputStream(ByteArray(0)))
            cssPath.containsMatchIn(url) || accept?.startsWith("text/css") == true ->
                WebResourceResponse("text/css", "utf-8", 200, "OK", headers, ByteArrayInputStream(ByteArray(0)))
            else -> WebResourceResponse("text/plain", "utf-8", 204, "No Content", headers, ByteArrayInputStream(ByteArray(0)))
        }
    }

    private fun sameSite(a: String, b: String): Boolean {
        fun root(x: String) = x.lowercase().split('.').takeLast(2).joinToString(".")
        return root(a) == root(b)
    }

    companion object {
        const val LIST_URL = "https://pgl.yoyo.org/adservers/serverlist.php?hostformat=hosts&showintro=0&mimetype=plaintext"
        // GIF transparente 1x1
        private val PIXEL = byteArrayOf(
            0x47, 0x49, 0x46, 0x38, 0x39, 0x61, 0x01, 0x00, 0x01, 0x00, 0x80.toByte(), 0x00, 0x00, 0x00, 0x00, 0x00,
            0xFF.toByte(), 0xFF.toByte(), 0xFF.toByte(), 0x21, 0xF9.toByte(), 0x04, 0x01, 0x00, 0x00, 0x00, 0x00, 0x2C,
            0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00, 0x00, 0x02, 0x01, 0x44, 0x00, 0x3B,
        )
    }
}
