package com.troy.browser.tabs

import android.graphics.Bitmap
import android.webkit.WebView
import com.troy.browser.player.FoundMedia

class Tab(val id: Long, val isPrivate: Boolean) {
    var webView: WebView? = null
    var title: String = ""
    var url: String = ""
    var favicon: Bitmap? = null
    /** Miniatura temporária usada somente na grade de abas. */
    var preview: Bitmap? = null
    var loading: Boolean = false
    var progress: Int = 0
    var isHome: Boolean = true
    var pendingLoad: Boolean = false
    val media = LinkedHashMap<String, FoundMedia>()
    var playerMedia: FoundMedia? = null
    var canGoBack: Boolean = false
    var canGoForward: Boolean = false

    fun displayTitle(default: String): String = when {
        isHome -> default
        title.isNotBlank() -> title
        else -> url
    }
}
