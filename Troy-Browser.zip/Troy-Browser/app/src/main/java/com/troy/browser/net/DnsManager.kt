package com.troy.browser.net

import android.content.Context
import android.util.Log
import androidx.webkit.ProxyConfig
import androidx.webkit.ProxyController
import androidx.webkit.WebViewFeature
import com.troy.browser.settings.Prefs
import com.troy.browser.util.Net
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Cache
import okhttp3.Dns
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.dnsoverhttps.DnsOverHttps
import java.io.File
import java.net.InetAddress
import java.util.concurrent.Executor

/**
 * DNS privado (DNS sobre HTTPS). Aplica ao tráfego do próprio app (downloads, sugestões, player)
 * e, quando o WebView suporta ProxyController, às páginas via um proxy local em 127.0.0.1 que resolve
 * os nomes pelo provedor escolhido.
 */
object DnsManager {
    class Provider(
        val id: String,
        val label: String,
        val description: String,
        val url: String?,
        val bootstrap: List<String> = emptyList(),
        val blocksAds: Boolean = false,
    )

    val providers: List<Provider> = listOf(
        Provider("off", "Desligado", "Usa o DNS do sistema (ou o DNS privado do Android)", null),
        Provider("cloudflare", "Cloudflare", "1.1.1.1 — rápido, foco em privacidade", "https://cloudflare-dns.com/dns-query", listOf("1.1.1.1", "1.0.0.1")),
        Provider("google", "Google", "8.8.8.8 — alta disponibilidade", "https://dns.google/dns-query", listOf("8.8.8.8", "8.8.4.4")),
        Provider("quad9", "Quad9", "Bloqueia domínios maliciosos", "https://dns.quad9.net/dns-query", listOf("9.9.9.9", "149.112.112.112")),
        Provider("adguard", "AdGuard DNS", "Bloqueia anúncios e rastreadores na rede", "https://dns.adguard-dns.com/dns-query", listOf("94.140.14.14", "94.140.15.15"), true),
        Provider("mullvad", "Mullvad (anúncios)", "Bloqueia anúncios e rastreadores", "https://adblock.dns.mullvad.net/dns-query", emptyList(), true),
        Provider("nextdns", "NextDNS", "Use o ID da sua configuração em nextdns.io", "https://dns.nextdns.io/{id}", emptyList(), true),
        Provider("custom", "Personalizado", "Endereço DoH próprio (https://…/dns-query)", null),
    )

    fun provider(id: String): Provider = providers.firstOrNull { it.id == id } ?: providers.first()

    class State(val active: Boolean, val label: String, val webViewCovered: Boolean, val message: String)

    @Volatile var state: State = State(false, "Desligado", false, "DNS do sistema")
        private set
    private val proxy = LocalProxy { Net.activeDns }
    private val inline = Executor { it.run() }

    /** Resolve a URL DoH final para a configuração atual, ou null se inválida/ausente. */
    fun resolveUrl(prefs: Prefs): String? {
        val p = provider(prefs.dnsProvider)
        return when (p.id) {
            "off" -> null
            "nextdns" -> prefs.nextDnsId.takeIf { Regex("^[0-9a-zA-Z]{4,12}$").matches(it) }?.let { p.url!!.replace("{id}", it) }
            "custom" -> prefs.customDohUrl.takeIf { it.startsWith("https://") && it.toHttpUrlOrNull() != null }
            else -> p.url
        }
    }

    private fun buildDoh(context: Context, url: String, bootstrap: List<String>): DnsOverHttps {
        val dir = File(context.cacheDir, "doh").apply { mkdirs() }
        val client = OkHttpClient.Builder().cache(Cache(dir, 1024L * 1024L)).build()
        val b = DnsOverHttps.Builder().client(client).url(url.toHttpUrlOrNull()!!).includeIPv6(true)
        val hosts = bootstrap.mapNotNull { runCatching { InetAddress.getByName(it) }.getOrNull() }
        if (hosts.isNotEmpty()) b.bootstrapDnsHosts(hosts)
        return b.build()
    }

    /** Aplica a configuração salva. Seguro para chamar de qualquer thread (trabalha em segundo plano). */
    suspend fun apply(context: Context, prefs: Prefs) = withContext(Dispatchers.IO) {
        val p = provider(prefs.dnsProvider)
        val url = resolveUrl(prefs)
        if (p.id == "off" || url == null) {
            Net.setDns(Dns.SYSTEM)
            proxy.stop()
            setWebViewProxy(null)
            state = State(false, "Desligado", false,
                if (p.id == "nextdns") "Informe o ID do NextDNS para ativar" else if (p.id == "custom") "Informe um endereço https:// válido" else "DNS do sistema")
            return@withContext
        }
        try {
            val doh = buildDoh(context.applicationContext, url, p.bootstrap)
            Net.setDns(doh)
            val covered = if (WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
                val port = proxy.start()
                setWebViewProxy(port)
            } else { proxy.stop(); false }
            state = State(true, p.label, covered,
                if (covered) "Ativo para páginas, downloads e player" else "Ativo para downloads e player. Este WebView não permite aplicar às páginas.")
        } catch (e: Exception) {
            Log.e("DnsManager", "Falha ao aplicar DNS privado", e)
            Net.setDns(Dns.SYSTEM); proxy.stop(); setWebViewProxy(null)
            state = State(false, "Erro", false, "Falha ao ativar: ${e.message}")
        }
    }

    /** O ProxyController deve ser usado na thread principal. */
    private suspend fun setWebViewProxy(port: Int?): Boolean = withContext(Dispatchers.Main) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) return@withContext false
        try {
            if (port == null) {
                ProxyController.getInstance().clearProxyOverride(inline) {}
            } else {
                val cfg = ProxyConfig.Builder().addProxyRule("127.0.0.1:$port").addDirect().build()
                ProxyController.getInstance().setProxyOverride(cfg, inline) {}
            }
            true
        } catch (e: Exception) {
            Log.w("DnsManager", "ProxyController indisponível: ${e.message}")
            false
        }
    }

    /** Consultas barradas pelo provedor (resposta 0.0.0.0 / domínio inexistente) nesta sessão. */
    val blockedQueries: Long get() = proxy.blockedCount

    /** Resolve um domínio pelo DNS ativo e devolve um resumo legível. */
    suspend fun test(host: String = "example.com"): String = withContext(Dispatchers.IO) {
        val t0 = System.currentTimeMillis()
        try {
            val addrs = Net.activeDns.lookup(host)
            val ms = System.currentTimeMillis() - t0
            val first = addrs.firstOrNull()
            val blocked = first != null && (first.isAnyLocalAddress || first.isLoopbackAddress)
            "${if (blocked) "Bloqueado pelo provedor" else "OK"} · $host → ${first?.hostAddress ?: "?"} (${ms} ms)"
        } catch (e: Exception) {
            "Falhou · ${e.message ?: e.javaClass.simpleName}"
        }
    }
}
