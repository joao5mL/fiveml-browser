package com.troy.browser

import android.app.Application
import com.troy.browser.adblock.AdBlocker
import com.troy.browser.data.AppDatabase
import com.troy.browser.downloads.DownloadCenter
import com.troy.browser.net.DnsManager
import com.troy.browser.notify.Notifier
import com.troy.browser.settings.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TroyApp : Application() {
    lateinit var db: AppDatabase; private set
    lateinit var prefs: Prefs; private set
    lateinit var adBlocker: AdBlocker; private set
    lateinit var downloads: DownloadCenter; private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        db = AppDatabase.get(this)
        prefs = Prefs(this)
        Notifier.createChannels(this)
        adBlocker = AdBlocker(this, prefs, db)
        downloads = DownloadCenter(this, db, prefs)
        adBlocker.load()
        downloads.recoverAfterRestart()
        CoroutineScope(Dispatchers.IO).launch { DnsManager.apply(this@TroyApp, prefs) }
    }

    companion object {
        lateinit var instance: TroyApp; private set
    }
}
