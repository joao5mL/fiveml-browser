package com.troy.browser.net

import android.util.Log
import okhttp3.Dns
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong

/**
 * Proxy HTTP local (somente 127.0.0.1). Atende CONNECT (HTTPS) e requisições http:// simples,
 * resolvendo os nomes pelo DNS informado (DoH). Não inspeciona nem altera o conteúdo HTTPS.
 */
class LocalProxy(private val dns: () -> Dns) {
    private val pool = Executors.newCachedThreadPool()
    @Volatile private var server: ServerSocket? = null
    @Volatile private var running = false
    val blockedCount: Long get() = blocked.get()
    private val blocked = AtomicLong(0)

    @Synchronized
    fun start(): Int {
        server?.takeIf { !it.isClosed }?.let { return it.localPort }
        val s = ServerSocket(0, 128, InetAddress.getByName("127.0.0.1"))
        server = s
        running = true
        pool.execute { acceptLoop(s) }
        return s.localPort
    }

    @Synchronized
    fun stop() {
        running = false
        runCatching { server?.close() }
        server = null
    }

    private fun acceptLoop(s: ServerSocket) {
        while (running && !s.isClosed) {
            try {
                val c = s.accept()
                pool.execute { handle(c) }
            } catch (e: IOException) {
                if (!running) break
            }
        }
    }

    private fun handle(client: Socket) {
        var upstream: Socket? = null
        try {
            client.soTimeout = IDLE_MS
            client.tcpNoDelay = true
            val cin = client.getInputStream()
            val cout = client.getOutputStream()
            val head = readHead(cin) ?: return
            val text = String(head.bytes, 0, head.headEnd, Charsets.ISO_8859_1)
            val lines = text.split("\r\n")
            val first = lines.firstOrNull()?.split(" ") ?: return
            if (first.size < 3) { reply(cout, 400); return }
            val method = first[0]
            val target = first[1]

            if (method.equals("CONNECT", true)) {
                val (host, port) = splitHostPort(target, 443)
                upstream = connectUpstream(host, port)
                if (upstream == null) { reply(cout, 502); return }
                cout.write("HTTP/1.1 200 Connection Established\r\n\r\n".toByteArray()); cout.flush()
                // Dados que o cliente já tenha enviado após o cabeçalho (raro em CONNECT)
                if (head.bytes.size > head.headEnd) upstream.getOutputStream().write(head.bytes, head.headEnd, head.bytes.size - head.headEnd)
                pipe(client, upstream)
            } else if (target.startsWith("http://", true)) {
                val rest = target.substring(7)
                val slash = rest.indexOf('/')
                val hostPort = if (slash >= 0) rest.substring(0, slash) else rest
                val path = if (slash >= 0) rest.substring(slash) else "/"
                val (host, port) = splitHostPort(hostPort, 80)
                upstream = connectUpstream(host, port)
                if (upstream == null) { reply(cout, 502); return }
                val hasUpgrade = lines.any { it.startsWith("Upgrade:", true) }
                val out = StringBuilder().append(method).append(' ').append(path).append(' ').append(first[2]).append("\r\n")
                for (i in 1 until lines.size) {
                    val l = lines[i]
                    if (l.isEmpty()) continue
                    val name = l.substringBefore(':').trim().lowercase()
                    if (name == "proxy-connection") continue
                    if (!hasUpgrade && (name == "connection" || name == "keep-alive")) continue
                    out.append(l).append("\r\n")
                }
                if (!hasUpgrade) out.append("Connection: close\r\n")
                out.append("\r\n")
                val uout = upstream.getOutputStream()
                uout.write(out.toString().toByteArray(Charsets.ISO_8859_1))
                if (head.bytes.size > head.headEnd) uout.write(head.bytes, head.headEnd, head.bytes.size - head.headEnd)
                uout.flush()
                pipe(client, upstream)
            } else {
                reply(cout, 405)
            }
        } catch (e: Exception) {
            Log.d(TAG, "Conexão encerrada: ${e.message}")
        } finally {
            runCatching { upstream?.close() }
            runCatching { client.close() }
        }
    }

    private fun connectUpstream(host: String, port: Int): Socket? {
        val addrs = try {
            if (isIpLiteral(host)) listOf(InetAddress.getByName(host)) else dns().lookup(host)
        } catch (e: Exception) {
            Log.d(TAG, "DNS falhou para $host: ${e.message}")
            return null
        }
        // Provedores com bloqueio respondem 0.0.0.0 / :: / 127.x para domínios filtrados
        val usable = addrs.filter { !(it.isAnyLocalAddress || it.isLoopbackAddress) || host.equals("localhost", true) }
        if (usable.isEmpty()) { blocked.incrementAndGet(); return null }
        for (a in usable) {
            val s = Socket()
            try {
                s.tcpNoDelay = true
                s.connect(InetSocketAddress(a, port), CONNECT_MS)
                s.soTimeout = IDLE_MS
                return s
            } catch (e: IOException) {
                runCatching { s.close() }
            }
        }
        return null
    }

    private fun pipe(a: Socket, b: Socket) {
        val t = pool.submit(Runnable {
            copy(a.getInputStream(), b.getOutputStream())
            runCatching { b.shutdownOutput() }
        })
        copy(b.getInputStream(), a.getOutputStream())
        runCatching { a.shutdownOutput() }
        runCatching { t.get(IDLE_MS.toLong(), TimeUnit.MILLISECONDS) }
    }

    private fun copy(input: InputStream, output: OutputStream) {
        val buf = ByteArray(16 * 1024)
        try {
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                output.write(buf, 0, n)
                output.flush()
            }
        } catch (e: IOException) { /* conexão encerrada ou inativa */ }
    }

    private class Head(val bytes: ByteArray, val headEnd: Int)

    /** Lê até o fim do cabeçalho (\r\n\r\n), limitado a 64 KB. */
    private fun readHead(input: InputStream): Head? {
        val buf = ByteArrayOutputStream()
        val one = ByteArray(4096)
        var end = -1
        while (end < 0) {
            val n = input.read(one)
            if (n < 0) return null
            buf.write(one, 0, n)
            val arr = buf.toByteArray()
            end = indexOfHeadEnd(arr)
            if (arr.size > 64 * 1024 && end < 0) return null
        }
        return Head(buf.toByteArray(), end)
    }

    private fun indexOfHeadEnd(a: ByteArray): Int {
        for (i in 0..a.size - 4) {
            if (a[i] == 13.toByte() && a[i + 1] == 10.toByte() && a[i + 2] == 13.toByte() && a[i + 3] == 10.toByte()) return i + 4
        }
        return -1
    }

    private fun splitHostPort(s: String, defaultPort: Int): Pair<String, Int> {
        if (s.startsWith("[")) {
            val close = s.indexOf(']')
            val host = s.substring(1, close)
            val port = s.substring(close + 1).removePrefix(":").toIntOrNull() ?: defaultPort
            return host to port
        }
        val i = s.lastIndexOf(':')
        return if (i > 0 && s.indexOf(':') == i) s.substring(0, i) to (s.substring(i + 1).toIntOrNull() ?: defaultPort) else s to defaultPort
    }

    private fun isIpLiteral(h: String) = Regex("""^(\d{1,3}\.){3}\d{1,3}$""").matches(h) || h.contains(':')

    private fun reply(out: OutputStream, code: Int) {
        val msg = when (code) { 400 -> "Bad Request"; 405 -> "Method Not Allowed"; else -> "Bad Gateway" }
        runCatching { out.write("HTTP/1.1 $code $msg\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".toByteArray()); out.flush() }
    }

    companion object {
        private const val TAG = "LocalProxy"
        private const val IDLE_MS = 120_000
        private const val CONNECT_MS = 15_000
    }
}
