package com.troy.browser.ui

import android.content.Intent
import android.provider.Settings
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.troy.browser.BuildConfig
import com.troy.browser.R
import com.troy.browser.net.DnsManager
import com.troy.browser.notify.Notifier
import com.troy.browser.settings.Prefs
import kotlinx.coroutines.launch

/** Configurações em categorias: a página inicial lista as áreas e cada uma abre sua própria tela. */
class SettingsActivity : ListPageActivity() {
    private val category: String? get() = intent.getStringExtra(EXTRA_CATEGORY)

    override fun pageTitle() = when (category) {
        CAT_APPEARANCE -> "Aparência e menu"
        CAT_SEARCH -> "Pesquisa"
        CAT_DOWNLOADS -> "Downloads"
        CAT_PRIVACY -> "Privacidade e segurança"
        CAT_PLAYBACK -> "Reprodução multimídia"
        CAT_ADVANCED -> "Avançado"
        CAT_ABOUT -> "Sobre o Troy Browser"
        else -> "Configurações"
    }

    override fun build() {
        when (category) {
            CAT_APPEARANCE -> appearance()
            CAT_SEARCH -> search()
            CAT_DOWNLOADS -> downloads()
            CAT_PRIVACY -> privacy()
            CAT_PLAYBACK -> playback()
            CAT_ADVANCED -> advanced()
            CAT_ABOUT -> about()
            else -> home()
        }
    }

    private fun open(cat: String) = startActivity(Intent(this, SettingsActivity::class.java).putExtra(EXTRA_CATEGORY, cat))

    private fun home() {
        addSpace(8)
        val engine = Prefs.ENGINES[prefs.searchEngine]?.first ?: "Google"
        val dns = DnsManager.state
        row("Aparência e menu", "Tema, papel de parede, posição do menu", R.drawable.ic_palette, true) { open(CAT_APPEARANCE) }
        row("Pesquisa", engine, R.drawable.ic_search, true) { open(CAT_SEARCH) }
        row("Downloads", "Simultâneos, velocidade, Wi-Fi, notificações", R.drawable.ic_download, true) { open(CAT_DOWNLOADS) }
        row("Privacidade e segurança", "Cookies, Safe Browsing, limpar dados", R.drawable.ic_lock, true) { open(CAT_PRIVACY) }
        row("Bloqueador de anúncios", if (prefs.adBlockEnabled) "Ativo" else "Desativado", R.drawable.ic_shield, true) {
            startActivity(Intent(this, AdBlockActivity::class.java))
        }
        row("DNS privado", if (dns.active) "Ativo · ${dns.label}" else "Desligado", R.drawable.ic_dns, true) {
            startActivity(Intent(this, DnsActivity::class.java))
        }
        row("Reprodução multimídia", "Player integrado", R.drawable.ic_play, true) { open(CAT_PLAYBACK) }
        row("Avançado", "JavaScript, modo desktop", R.drawable.ic_tune, true) { open(CAT_ADVANCED) }
        row("Sobre o Troy Browser", "Versão ${BuildConfig.VERSION_NAME}", R.drawable.ic_info, true) { open(CAT_ABOUT) }
    }

    private fun appearance() {
        row("Tema e papel de parede", "Temas, gradientes, papel de parede e opacidade", R.drawable.ic_palette, true) {
            startActivity(Intent(this, AppearanceActivity::class.java))
        }
        row("Posição do menu", if (prefs.menuPosition == "bottom") "Inferior" else "Superior") {
            MaterialAlertDialogBuilder(this).setTitle("Posição do menu")
                .setSingleChoiceItems(arrayOf("Superior", "Inferior"), if (prefs.menuPosition == "bottom") 1 else 0) { d, which ->
                    prefs.menuPosition = if (which == 1) "bottom" else "top"; d.dismiss(); rebuild()
                }.setNegativeButton("Cancelar", null).show()
        }
        switchRow("Barra inferior de navegação", "Mostra voltar, avançar e início na parte de baixo", prefs.showBottomBar) { prefs.showBottomBar = it }
        section("Página inicial")
        switchRow("Mostrar atalhos", "Exibe seus atalhos personalizados", prefs.showShortcutsOnHome) { prefs.showShortcutsOnHome = it }
        switchRow("Mostrar pesquisas recentes", "Exibe o histórico de pesquisas", prefs.showSearchHistoryOnHome) { prefs.showSearchHistoryOnHome = it }
        section("Sessão")
        switchRow("Restaurar abas ao abrir", "Reabre as abas normais da última sessão", prefs.restoreTabs) { prefs.restoreTabs = it }
    }

    private fun search() {
        val keys = Prefs.ENGINES.keys.toList()
        keys.forEach { k ->
            val selected = prefs.searchEngine == k
            row((if (selected) "● " else "○ ") + (Prefs.ENGINES[k]?.first ?: k), Prefs.ENGINES[k]?.second?.substringBefore("/search")?.substringBefore("/?") ?: "") {
                prefs.searchEngine = k; rebuild()
            }
        }
    }

    private fun downloads() {
        row("Downloads simultâneos", prefs.maxParallelDownloads.toString()) {
            MaterialAlertDialogBuilder(this).setTitle("Downloads simultâneos")
                .setSingleChoiceItems(arrayOf("1", "2", "3", "4", "5", "6"), prefs.maxParallelDownloads - 1) { d, i -> prefs.maxParallelDownloads = i + 1; d.dismiss(); rebuild() }.show()
        }
        row("Limite de velocidade", if (prefs.speedLimitKbps == 0) "Sem limite" else "${prefs.speedLimitKbps} KB/s") {
            val opts = intArrayOf(0, 256, 512, 1024, 2048, 5120)
            MaterialAlertDialogBuilder(this).setTitle("Limite de velocidade")
                .setItems(opts.map { if (it == 0) "Sem limite" else "$it KB/s" }.toTypedArray()) { _, i -> prefs.speedLimitKbps = opts[i]; rebuild() }.show()
        }
        switchRow("Somente Wi-Fi", "Não baixa usando dados móveis", prefs.wifiOnly) { prefs.wifiOnly = it }
        info("Pasta de armazenamento", "Vídeos: Movies/Troy Browser\nÁudio: Music/Troy Browser\nOutros: Download/Troy Browser")
        section("Notificações")
        row("Permissão de notificações", if (Notifier.canNotify(this)) "Concedida" else "Não concedida — toque para ajustar") {
            startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
        }
    }

    private fun privacy() {
        switchRow("Cookies de terceiros", "Permite cookies de outros domínios nas páginas", prefs.thirdPartyCookies) { prefs.thirdPartyCookies = it }
        switchRow("Proteção contra sites perigosos", "Verificação Safe Browsing fornecida pelo WebView do Android", prefs.safeBrowsingEnabled) { prefs.safeBrowsingEnabled = it }
        section("Limpar dados")
        row("Limpar histórico", "Remove todos os sites visitados", R.drawable.ic_history) {
            UiUtil.confirm(this, "Limpar histórico", "Remover todo o histórico?", "Limpar") { lifecycleScope.launch { app.db.history().clear() } }
        }
        row("Limpar pesquisas recentes", "", R.drawable.ic_search) { lifecycleScope.launch { app.db.searches().clear(); UiUtil.toast(this@SettingsActivity, "Pesquisas removidas") } }
        row("Limpar cookies", "", R.drawable.ic_lock) { android.webkit.CookieManager.getInstance().removeAllCookies { UiUtil.toast(this, "Cookies removidos") } }
        row("Limpar cache", "", R.drawable.ic_delete) { android.webkit.WebView(this).apply { clearCache(true); destroy() }; cacheDir.deleteRecursively(); UiUtil.toast(this, "Cache limpo") }
        section("Navegação privada")
        info("Como funciona", "Abas privadas não salvam histórico, pesquisas nem miniaturas, e seus downloads não aparecem na lista. O armazenamento é isolado quando o WebView do aparelho suporta perfis.")
    }

    private fun playback() {
        info("Player integrado", "Reproduz MP4, WebM, HLS e DASH, com tela cheia, controle de qualidade quando a fonte oferece e áudio.")
        info("Download de vídeos", "O Troy baixa vídeos diretos e HLS sem criptografia. Conteúdo protegido por DRM ou transmissões ao vivo não são baixados.")
    }

    private fun advanced() {
        switchRow("JavaScript", "Necessário para a maioria dos sites. Aplica-se a novas abas.", prefs.javascriptEnabled) { prefs.javascriptEnabled = it }
        switchRow("Modo desktop", "Solicita a versão para computador dos sites", prefs.desktopMode) { prefs.desktopMode = it }
    }

    private fun about() {
        info("Troy Browser", "Versão ${BuildConfig.VERSION_NAME}\nMotor de renderização: Android WebView (Chromium)")
    }

    companion object {
        const val EXTRA_CATEGORY = "category"
        const val CAT_APPEARANCE = "appearance"
        const val CAT_SEARCH = "search"
        const val CAT_DOWNLOADS = "downloads"
        const val CAT_PRIVACY = "privacy"
        const val CAT_PLAYBACK = "playback"
        const val CAT_ADVANCED = "advanced"
        const val CAT_ABOUT = "about"
    }
}
