package com.troy.browser.util

import okhttp3.Dns
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

object Net {
    const val USER_AGENT =
        "Mozilla/5.0 (Linux; Android 15; RMX3710) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/126.0.0.0 Mobile Safari/537.36"

    @Volatile private var dns: Dns = Dns.SYSTEM
    @Volatile private var current: OkHttpClient = build(Dns.SYSTEM)

    /** Cliente HTTP do app (downloads, sugestões, player). Usa o DNS privado quando ativo. */
    val client: OkHttpClient get() = current

    /** DNS atualmente em uso pelo app (sistema ou DoH). */
    val activeDns: Dns get() = dns

    fun setDns(newDns: Dns) {
        dns = newDns
        current = build(newDns)
    }

    private fun build(d: Dns): OkHttpClient = OkHttpClient.Builder()
        .dns(d)
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .retryOnConnectionFailure(true)
        .build()
}
