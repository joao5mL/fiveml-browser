package com.troy.browser.downloads

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.File
import java.nio.ByteBuffer

/** Une trilhas de vídeo/áudio de um ou mais arquivos em um MP4 final usando MediaMuxer. */
object Remuxer {
    fun remux(inputs: List<File>, output: File) {
        output.delete()
        val muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val extractors = mutableListOf<MediaExtractor>()
        try {
            data class Mapping(val ex: MediaExtractor, val src: Int, val dst: Int)
            val maps = mutableListOf<Mapping>()
            var haveVideo = false
            var haveAudio = false
            for (f in inputs) {
                val ex = MediaExtractor().also { extractors += it }
                ex.setDataSource(f.absolutePath)
                for (t in 0 until ex.trackCount) {
                    val fmt = ex.getTrackFormat(t)
                    val mime = fmt.getString(MediaFormat.KEY_MIME).orEmpty()
                    val take = (mime.startsWith("video/") && !haveVideo) || (mime.startsWith("audio/") && !haveAudio)
                    if (!take) continue
                    if (mime.startsWith("video/")) haveVideo = true else haveAudio = true
                    maps += Mapping(ex, t, muxer.addTrack(fmt))
                }
            }
            if (maps.isEmpty()) throw DownloadFailure("Nenhuma trilha de mídia compatível encontrada")
            muxer.start()
            val buffer = ByteBuffer.allocate(2 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()
            for (m in maps) {
                m.ex.selectTrack(m.src)
                m.ex.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
                while (true) {
                    buffer.clear()
                    val size = m.ex.readSampleData(buffer, 0)
                    if (size < 0) break
                    info.set(0, size, m.ex.sampleTime, if (m.ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                    muxer.writeSampleData(m.dst, buffer, info)
                    m.ex.advance()
                }
                m.ex.unselectTrack(m.src)
            }
            muxer.stop()
        } catch (e: DownloadFailure) {
            throw e
        } catch (e: Exception) {
            output.delete()
            throw DownloadFailure("Não foi possível montar o vídeo final: ${e.message}")
        } finally {
            runCatching { muxer.release() }
            extractors.forEach { runCatching { it.release() } }
        }
        if (output.length() <= 0) throw DownloadFailure("Arquivo final vazio após a montagem")
    }
}
