package com.troy.browser.ui

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.GridLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.troy.browser.TroyApp
import com.troy.browser.R
import com.google.android.material.switchmaterial.SwitchMaterial
import coil.load
import com.google.android.material.slider.Slider
import java.io.File

/** Temas, papel de parede (prontos ou da galeria) e opacidade. */
class AppearanceActivity : AppCompatActivity() {
    private val prefs get() = (application as TroyApp).prefs
    private lateinit var appliedTheme: String
    private lateinit var content: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val galleryPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@registerForActivityResult
        val f = Wallpapers.importFromGallery(this, uri)
        if (f == null) { UiUtil.toast(this, "Não foi possível usar esta imagem"); return@registerForActivityResult }
        prefs.homeWallpaper = f.absolutePath
        prefs.wallpaperPreset = ""
        build()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        appliedTheme = ThemeManager.apply(this)
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundResource(R.drawable.bg_gradient) }
        val bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(UiUtil.attr(context, R.attr.trBgSecondary)); minimumHeight = dp(56)
        }
        val back = android.widget.ImageButton(this).apply {
            setImageResource(R.drawable.ic_back); setColorFilter(UiUtil.attr(context, R.attr.trTextPrimary))
            setBackgroundResource(android.R.color.transparent); setPadding(dp(14), dp(14), dp(14), dp(14))
            setOnClickListener { finish() }
        }
        bar.addView(back, LinearLayout.LayoutParams(dp(52), dp(52)))
        bar.addView(TextView(this).apply {
            text = "Aparência"; textSize = 19f; setTextColor(UiUtil.attr(context, R.attr.trTextPrimary))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(32)) }
        root.addView(ScrollView(this).apply { addView(content) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        build()
    }

    override fun onResume() {
        super.onResume()
        if (ThemeManager.changed(this, appliedTheme)) recreate()
    }

    private fun build() {
        content.removeAllViews()
        val textP = UiUtil.attr(this, R.attr.trTextPrimary)
        val textS = UiUtil.attr(this, R.attr.trTextSecondary)
        val accent = UiUtil.attr(this, R.attr.trAccent)
        val border = UiUtil.attr(this, R.attr.trBorder)

        fun header(t: String, sub: String? = null) {
            content.addView(TextView(this).apply {
                text = t.uppercase(); textSize = 12f; letterSpacing = 0.1f; setTextColor(UiUtil.attr(context, R.attr.trAccentDim))
                setPadding(dp(20), dp(22), dp(20), dp(if (sub == null) 8 else 2))
            })
            if (sub != null) content.addView(TextView(this).apply {
                text = sub; textSize = 12.5f; setTextColor(textS); setPadding(dp(20), 0, dp(20), dp(8))
            })
        }

        // ── Temas ──
        header("Tema", "Escolha as cores do navegador")
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(14), dp(4), dp(14), dp(4)) }
        ThemeManager.all.forEach { t ->
            val selected = ThemeManager.info(prefs.themeId).id == t.id
            val item = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(6), dp(4), dp(6), dp(4)) }
            val swatch = View(this).apply {
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(t.gradStart, t.gradEnd)).apply {
                    shape = GradientDrawable.OVAL
                    setStroke(dp(if (selected) 3 else 1), if (selected) accent else border)
                }
            }
            item.addView(swatch, LinearLayout.LayoutParams(dp(58), dp(58)))
            item.addView(View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(t.accent) }
            }, LinearLayout.LayoutParams(dp(10), dp(10)).apply { topMargin = dp(6) })
            item.addView(TextView(this).apply { text = t.label; textSize = 11.5f; setTextColor(if (selected) textP else textS); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(70), -2).apply { topMargin = dp(2) })
            item.setOnClickListener {
                if (!selected) { prefs.themeId = t.id; recreate() }
            }
            row.addView(item)
        }
        content.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) })

        // ── Papel de parede ──
        header("Papel de parede da página inicial", "Prontos ou da sua galeria")
        val grid = GridLayout(this).apply { columnCount = 3; setPadding(dp(14), 0, dp(14), 0) }
        val hasGallery = prefs.homeWallpaper?.let { File(it).exists() } == true
        val currentPreset = prefs.wallpaperPreset

        fun tile(label: String, selected: Boolean, fill: (ImageView) -> Unit, onClick: () -> Unit) {
            val cell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(5), dp(5), dp(5), dp(5)) }
            val frame = android.widget.FrameLayout(this).apply {
                background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setStroke(dp(if (selected) 3 else 1), if (selected) accent else border); setColor(Color.TRANSPARENT) }
                setPadding(dp(3), dp(3), dp(3), dp(3))
            }
            val img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; clipToOutline = true
                outlineProvider = object : android.view.ViewOutlineProvider() { override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(11).toFloat()) } } }
            fill(img)
            frame.addView(img, android.widget.FrameLayout.LayoutParams(-1, -1))
            cell.addView(frame, LinearLayout.LayoutParams(dp(100), dp(130)))
            cell.addView(TextView(this).apply { text = label; textSize = 12f; setTextColor(if (selected) textP else textS); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(2) })
            cell.setOnClickListener { onClick() }
            grid.addView(cell)
        }

        tile("Do tema", currentPreset.isEmpty() && !hasGallery, { img ->
            val info = ThemeManager.info(prefs.themeId)
            img.setImageDrawable(GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(info.gradStart, info.gradEnd)))
        }) { prefs.wallpaperPreset = ""; prefs.homeWallpaper?.let { File(it).delete() }; prefs.homeWallpaper = null; build() }

        Wallpapers.presets.forEach { sp ->
            tile(sp.label, currentPreset == sp.id && !hasGallery, { img -> img.setImageDrawable(Wallpapers.WallpaperDrawable(sp)) }) {
                prefs.homeWallpaper?.let { File(it).delete() }; prefs.homeWallpaper = null; prefs.wallpaperPreset = sp.id; build()
            }
        }
        tile("Galeria", hasGallery, { img ->
            if (hasGallery) img.load(File(prefs.homeWallpaper!!))
            else { img.setBackgroundColor(UiUtil.attr(this, R.attr.trSurfaceElevated)); img.setImageResource(R.drawable.ic_add); img.scaleType = ImageView.ScaleType.CENTER; img.setColorFilter(textP) }
        }) { galleryPicker.launch("image/*") }
        content.addView(grid)

        // ── Opacidade ──
        header("Opacidade do papel de parede")
        val label = TextView(this).apply { textSize = 13f; setTextColor(textP); setPadding(dp(20), 0, dp(20), 0); text = "${prefs.wallpaperOpacity}%" }
        content.addView(label)
        content.addView(Slider(this).apply {
            valueFrom = 0f; valueTo = 100f; stepSize = 5f; value = (prefs.wallpaperOpacity / 5 * 5).toFloat()
            trackActiveTintList = android.content.res.ColorStateList.valueOf(accent)
            thumbTintList = android.content.res.ColorStateList.valueOf(accent)
            addOnChangeListener { _, v, _ -> prefs.wallpaperOpacity = v.toInt(); label.text = "${v.toInt()}%" }
        }, LinearLayout.LayoutParams(-1, -2).apply { marginStart = dp(12); marginEnd = dp(12) })

        // ── Elementos da página inicial ──
        header("Página inicial")
        switchRow("Mostrar atalhos", prefs.showShortcutsOnHome) { prefs.showShortcutsOnHome = it }
        switchRow("Mostrar pesquisas recentes", prefs.showSearchHistoryOnHome) { prefs.showSearchHistoryOnHome = it }
    }

    private fun switchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), dp(8), dp(16), dp(8)) }
        r.addView(TextView(this).apply { text = title; textSize = 15f; setTextColor(UiUtil.attr(context, R.attr.trTextPrimary)) }, LinearLayout.LayoutParams(0, -2, 1f))
        val sw = SwitchMaterial(this).apply { isChecked = checked; setOnCheckedChangeListener { _, c -> onChange(c) } }
        r.addView(sw)
        r.setOnClickListener { sw.toggle() }
        content.addView(r)
    }
}
