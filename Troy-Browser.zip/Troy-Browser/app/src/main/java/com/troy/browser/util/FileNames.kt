package com.troy.browser.util

import android.net.Uri
import android.webkit.URLUtil

object FileNames {
    private val invalid = Regex("""[\\/:*?"<>|\u0000-\u001F]""")
    private val genericBase = Regex("""^(init([-_].*)?|video[-_]?\d*|media[-_]?\d*|download(file)?|index|master|playlist|segment[-_]?\d*|chunk[-_]?\d*|seg[-_]?\d*)$""", RegexOption.IGNORE_CASE)

    fun sanitize(raw: String): String =
        raw.replace(invalid, "_").replace(Regex("\\s+"), " ").trim().trim('.', ' ').take(150)

    fun isGeneric(name: String): Boolean = genericBase.matches(name.substringBeforeLast('.'))

    fun extensionFor(mime: String?, url: String): String {
        val m = mime?.lowercase().orEmpty()
        return when {
            m.contains("webm") -> "webm"
            m.contains("quicktime") -> "mov"
            m.contains("3gpp") -> "3gp"
            m.contains("matroska") -> "mkv"
            m.contains("mpegurl") -> "mp4"
            m.startsWith("audio/mpeg") -> "mp3"
            m.startsWith("audio/mp4") || m.contains("m4a") -> "m4a"
            m == "image/png" -> "png"
            m == "image/webp" -> "webp"
            m == "image/gif" -> "gif"
            m == "image/avif" -> "avif"
            m == "image/jpeg" || m == "image/jpg" -> "jpg"
            m.startsWith("video/") -> "mp4"
            else -> Regex("""\.([a-z0-9]{2,5})(?=$|[?#])""", RegexOption.IGNORE_CASE)
                .find(Uri.parse(url).path.orEmpty())?.groupValues?.get(1)?.lowercase() ?: "bin"
        }
    }

    /** Prioridade: título da página/vídeo > nome do servidor > nome da URL. */
    fun build(title: String?, url: String, contentDisposition: String?, mime: String?): String {
        val clean = title?.let { sanitize(it) }?.takeIf { it.isNotBlank() }
        val ext = extensionFor(mime, url)
        if (clean != null) {
            return if (clean.endsWith(".$ext", true)) clean else "$clean.$ext"
        }
        val guessed = sanitize(URLUtil.guessFileName(url, contentDisposition, mime))
        return guessed.ifBlank { "arquivo_${System.currentTimeMillis()}.$ext" }
    }

    fun unique(name: String, exists: (String) -> Boolean): String {
        if (!exists(name)) return name
        val base = name.substringBeforeLast('.', name)
        val ext = name.substringAfterLast('.', "")
        var i = 1
        while (true) {
            val candidate = if (ext.isEmpty()) "$base ($i)" else "$base ($i).$ext"
            if (!exists(candidate)) return candidate
            i++
        }
    }
}
