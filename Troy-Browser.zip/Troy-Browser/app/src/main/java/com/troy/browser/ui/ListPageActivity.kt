package com.troy.browser.ui

import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.annotation.AttrRes
import androidx.annotation.DrawableRes
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.switchmaterial.SwitchMaterial
import com.troy.browser.R
import com.troy.browser.TroyApp

/** Base das telas de configuração: barra de título, rolagem e componentes padronizados. */
abstract class ListPageActivity : AppCompatActivity() {
    protected val app get() = application as TroyApp
    protected val prefs get() = app.prefs
    protected lateinit var content: LinearLayout
    private lateinit var appliedTheme: String
    private var firstResume = true

    protected abstract fun pageTitle(): String
    protected abstract fun build()

    protected fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    protected fun color(@AttrRes attr: Int) = UiUtil.attr(this, attr)

    override fun onCreate(savedInstanceState: Bundle?) {
        appliedTheme = ThemeManager.apply(this)
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundResource(R.drawable.bg_gradient) }
        val bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(color(R.attr.trBgSecondary)); minimumHeight = dp(56)
        }
        bar.addView(ImageButton(this).apply {
            setImageResource(R.drawable.ic_back); setColorFilter(color(R.attr.trTextPrimary))
            setBackgroundResource(android.R.color.transparent); setPadding(dp(14), dp(14), dp(14), dp(14))
            contentDescription = "Voltar"
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(52), dp(52)))
        bar.addView(TextView(this).apply {
            text = pageTitle(); textSize = 19f; setTextColor(color(R.attr.trTextPrimary))
            setTypeface(typeface, Typeface.BOLD)
        })
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(32)) }
        root.addView(ScrollView(this).apply { addView(content) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        build()
    }

    override fun onResume() {
        super.onResume()
        if (ThemeManager.changed(this, appliedTheme)) { recreate(); return }
        if (firstResume) firstResume = false else rebuild()
    }

    protected fun rebuild() {
        content.removeAllViews()
        build()
    }

    // ── componentes ──

    protected fun section(title: String) {
        content.addView(TextView(this).apply {
            text = title.uppercase(); textSize = 12f; letterSpacing = 0.1f
            setTextColor(color(R.attr.trAccentDim)); setPadding(dp(20), dp(24), dp(20), dp(6))
        })
    }

    private fun selectableBackground(): Int {
        val tv = android.util.TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        return tv.resourceId
    }

    private fun textColumn(title: String, sub: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(TextView(context).apply { text = title; textSize = 15.5f; setTextColor(color(R.attr.trTextPrimary)) })
        if (sub.isNotBlank()) addView(TextView(context).apply {
            text = sub; textSize = 12.5f; setTextColor(color(R.attr.trTextSecondary)); setPadding(0, dp(2), 0, 0)
        })
    }

    /** Linha clicável com ícone opcional e seta. */
    protected fun row(title: String, sub: String = "", @DrawableRes icon: Int? = null, chevron: Boolean = false, onClick: () -> Unit) {
        val r = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(13), dp(16), dp(13))
            isClickable = true; isFocusable = true
            setBackgroundResource(selectableBackground())
            setOnClickListener { onClick() }
        }
        if (icon != null) r.addView(ImageView(this).apply { setImageResource(icon); setColorFilter(color(R.attr.trAccent)) },
            LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginEnd = dp(18) })
        r.addView(textColumn(title, sub), LinearLayout.LayoutParams(0, -2, 1f))
        if (chevron) r.addView(ImageView(this).apply { setImageResource(R.drawable.ic_chevron); setColorFilter(color(R.attr.trTextSecondary)) },
            LinearLayout.LayoutParams(dp(22), dp(22)))
        content.addView(r, ViewGroup.LayoutParams(-1, -2))
    }

    protected fun info(title: String, sub: String) {
        content.addView(LinearLayout(this).apply {
            setPadding(dp(20), dp(12), dp(20), dp(12)); addView(textColumn(title, sub))
        }, ViewGroup.LayoutParams(-1, -2))
    }

    protected fun switchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        val r = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), dp(10), dp(16), dp(10))
            setBackgroundResource(selectableBackground())
        }
        r.addView(textColumn(title, sub), LinearLayout.LayoutParams(0, -2, 1f))
        val sw = SwitchMaterial(this).apply { isChecked = checked; setOnCheckedChangeListener { _, c -> onChange(c) } }
        r.addView(sw)
        r.setOnClickListener { sw.toggle() }
        content.addView(r, ViewGroup.LayoutParams(-1, -2))
    }

    /** Cartão com números em destaque (ex.: estatísticas). */
    protected fun statsCard(items: List<Pair<String, String>>) {
        val card = LinearLayout(this).apply {
            setBackgroundResource(R.drawable.bg_card); setPadding(dp(8), dp(16), dp(8), dp(16))
        }
        items.forEach { (label, value) ->
            card.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                addView(TextView(context).apply { text = value; textSize = 22f; setTypeface(typeface, Typeface.BOLD); setTextColor(color(R.attr.trTextPrimary)) })
                addView(TextView(context).apply { text = label; textSize = 11.5f; gravity = Gravity.CENTER; setTextColor(color(R.attr.trTextSecondary)) })
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(16), dp(14), dp(16), dp(6)) })
    }

    /** Cartão de estado com ícone grande (ativo/inativo). */
    protected fun statusCard(@DrawableRes icon: Int, active: Boolean, title: String, sub: String) {
        val card = LinearLayout(this).apply {
            setBackgroundResource(R.drawable.bg_card); gravity = Gravity.CENTER_VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        card.addView(ImageView(this).apply {
            setImageResource(icon); setColorFilter(if (active) color(R.attr.trAccent) else color(R.attr.trTextSecondary))
            setBackgroundResource(R.drawable.bg_icon_tile); setPadding(dp(14), dp(14), dp(14), dp(14))
        }, LinearLayout.LayoutParams(dp(60), dp(60)).apply { marginEnd = dp(16) })
        card.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(context).apply { text = title; textSize = 17f; setTypeface(typeface, Typeface.BOLD); setTextColor(color(R.attr.trTextPrimary)) })
            addView(TextView(context).apply { text = sub; textSize = 12.5f; setTextColor(color(R.attr.trTextSecondary)); setPadding(0, dp(3), 0, 0) })
        }, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(16), dp(16), dp(16), dp(4)) })
    }

    protected fun addSpace(h: Int) { content.addView(View(this), LinearLayout.LayoutParams(-1, dp(h))) }
}
