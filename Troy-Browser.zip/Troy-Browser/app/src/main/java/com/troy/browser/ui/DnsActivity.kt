package com.troy.browser.ui

import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.troy.browser.R
import com.troy.browser.net.DnsManager
import kotlinx.coroutines.launch

/** DNS privado (DNS sobre HTTPS): escolha do provedor, teste e estado. */
class DnsActivity : ListPageActivity() {

    override fun pageTitle() = "DNS privado"

    override fun build() {
        val st = DnsManager.state
        statusCard(R.drawable.ic_dns, st.active,
            if (st.active) "Ativo · ${st.label}" else "Desligado", st.message)

        if (st.active) statsCard(listOf("Consultas bloqueadas pelo provedor" to DnsManager.blockedQueries.toString()))

        section("Provedor")
        DnsManager.providers.forEach { p ->
            val selected = prefs.dnsProvider == p.id
            row((if (selected) "● " else "○ ") + p.label, p.description + if (p.blocksAds) " · filtra anúncios" else "") { choose(p.id) }
        }

        when (prefs.dnsProvider) {
            "nextdns" -> row("ID da configuração NextDNS", prefs.nextDnsId.ifBlank { "Toque para informar (ex.: abc123)" }, R.drawable.ic_tune) {
                UiUtil.input2(this, "NextDNS", "ID da configuração", prefs.nextDnsId, null, "") { v, _ ->
                    prefs.nextDnsId = v; applyAndRebuild()
                }
            }
            "custom" -> row("Endereço DoH", prefs.customDohUrl.ifBlank { "Toque para informar (https://…/dns-query)" }, R.drawable.ic_link) {
                UiUtil.input2(this, "DNS personalizado", "https://servidor/dns-query", prefs.customDohUrl, null, "") { v, _ ->
                    prefs.customDohUrl = v; applyAndRebuild()
                }
            }
        }

        section("Testes")
        row("Testar conexão", "Resolve example.com pelo DNS atual", R.drawable.ic_refresh) { runTest("example.com") }
        row("Testar bloqueio de anúncios", "Resolve doubleclick.net — provedores com filtro devem bloquear", R.drawable.ic_shield) { runTest("doubleclick.net") }

        section("Como funciona")
        info("Consultas criptografadas", "O Troy envia as consultas de DNS por HTTPS para o provedor escolhido. Vale para downloads, player e para as páginas, quando o WebView do aparelho permite.")
        info("Anúncios na rede", "Com AdGuard, Mullvad ou NextDNS (com listas de bloqueio ativadas na sua conta) os anúncios são barrados antes da conexão, além do bloqueador do navegador.")
        info("Se algum site falhar", "Escolha outro provedor ou volte para \"Desligado\". O DNS privado do Android (Configurações › Rede) continua funcionando de forma independente.")
    }

    private fun choose(id: String) {
        prefs.dnsProvider = id
        if ((id == "nextdns" && prefs.nextDnsId.isBlank()) || (id == "custom" && prefs.customDohUrl.isBlank())) {
            applyAndRebuild()
            UiUtil.toast(this, "Informe os dados do provedor para ativar")
        } else applyAndRebuild()
    }

    private fun applyAndRebuild() {
        lifecycleScope.launch {
            DnsManager.apply(this@DnsActivity, prefs)
            rebuild()
        }
    }

    private fun runTest(host: String) {
        UiUtil.toast(this, "Testando…")
        lifecycleScope.launch {
            val r = DnsManager.test(host)
            MaterialAlertDialogBuilder(this@DnsActivity).setTitle("Resultado").setMessage(r)
                .setPositiveButton(android.R.string.ok, null).show()
        }
    }
}
