package com.troy.browser.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.net.Uri
import java.io.File
import kotlin.math.max

/** Papéis de parede gerados em código (gradientes com brilhos suaves), sem imagens embutidas. */
object Wallpapers {
    class Orb(val x: Float, val y: Float, val r: Float, val color: Int)
    class Spec(val id: String, val label: String, val colors: IntArray, val orbs: List<Orb>)

    val presets: List<Spec> = listOf(
        Spec("aurora", "Aurora", intArrayOf(0xFF06141F.toInt(), 0xFF0B3B3A.toInt()), listOf(Orb(0.2f, 0.25f, 0.6f, 0x6637E6B0), Orb(0.85f, 0.65f, 0.65f, 0x663C7BFF))),
        Spec("nebulosa", "Nebulosa", intArrayOf(0xFF0B1030.toInt(), 0xFF1B2A6B.toInt()), listOf(Orb(0.8f, 0.15f, 0.7f, 0x667A8CFF), Orb(0.15f, 0.8f, 0.6f, 0x4436C5F0))),
        Spec("oceano", "Oceano", intArrayOf(0xFF021B2B.toInt(), 0xFF0A5C73.toInt()), listOf(Orb(0.5f, 0.95f, 0.8f, 0x6638D4E8), Orb(0.1f, 0.1f, 0.5f, 0x3340A0FF))),
        Spec("poente", "Pôr do sol", intArrayOf(0xFF2B1030.toInt(), 0xFFB5452F.toInt()), listOf(Orb(0.5f, 1.0f, 0.85f, 0x88FFB35C.toInt()), Orb(0.1f, 0.1f, 0.55f, 0x55FF5C8A.toInt()))),
        Spec("floresta", "Floresta", intArrayOf(0xFF06180F.toInt(), 0xFF1F5A3B.toInt()), listOf(Orb(0.75f, 0.25f, 0.6f, 0x5547E08A), Orb(0.1f, 0.9f, 0.6f, 0x3328B0A0))),
        Spec("carvao", "Carvão", intArrayOf(0xFF0E0F12.toInt(), 0xFF2C3038.toInt()), listOf(Orb(0.8f, 0.2f, 0.55f, 0x33FFFFFF), Orb(0.2f, 0.85f, 0.5f, 0x22FFFFFF))),
        Spec("neon", "Neon", intArrayOf(0xFF1A0820.toInt(), 0xFF4A1450.toInt()), listOf(Orb(0.2f, 0.8f, 0.65f, 0x66FF4FA3), Orb(0.9f, 0.2f, 0.55f, 0x5536C5F0))),
        Spec("ouro", "Ouro", intArrayOf(0xFF1A1206.toInt(), 0xFF6B4E12.toInt()), listOf(Orb(0.5f, 0.2f, 0.65f, 0x66FFD36B))),
        Spec("gelo", "Gelo", intArrayOf(0xFF0C1A2E.toInt(), 0xFF3A6EA5.toInt()), listOf(Orb(0.2f, 0.2f, 0.65f, 0x66BFE3FF), Orb(0.9f, 0.85f, 0.5f, 0x4457A6FF))),
        Spec("vinho", "Vinho", intArrayOf(0xFF1A070D.toInt(), 0xFF6B1B34.toInt()), listOf(Orb(0.8f, 0.8f, 0.7f, 0x66FF6B8B), Orb(0.1f, 0.15f, 0.5f, 0x33FFB36B))),
    )

    fun spec(id: String?): Spec? = presets.firstOrNull { it.id == id }

    class WallpaperDrawable(private val spec: Spec) : Drawable() {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val orbPaint = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun draw(canvas: Canvas) {
            val b = bounds
            if (b.isEmpty) return
            val w = b.width().toFloat(); val h = b.height().toFloat()
            paint.shader = LinearGradient(b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.bottom.toFloat(), spec.colors, null, Shader.TileMode.CLAMP)
            canvas.drawRect(b, paint)
            val side = max(w, h)
            for (o in spec.orbs) {
                val cx = b.left + o.x * w; val cy = b.top + o.y * h; val r = o.r * side
                orbPaint.shader = RadialGradient(cx, cy, r, o.color, o.color and 0x00FFFFFF, Shader.TileMode.CLAMP)
                canvas.drawRect(b, orbPaint)
            }
        }
        override fun setAlpha(alpha: Int) { paint.alpha = alpha; orbPaint.alpha = alpha }
        override fun setColorFilter(cf: ColorFilter?) { paint.colorFilter = cf; orbPaint.colorFilter = cf }
        @Deprecated("Deprecated in Java") override fun getOpacity() = PixelFormat.TRANSLUCENT
    }

    fun drawable(id: String?): Drawable? = spec(id)?.let { WallpaperDrawable(it) }

    /** Importa uma imagem da galeria reduzindo para no máximo ~1600 px, e devolve o arquivo salvo. */
    fun importFromGallery(context: Context, uri: Uri): File? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp: Bitmap? = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        if (bmp == null) null else {
            context.filesDir.listFiles { f -> f.name.startsWith("wallpaper_") }?.forEach { it.delete() }
            val out = File(context.filesDir, "wallpaper_${System.currentTimeMillis()}.jpg")
            out.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            bmp.recycle()
            out
        }
    } catch (e: Exception) { null }
}
