package com.troy.browser.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.troy.browser.R

/** Itens do menu principal (⋮): linhas com ícone e separadores. */
sealed class MenuModel {
    class Row(
        val icon: Int,
        val label: String,
        val sub: String? = null,
        val checked: Boolean = false,
        val action: () -> Unit,
    ) : MenuModel()

    object Divider : MenuModel()
}

class PopupMenuAdapter(
    private val items: List<MenuModel>,
    private val dismiss: () -> Unit,
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    class RowVH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.rowIcon)
        val label: TextView = v.findViewById(R.id.rowLabel)
        val sub: TextView = v.findViewById(R.id.rowSub)
        val check: ImageView = v.findViewById(R.id.rowCheck)
    }

    class DividerVH(v: View) : RecyclerView.ViewHolder(v)

    override fun getItemCount() = items.size
    override fun getItemViewType(position: Int) = if (items[position] is MenuModel.Divider) 1 else 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == 1) DividerVH(inflater.inflate(R.layout.item_menu_divider, parent, false))
        else RowVH(inflater.inflate(R.layout.item_menu_row, parent, false))
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val row = items[position] as? MenuModel.Row ?: return
        val h = holder as RowVH
        h.icon.setImageResource(row.icon)
        h.label.text = row.label
        h.sub.visibility = if (row.sub.isNullOrBlank()) View.GONE else View.VISIBLE
        h.sub.text = row.sub
        h.check.visibility = if (row.checked) View.VISIBLE else View.GONE
        h.itemView.setOnClickListener { dismiss(); row.action() }
    }
}
