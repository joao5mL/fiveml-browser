package com.troy.browser.storage

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import java.io.File

/** Publica arquivos finais em Movies/Troy Browser (vídeo/áudio) ou Download/Troy Browser (demais) via MediaStore. */
object MediaStorage {

    fun tempDir(context: Context): File =
        File(context.getExternalFilesDir(null) ?: context.filesDir, "tmp").apply { mkdirs() }

    fun mimeFor(fileName: String, fallback: String?): String {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
            ?: fallback?.takeIf { it.contains('/') && !it.contains("octet") }
            ?: "application/octet-stream"
    }

    /** Move o arquivo validado para o destino público e devolve o Uri final. */
    fun publish(context: Context, source: File, fileName: String, mime: String): Uri {
        require(source.exists() && source.length() > 0) { "Arquivo de origem inexistente ou vazio" }
        val isVideo = mime.startsWith("video/")
        val isAudio = mime.startsWith("audio/")
        val resolver = context.contentResolver

        if (Build.VERSION.SDK_INT >= 29) {
            val collection = when {
                isVideo -> MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                isAudio -> MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                else -> MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            }
            val relative = when {
                isVideo -> Environment.DIRECTORY_MOVIES + "/Troy Browser"
                isAudio -> Environment.DIRECTORY_MUSIC + "/Troy Browser"
                else -> Environment.DIRECTORY_DOWNLOADS + "/Troy Browser"
            }
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, uniqueName(context, collection, relative, fileName))
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, relative)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = resolver.insert(collection, values) ?: error("MediaStore recusou criar o arquivo")
            try {
                resolver.openOutputStream(uri)?.use { out -> source.inputStream().use { it.copyTo(out, 256 * 1024) } }
                    ?: error("Não foi possível abrir o destino para gravação")
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                resolver.update(uri, done, null, null)
            } catch (e: Exception) {
                runCatching { resolver.delete(uri, null, null) }
                throw e
            }
            source.delete()
            return uri
        } else {
            val base = when {
                isVideo -> Environment.DIRECTORY_MOVIES
                isAudio -> Environment.DIRECTORY_MUSIC
                else -> Environment.DIRECTORY_DOWNLOADS
            }
            val dir = File(Environment.getExternalStoragePublicDirectory(base), "Troy Browser").apply { mkdirs() }
            val dest = File(dir, com.troy.browser.util.FileNames.unique(fileName) { File(dir, it).exists() })
            source.copyTo(dest, overwrite = false)
            source.delete()
            android.media.MediaScannerConnection.scanFile(context, arrayOf(dest.absolutePath), arrayOf(mime), null)
            return Uri.fromFile(dest)
        }
    }

    private fun uniqueName(context: Context, collection: Uri, relative: String, name: String): String =
        com.troy.browser.util.FileNames.unique(name) { candidate ->
            context.contentResolver.query(
                collection, arrayOf(MediaStore.MediaColumns._ID),
                "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH}=?",
                arrayOf(candidate, "$relative/"), null
            )?.use { it.count > 0 } ?: false
        }

    fun exists(context: Context, uri: Uri): Boolean = try {
        context.contentResolver.openFileDescriptor(uri, "r")?.use { it.statSize != 0L } ?: false
    } catch (e: Exception) { false }

    fun size(context: Context, uri: Uri): Long = try {
        context.contentResolver.openFileDescriptor(uri, "r")?.use { it.statSize } ?: -1
    } catch (e: Exception) { -1 }

    fun delete(context: Context, uri: Uri): Boolean = try {
        if (uri.scheme == "file") File(uri.path!!).delete() else context.contentResolver.delete(uri, null, null) > 0
    } catch (e: Exception) { false }
}
