package com.troy.browser.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.card.MaterialCardView
import com.troy.browser.R
import com.troy.browser.tabs.Tab

/** Grade de abas em cartões (favicon, título, fechar e miniatura). A aba ativa fica destacada. */
class TabAdapter(
    private val tabs: List<Tab>,
    private val current: Tab?,
    private val onSelect: (Tab) -> Unit,
    private val onClose: (Tab) -> Unit,
) : RecyclerView.Adapter<TabAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val card: MaterialCardView = v.findViewById(R.id.tabCard)
        val preview: ImageView = v.findViewById(R.id.tabPreview)
        val placeholder: ImageView = v.findViewById(R.id.tabPlaceholder)
        val icon: ImageView = v.findViewById(R.id.tabIcon)
        val title: TextView = v.findViewById(R.id.tabTitle)
        val close: ImageButton = v.findViewById(R.id.tabClose)
    }

    override fun getItemCount() = tabs.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_tab, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val tab = tabs[position]
        val ctx = h.itemView.context
        val active = tab === current
        val accent = UiUtil.attr(ctx, R.attr.trAccent)
        val elevated = UiUtil.attr(ctx, R.attr.trSurfaceElevated)
        val border = UiUtil.attr(ctx, R.attr.trBorder)
        val textP = UiUtil.attr(ctx, R.attr.trTextPrimary)
        val density = ctx.resources.displayMetrics.density

        h.card.setCardBackgroundColor(if (active) ColorUtils.blendARGB(elevated, accent, 0.38f) else elevated)
        h.card.strokeColor = if (active) accent else border
        h.card.strokeWidth = ((if (active) 2 else 1) * density).toInt()

        h.title.text = when {
            tab.isHome && tab.isPrivate -> "Aba privada"
            else -> tab.displayTitle("Nova aba")
        }

        val fav = tab.favicon
        if (fav != null && !tab.isPrivate) { h.icon.clearColorFilter(); h.icon.setImageBitmap(fav) }
        else {
            h.icon.setImageResource(if (tab.isPrivate) R.drawable.ic_incognito else if (tab.isHome) R.drawable.ic_home else R.drawable.ic_globe)
            h.icon.setColorFilter(textP)
        }

        val prev = tab.preview
        if (!tab.isPrivate && !tab.isHome && prev != null && !prev.isRecycled) {
            h.preview.setImageBitmap(prev)
            h.preview.visibility = View.VISIBLE
            h.placeholder.visibility = View.GONE
        } else {
            h.preview.setImageDrawable(null)
            h.preview.visibility = View.GONE
            h.placeholder.visibility = View.VISIBLE
            h.placeholder.setImageResource(if (tab.isPrivate) R.drawable.ic_incognito else if (tab.isHome) R.drawable.ic_home else R.drawable.ic_globe)
        }

        h.itemView.setOnClickListener { onSelect(tab) }
        h.close.setOnClickListener { onClose(tab) }
    }
}
