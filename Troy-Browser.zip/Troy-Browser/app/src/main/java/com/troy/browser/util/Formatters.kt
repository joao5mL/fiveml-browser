package com.troy.browser.util

import java.text.DateFormat
import java.util.Date
import java.util.Locale

object Formatters {
    fun size(bytes: Long): String {
        if (bytes < 0) return "—"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        var v = bytes.toDouble()
        var i = 0
        while (v >= 1024 && i < units.lastIndex) { v /= 1024; i++ }
        return if (i == 0) "${bytes} B" else String.format(Locale.getDefault(), "%.1f %s", v, units[i])
    }

    fun speed(bytesPerSec: Long): String = if (bytesPerSec <= 0) "" else size(bytesPerSec) + "/s"

    fun eta(seconds: Long): String {
        if (seconds < 0) return ""
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val s = seconds % 60
        return when {
            h > 0 -> "${h}h ${m}min"
            m > 0 -> "${m}min ${s}s"
            else -> "${s}s"
        }
    }

    fun date(ms: Long): String =
        DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(ms))
}
