package com.troy.browser.downloads

import com.troy.browser.data.DownloadEntity
import com.troy.browser.util.Net
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.net.URI

/**
 * Baixa mídia HLS sem criptografia: lê o manifesto, escolhe a melhor variante, baixa todos os
 * segmentos e gera um único arquivo reproduzível. Conteúdo com EXT-X-KEY (DRM/AES) é recusado.
 */
class HlsDownloader {

    class Segment(val url: String, val duration: Double)
    class MediaPlaylist(val segments: List<Segment>, val initUrl: String?, val isFmp4: Boolean, val isLive: Boolean)
    class Variant(val url: String, val bandwidth: Long, val audioGroup: String?)

    class Result(val file: File, val totalBytes: Long)

    suspend fun download(
        item: DownloadEntity,
        workDir: File,
        cookie: String?,
        userAgent: String,
        onProgress: (done: Int, total: Int, bytes: Long) -> Unit,
    ): Result {
        workDir.mkdirs()
        val masterText = fetchText(item.url, item.pageUrl, cookie, userAgent)
        if (!masterText.trimStart().startsWith("#EXTM3U")) throw DownloadFailure("O endereço não é um manifesto HLS válido")

        var videoPlaylistUrl = item.url
        var audioPlaylistUrl: String? = null
        if (masterText.contains("#EXT-X-STREAM-INF")) {
            val variants = parseVariants(masterText, item.url)
            val best = variants.maxByOrNull { it.bandwidth } ?: throw DownloadFailure("Manifesto sem variantes de vídeo")
            videoPlaylistUrl = best.url
            audioPlaylistUrl = best.audioGroup?.let { findAudio(masterText, it, item.url) }
        }

        val videoFile = downloadStream(videoPlaylistUrl, item, File(workDir, "video"), cookie, userAgent, 0.0, if (audioPlaylistUrl != null) 0.85 else 1.0, onProgress)
        var audioFile: File? = null
        if (audioPlaylistUrl != null) {
            audioFile = downloadStream(audioPlaylistUrl, item, File(workDir, "audio"), cookie, userAgent, 0.85, 1.0, onProgress)
        }

        val out = File(workDir, "final.mp4")
        val inputs = listOfNotNull(videoFile, audioFile)
        Remuxer.remux(inputs, out)
        inputs.forEach { it.delete() }
        return Result(out, out.length())
    }

    private var totalSegmentsAll = 0

    private suspend fun downloadStream(
        playlistUrl: String, item: DownloadEntity, base: File, cookie: String?, ua: String,
        from: Double, to: Double, onProgress: (Int, Int, Long) -> Unit,
    ): File {
        val text = fetchText(playlistUrl, item.pageUrl, cookie, ua)
        val pl = parseMedia(text, playlistUrl)
        if (pl.isLive) throw DownloadFailure("Transmissão ao vivo não pode ser baixada como arquivo completo")
        if (pl.segments.isEmpty()) throw DownloadFailure("Manifesto sem segmentos")
        val out = File(base.path + if (pl.isFmp4) ".mp4" else ".ts")
        out.delete()
        var bytes = 0L
        FileOutputStream(out).use { fos ->
            pl.initUrl?.let { bytes += copyTo(it, fos, item.pageUrl, cookie, ua) }
            pl.segments.forEachIndexed { i, seg ->
                currentCoroutineContext().ensureActive()
                bytes += copyTo(seg.url, fos, item.pageUrl, cookie, ua)
                val frac = from + (to - from) * (i + 1) / pl.segments.size
                onProgress((frac * 1000).toInt(), 1000, bytes)
            }
            fos.flush(); fos.fd.sync()
        }
        if (out.length() == 0L) throw DownloadFailure("Nenhum dado de mídia recebido")
        return out
    }

    private fun copyTo(url: String, out: FileOutputStream, referer: String?, cookie: String?, ua: String): Long {
        repeat(3) { attempt ->
            try {
                val resp = Net.client.newCall(req(url, referer, cookie, ua)).execute()
                resp.use {
                    if (!it.isSuccessful) throw DownloadFailure("Segmento indisponível (HTTP ${it.code})", retryable = it.code >= 500)
                    val body = it.body ?: throw DownloadFailure("Segmento vazio")
                    val ct = it.header("Content-Type")?.lowercase().orEmpty()
                    if (ct.startsWith("text/html")) throw DownloadFailure("Segmento retornou HTML (link expirado ou protegido)")
                    var n = 0L
                    body.byteStream().use { input ->
                        val buf = ByteArray(64 * 1024)
                        while (true) { val r = input.read(buf); if (r < 0) break; out.write(buf, 0, r); n += r }
                    }
                    return n
                }
            } catch (e: DownloadFailure) { if (!e.retryable || attempt == 2) throw e }
            catch (e: java.io.IOException) { if (attempt == 2) throw DownloadFailure("Falha de rede em segmento: ${e.message}", true) }
        }
        throw DownloadFailure("Falha ao baixar segmento")
    }

    private fun req(url: String, referer: String?, cookie: String?, ua: String): Request {
        val b = Request.Builder().url(url).header("User-Agent", ua).header("Accept-Encoding", "identity")
        referer?.let { b.header("Referer", it) }
        cookie?.takeIf { it.isNotBlank() }?.let { b.header("Cookie", it) }
        return b.build()
    }

    private fun fetchText(url: String, referer: String?, cookie: String?, ua: String): String =
        Net.client.newCall(req(url, referer, cookie, ua)).execute().use {
            if (!it.isSuccessful) throw DownloadFailure("Manifesto indisponível (HTTP ${it.code})")
            it.body?.string() ?: throw DownloadFailure("Manifesto vazio")
        }

    companion object {
        fun resolve(base: String, ref: String): String = URI(base).resolve(ref.trim()).toString()

        fun parseVariants(text: String, base: String): List<Variant> {
            val lines = text.lines().map { it.trim() }
            val out = mutableListOf<Variant>()
            for (i in lines.indices) {
                if (!lines[i].startsWith("#EXT-X-STREAM-INF")) continue
                val bw = Regex("""BANDWIDTH=(\d+)""").find(lines[i])?.groupValues?.get(1)?.toLongOrNull() ?: 0L
                val audio = Regex("""AUDIO="([^"]+)"""").find(lines[i])?.groupValues?.get(1)
                var j = i + 1
                while (j < lines.size && (lines[j].isEmpty() || lines[j].startsWith("#"))) j++
                if (j < lines.size) out += Variant(resolve(base, lines[j]), bw, audio)
            }
            return out
        }

        fun findAudio(text: String, group: String, base: String): String? =
            text.lines().map { it.trim() }.filter { it.startsWith("#EXT-X-MEDIA") && it.contains("TYPE=AUDIO") && it.contains("GROUP-ID=\"$group\"") }
                .mapNotNull { Regex("""URI="([^"]+)"""").find(it)?.groupValues?.get(1) }
                .firstOrNull()?.let { resolve(base, it) }

        fun parseMedia(text: String, base: String): MediaPlaylist {
            val segs = mutableListOf<Segment>()
            var initUrl: String? = null
            var dur = 0.0
            var ended = false
            var fmp4 = false
            for (raw in text.lines()) {
                val line = raw.trim()
                when {
                    line.startsWith("#EXT-X-KEY") && !line.contains("METHOD=NONE") ->
                        throw DownloadFailure("Conteúdo protegido por criptografia/DRM. O Troy Browser não baixa mídia protegida.")
                    line.startsWith("#EXT-X-MAP") -> {
                        Regex("""URI="([^"]+)"""").find(line)?.groupValues?.get(1)?.let { initUrl = resolve(base, it); fmp4 = true }
                    }
                    line.startsWith("#EXTINF") -> dur = line.substringAfter(':').substringBefore(',').toDoubleOrNull() ?: 0.0
                    line.startsWith("#EXT-X-ENDLIST") -> ended = true
                    line.isNotEmpty() && !line.startsWith("#") -> {
                        segs += Segment(resolve(base, line), dur)
                        if (line.substringBefore('?').endsWith(".m4s") || line.substringBefore('?').endsWith(".mp4")) fmp4 = true
                    }
                }
            }
            return MediaPlaylist(segs, initUrl, fmp4, isLive = !ended)
        }
    }
}
