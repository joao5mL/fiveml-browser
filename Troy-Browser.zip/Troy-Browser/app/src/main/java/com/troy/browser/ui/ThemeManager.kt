package com.troy.browser.ui

import android.app.Activity
import android.content.Context
import com.troy.browser.TroyApp
import com.troy.browser.R

/** Temas do app. Cada tema é um style com atributos de cor (fv*) e um gradiente de fundo. */
object ThemeManager {
    class Info(val id: String, val label: String, val styleRes: Int, val bg: Int, val accent: Int, val gradStart: Int, val gradEnd: Int)

    val all: List<Info> = listOf(
        Info("midnight", "Meia-noite", R.style.Theme_Troy, 0xFF0F1424.toInt(), 0xFF7FA8FF.toInt(), 0xFF0C1020.toInt(), 0xFF22345C.toInt()),
        Info("ocean", "Oceano", R.style.Theme_Troy_Ocean, 0xFF071C27.toInt(), 0xFF4FD1E0.toInt(), 0xFF051821.toInt(), 0xFF0F5566.toInt()),
        Info("aurora", "Aurora", R.style.Theme_Troy_Aurora, 0xFF08211B.toInt(), 0xFF5EEAB0.toInt(), 0xFF061A15.toInt(), 0xFF14604F.toInt()),
        Info("sunset", "Pôr do sol", R.style.Theme_Troy_Sunset, 0xFF261022.toInt(), 0xFFFF9E6B.toInt(), 0xFF220D1E.toInt(), 0xFF95402E.toInt()),
        Info("graphite", "Grafite", R.style.Theme_Troy_Graphite, 0xFF121315.toInt(), 0xFFD0D5DE.toInt(), 0xFF0F1012.toInt(), 0xFF2F333A.toInt()),
        Info("crimson", "Carmesim", R.style.Theme_Troy_Crimson, 0xFF1A0B0E.toInt(), 0xFFFF6B7D.toInt(), 0xFF160709.toInt(), 0xFF64192A.toInt()),
        Info("gold", "Dourado", R.style.Theme_Troy_Gold, 0xFF1A1408.toInt(), 0xFFF5C84C.toInt(), 0xFF151006.toInt(), 0xFF58441A.toInt()),
        Info("light", "Claro", R.style.Theme_Troy_Light, 0xFFF4F6FA.toInt(), 0xFF2F5FD0.toInt(), 0xFFF9FBFF.toInt(), 0xFFDCE5F7.toInt()),
    )

    const val DEFAULT_ID = "midnight"

    fun info(id: String): Info = all.firstOrNull { it.id == id } ?: all.first()

    /** Aplica o tema salvo. Deve ser chamado antes de super.onCreate(). Retorna o id aplicado. */
    fun apply(activity: Activity): String {
        val id = TroyApp.instance.prefs.themeId
        activity.setTheme(info(id).styleRes)
        return info(id).id
    }

    fun changed(context: Context, applied: String): Boolean =
        TroyApp.instance.prefs.themeId.let { info(it).id != applied }
}
