package com.troy.browser.ui

import android.content.Intent
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.troy.browser.R
import com.troy.browser.net.DnsManager
import com.troy.browser.util.Formatters
import kotlinx.coroutines.launch

/** Tela do bloqueador de anúncios: estado, estatísticas, exceção do site atual, listas e DNS. */
class AdBlockActivity : ListPageActivity() {
    private val host: String? get() = intent.getStringExtra(EXTRA_HOST)

    override fun pageTitle() = "Bloqueador de anúncios"

    override fun build() {
        val blocker = app.adBlocker
        val h = host

        statusCard(
            R.drawable.ic_shield, blocker.enabled,
            if (blocker.enabled) "Proteção ativa" else "Proteção desativada",
            if (blocker.enabled) "Anúncios${if (blocker.trackersEnabled) " e rastreadores" else ""} bloqueados nas páginas"
            else "As páginas carregam sem nenhum filtro",
        )
        switchRow("Bloqueador de anúncios", "Bloqueia redes de anúncios conhecidas", blocker.enabled) {
            prefs.adBlockEnabled = it; blocker.notifyChanged(); rebuild()
        }

        statsCard(listOf(
            "Nesta sessão" to blocker.sessionBlocked.toString(),
            "Anúncios" to blocker.sessionAdsBlocked.toString(),
            "Rastreadores" to blocker.sessionTrackersBlocked.toString(),
            "Total" to blocker.totalBlocked.toString(),
        ))

        if (h != null) {
            section("Site atual")
            val allowed = blocker.isAllowedSite(h)
            switchRow("Bloquear neste site", h + if (allowed) " — liberado, sem bloqueio" else "", !allowed) { on ->
                blocker.setSiteAllowed(h, !on)
                content.postDelayed({ rebuild() }, 300)
            }
        }

        section("Proteções")
        switchRow("Bloquear rastreadores", "Analytics, pixels e telemetria de audiência", prefs.blockTrackers) {
            prefs.blockTrackers = it; blocker.notifyChanged(); rebuild()
        }
        info("Vídeos nunca são bloqueados",
            "Arquivos de vídeo, áudio, HLS e DASH, legendas e recursos do próprio site passam sempre. O Troy não esconde nem remove elementos das páginas, então o player não desaparece.")

        section("Listas de filtros")
        val updated = if (prefs.filterListUpdatedAt == 0L) "Lista padrão" else "Atualizada em ${Formatters.date(prefs.filterListUpdatedAt)}"
        row("Atualizar lista de anúncios", "${blocker.adHostCount} domínios de anúncios · ${blocker.trackerHostCount} de rastreadores\n$updated", R.drawable.ic_refresh) {
            lifecycleScope.launch {
                runCatching { blocker.updateLists() }
                    .onSuccess { UiUtil.toast(this@AdBlockActivity, "Lista atualizada: $it domínios"); rebuild() }
                    .onFailure { UiUtil.toast(this@AdBlockActivity, "Falha ao atualizar: ${it.message}") }
            }
        }

        section("Rede")
        val dns = DnsManager.state
        row("DNS privado", if (dns.active) "Ativo · ${dns.label}" else "Desligado — use AdGuard ou NextDNS para filtrar anúncios em toda a rede",
            R.drawable.ic_dns, chevron = true) { startActivity(Intent(this, DnsActivity::class.java)) }

        section("Sites com exceção")
        val sites = blocker.allowedSites()
        if (sites.isEmpty()) info("Nenhum site liberado", "Se um site não funcionar direito, abra-o e desative \"Bloquear neste site\".")
        else sites.forEach { site ->
            row(site, "Toque para voltar a bloquear", R.drawable.ic_close_circle) {
                UiUtil.confirm(this, "Remover exceção", "Voltar a bloquear anúncios em $site?", "Remover") {
                    blocker.setSiteAllowed(site, false)
                    content.postDelayed({ rebuild() }, 300)
                }
            }
        }
    }

    companion object { const val EXTRA_HOST = "host" }
}
