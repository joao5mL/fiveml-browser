# Troy Browser

Navegador Android nativo (Kotlin) com motor Android WebView (Chromium), interface Material 3, gerenciador de downloads próprio e player Media3.

## Interface

- **Barra superior:** endereço com ícone de segurança, escudo do bloqueador, contador de abas e menu ⋮. A barra inferior (voltar, avançar, início) é opcional em Configurações › Aparência e menu.
- **Menu ⋮:** ações rápidas (avançar, favoritar, baixar vídeo, compartilhar, atualizar/parar) e lista organizada. Cada item abre sua própria tela.
- **Abas:** seletor em tela cheia, grade de cartões com miniatura, busca nas abas, alternância normais/privadas. Abas privadas nunca geram miniatura.
- **Temas:** 8 temas com fundo em gradiente, papel de parede (prontos ou da galeria) e opacidade.

## Módulos

| Pacote | Responsabilidade |
|---|---|
| `ui` | Navegador, página inicial, menu, abas, Downloads, Histórico, Favoritos, Configurações, Bloqueador, DNS |
| `tabs` | Abas normais/privadas e restauração de sessão |
| `downloads` | Motor HTTP (OkHttp, streaming, Range), HLS, validação, fila e serviço em primeiro plano |
| `player` | Detecção de mídia, identificação do título e player Media3 |
| `adblock` | Bloqueio de anúncios e rastreadores, exceções por site |
| `net` | DNS privado (DoH) e proxy local para o WebView |
| `notify` | Canais e notificações de downloads |
| `storage` | MediaStore (`Movies/Troy Browser`, `Music/Troy Browser`, `Download/Troy Browser`) |
| `data` | Room: downloads, histórico, favoritos, pesquisas e exceções |

## Bloqueador de anúncios

Listas separadas para anúncios (`assets/filters_ads.txt`, atualizável) e rastreadores (`assets/filters_trackers.txt`). Nunca bloqueia o documento principal, mídia (mp4, webm, m3u8, mpd, segmentos, áudio), requisições de vídeo/áudio nem recursos do próprio domínio da página. Não aplica filtros cosméticos. Requisições bloqueadas recebem resposta vazia coerente com o tipo (GIF 1×1, script/CSS vazio, 204). Exceção por site disponível.

## DNS privado

DNS sobre HTTPS com Cloudflare, Google, Quad9, AdGuard, Mullvad, NextDNS (ID da conta) ou endereço personalizado. Aplica-se às conexões do app (downloads, sugestões, player) e, quando o WebView suporta `PROXY_OVERRIDE`, às páginas por meio de um proxy local em 127.0.0.1 que resolve os nomes pelo provedor. Se o WebView não suportar, a tela informa que só downloads e player são cobertos.

## Downloads

- Escrita progressiva em arquivo temporário, sem carregar arquivos inteiros na memória.
- Pausa/retomada com `Range` quando o servidor suporta.
- Conclusão somente após transferência completa, tamanho coerente, arquivo não vazio e validação estrutural (MP4/MOV: `ftyp`, `moov`, `mdat`; WebM/MKV: EBML; respostas HTML/JSON/texto são rejeitadas).
- HLS sem criptografia: manifesto → melhor variante → segmentos → remux para MP4. Conteúdo com `EXT-X-KEY`, transmissões ao vivo e DASH não são baixados.

## Nome do arquivo

Título obtido na ordem: atributos do `<video>`, `figcaption`, legenda/descrição visível próxima ao player, `og:title`/`twitter:title`, JSON-LD, `h1` do conteúdo e título da página. Textos ocultos, de acessibilidade, modais e banners são descartados. Nomes repetidos recebem sufixo numérico.

## Build

JDK 17, Gradle 8.9, Android Gradle Plugin 8.5.2, Kotlin 1.9.24.

```
gradle wrapper --gradle-version 8.9
./gradlew assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`. O workflow `.github/workflows/build.yml` gera `Troy-Browser.apk`.
