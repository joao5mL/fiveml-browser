# FivemL Browser — GitHub Actions

Este projeto usa GitHub Actions para gerar o APK Debug.

## Como enviar

O workflow `.github/workflows/android.yml` aceita estas duas formas:

1. Enviar o conteúdo extraído do projeto para a raiz do repositório; ou
2. Enviar o arquivo ZIP do projeto diretamente para a raiz do repositório.

O workflow procura automaticamente `settings.gradle.kts`/`settings.gradle`, inclusive dentro de uma pasta extraída ou do ZIP, e executa `:app:assembleDebug` no diretório correto.

## Baixar o APK

Abra **Actions**, selecione a execução concluída e baixe o artefato `FivemL-Browser-debug`.

O artefato só será publicado se a compilação terminar com sucesso.
