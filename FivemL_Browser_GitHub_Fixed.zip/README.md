# FivemL Browser

Projeto Android nativo em Kotlin.

## Gerar APK pelo GitHub Actions

1. Envie o conteúdo deste projeto para a raiz de um repositório GitHub (a pasta `app` deve ficar ao lado de `build.gradle.kts` e `settings.gradle.kts`).
2. Abra a aba **Actions** do repositório.
3. Execute **Android APK** em **Run workflow**, ou faça um push na branch.
4. Quando o job terminar com sucesso, abra a execução e baixe o artefato **FivemL-Browser-debug**.
5. Extraia o ZIP do artefato e instale `app-debug.apk` no Android.

O workflow usa JDK 17 e Gradle 8.1.1. Não é necessário enviar uma pasta `build/`.

## Estado das funções

O projeto contém navegador WebView, histórico local com Room, telas de abas e downloads, preferências de desktop/JavaScript, bloqueio simples de domínios de anúncios e detecção de URLs de mídia direta. A detecção por extensão/URL não extrai automaticamente mídia protegida ou incorporada por todas as plataformas; os extractors de API ainda são pontos de extensão e não implementam integração com serviços externos.
