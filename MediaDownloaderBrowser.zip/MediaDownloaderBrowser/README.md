# MediaDownloaderBrowser

Projeto Android nativo em Kotlin/XML. O app detecta requisições de mídia direta e pública (`mp4`, `webm`, `mov`, `m4v`, `mp3`, `m4a`, `ogg`) observadas pelo WebView e baixa URLs diretas com WorkManager + OkHttp.

## Build local
Abra a pasta no Android Studio com JDK 17 e compile `:app:assembleDebug`.

## GitHub Actions
Envie o projeto para um repositório GitHub nas branches `main` ou `master`. Em cada push/PR, o workflow compila `app-debug.apk`. Baixe em **Actions → execução → Artifacts**.

## Limites desta base
- Não extrai nem descriptografa DRM, não contorna autenticação, paywall ou controles de acesso.
- HLS/DASH (`.m3u8`/`.mpd`) não são baixados nesta base. O download é de arquivos diretos.
- Integrações com plataformas devem usar APIs oficiais/autorizadas e respeitar termos, permissões e direitos autorais.
- O detector do WebView observa pedidos; não consegue garantir que todo player exponha uma URL de arquivo.
- Android 13+ pode solicitar permissão de notificações. A ausência dela não impede necessariamente o trabalho, mas reduz a visibilidade da notificação.
- Em Android 15+, trabalhos de sincronização em primeiro plano têm limites de execução do sistema. WorkManager administra a execução e reagendamento.

## Observação
`DownloadService` é intencionalmente um `CoroutineWorker` em foreground, não um `android.app.Service`: para downloads persistentes, WorkManager fornece fila, restrições e recuperação após encerramento do processo.
