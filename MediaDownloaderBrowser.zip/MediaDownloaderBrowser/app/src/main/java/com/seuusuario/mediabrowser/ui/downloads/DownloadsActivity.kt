package com.seuusuario.mediabrowser.ui.downloads

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.seuusuario.mediabrowser.R

class DownloadsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_downloads)
    }
}
