package com.seuusuario.mediabrowser.extractors

/**
 * Ponto de extensão para APIs oficiais/autorizadas.
 * Não implementa scraping de contas, endpoints privados ou contorno de proteções.
 */
class ApiExtractor : BaseExtractor {
    override suspend fun extract(pageUrl: String): List<ExtractedMedia> = emptyList()
}
