package com.seuusuario.mediabrowser.ui.browser

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class BrowserViewModel : ViewModel() {
    private val _detectedMedia = MutableStateFlow<String?>(null)
    val detectedMedia: StateFlow<String?> = _detectedMedia
    fun onMediaDetected(url: String) { _detectedMedia.value = url }
    fun clearDetection() { _detectedMedia.value = null }
}
