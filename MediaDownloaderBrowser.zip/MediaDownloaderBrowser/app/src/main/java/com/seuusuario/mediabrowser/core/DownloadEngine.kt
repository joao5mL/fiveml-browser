package com.seuusuario.mediabrowser.core

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.provider.MediaStore
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import com.seuusuario.mediabrowser.service.DownloadService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.net.URLConnection

class DownloadEngine(private val context: Context, private val client: OkHttpClient = OkHttpClient()) {
    suspend fun download(url: String, onProgress: (Int) -> Unit): String = withContext(Dispatchers.IO) {
        val request = Request.Builder().url(url).header("User-Agent", "MediaDownloaderBrowser/1.0").build()
        client.newCall(request).execute().use { response ->
            check(response.isSuccessful) { "HTTP ${response.code}" }
            val body = response.body ?: error("Resposta vazia")
            val name = safeFileName(url.substringAfterLast('/').substringBefore('?').ifBlank { "media_${System.currentTimeMillis()}" })
            val mime = body.contentType()?.toString() ?: URLConnection.guessContentTypeFromName(name) ?: "application/octet-stream"

            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: error("Não foi possível criar o arquivo")
                try {
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        body.byteStream().use { input -> copyWithProgress(input, out, body.contentLength(), onProgress) }
                    } ?: error("Não foi possível abrir o destino")
                    values.clear()
                    values.put(MediaStore.Downloads.IS_PENDING, 0)
                    context.contentResolver.update(uri, values, null, null)
                } catch (t: Throwable) {
                    context.contentResolver.delete(uri, null, null)
                    throw t
                }
                "Downloads/$name"
            } else {
                val dir = context.getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS)
                    ?: error("Armazenamento indisponível")
                val file = File(dir, name)
                FileOutputStream(file).use { out ->
                    body.byteStream().use { input -> copyWithProgress(input, out, body.contentLength(), onProgress) }
                }
                file.absolutePath
            }
        }
    }

    private fun copyWithProgress(input: java.io.InputStream, output: java.io.OutputStream, total: Long, progress: (Int) -> Unit) {
        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
        var count = 0L
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            output.write(buffer, 0, read)
            count += read
            if (total > 0) progress(((count * 100) / total).toInt().coerceIn(0, 100))
        }
        output.flush()
    }

    private fun safeFileName(raw: String): String =
        raw.replace(Regex("""[\\\\/:*?"<>|]"""), "_").take(120).ifBlank { "media.bin" }
}
