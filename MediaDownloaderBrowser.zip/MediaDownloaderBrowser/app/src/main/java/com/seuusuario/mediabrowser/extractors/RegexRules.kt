package com.seuusuario.mediabrowser.extractors

object RegexRules {
    val MEDIA_EXTENSIONS = Regex("""(?i)\.(mp4|webm|mov|m4v|mp3|m4a|ogg)(?:$|[?#])""")
    val URL_IN_HTML = Regex("""(?i)https?://[^"'\s<>]+\\.(?:mp4|webm|mov|m4v|mp3|m4a)(?:\\?[^"'\s<>]*)?""")
}
