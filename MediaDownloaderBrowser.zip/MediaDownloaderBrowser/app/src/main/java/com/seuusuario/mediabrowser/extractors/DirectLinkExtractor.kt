package com.seuusuario.mediabrowser.extractors

import okhttp3.OkHttpClient
import okhttp3.Request
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class DirectLinkExtractor(
    private val client: OkHttpClient = OkHttpClient()
) : BaseExtractor {
    override suspend fun extract(pageUrl: String): List<ExtractedMedia> = withContext(Dispatchers.IO) {
        val request = Request.Builder().url(pageUrl).header("User-Agent", "MediaDownloaderBrowser/1.0").build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return@withContext emptyList()
            val html = response.body?.string().orEmpty()
            RegexRules.URL_IN_HTML.findAll(html)
                .map { ExtractedMedia(it.value.trimEnd('"', '\\'', ')', ';')) }
                .distinctBy { it.url }.toList()
        }
    }
}
