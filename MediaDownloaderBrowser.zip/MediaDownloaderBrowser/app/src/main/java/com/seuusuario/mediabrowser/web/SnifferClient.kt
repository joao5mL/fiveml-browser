package com.seuusuario.mediabrowser.web

import android.net.Uri
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import com.seuusuario.mediabrowser.extractors.RegexRules
import java.util.concurrent.ConcurrentHashMap

class SnifferClient(private val onMediaFound: (String) -> Unit) : WebViewClient() {
    private val seen = ConcurrentHashMap.newKeySet<String>()

    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
        return false
    }

    override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?) =
        request?.url?.toString()?.let { url ->
            if (isPublicDirectMedia(url) && seen.add(url)) onMediaFound(url)
            null
        }

    private fun isPublicDirectMedia(raw: String): Boolean {
        val uri = runCatching { Uri.parse(raw) }.getOrNull() ?: return false
        if (uri.scheme !in setOf("https", "http")) return false
        return RegexRules.MEDIA_EXTENSIONS.containsMatchIn(uri.path.orEmpty())
    }
}
