package com.seuusuario.mediabrowser.core

/**
 * Reservado para uma futura integração com FFmpeg empacotado/licenciado.
 * Esta versão não mescla streams nem tenta contornar DRM.
 */
class FfmpegWrapper {
    fun isAvailable(): Boolean = false
}
