package com.seuusuario.mediabrowser.extractors

data class ExtractedMedia(val url: String, val title: String? = null, val mimeType: String? = null)

interface BaseExtractor {
    suspend fun extract(pageUrl: String): List<ExtractedMedia>
}
