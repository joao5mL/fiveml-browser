package com.seuusuario.mediabrowser.web

import android.webkit.WebView

/**
 * Encapsula o WebView e publica somente URLs diretas de mídia pública.
 * shouldInterceptRequest observa pedidos; não lê conteúdo protegido nem contorna DRM.
 */
class SnifferWebView(
    val webView: WebView,
    onMediaFound: (String) -> Unit
) {
    init {
        webView.webViewClient = SnifferClient(onMediaFound)
        webView.webChromeClient = android.webkit.WebChromeClient()
    }

    fun loadUrl(url: String) = webView.loadUrl(url)
}
