package com.seuusuario.mediabrowser.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import com.seuusuario.mediabrowser.R
import com.seuusuario.mediabrowser.core.DownloadEngine

/**
 * Worker com execução em primeiro plano (notificação persistente).
 * WorkManager gerencia retomada/reagendamento de forma mais segura que um Service manual.
 */
class DownloadService(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    companion object {
        const val KEY_URL = "download_url"
        private const val CHANNEL_ID = "media_downloads"
        private const val NOTIFICATION_ID = 4102
    }

    override suspend fun doWork(): Result {
        val url = inputData.getString(KEY_URL) ?: return Result.failure()
        return try {
            setForeground(createForegroundInfo(0, "Preparando download"))
            val path = DownloadEngine(applicationContext).download(url) { percent ->
                setProgressAsync(androidx.work.workDataOf("progress" to percent))
                setForegroundAsync(createForegroundInfo(percent, "Baixando $percent%"))
            }
            Result.success(androidx.work.workDataOf("saved_path" to path))
        } catch (e: Exception) {
            Result.failure(androidx.work.workDataOf("error" to (e.message ?: "Falha no download")))
        }
    }

    private fun createForegroundInfo(progress: Int, message: String): ForegroundInfo {
        createChannel()
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("MediaDownloaderBrowser")
            .setContentText(message)
            .setProgress(100, progress, false)
            .setOngoing(progress < 100)
            .setOnlyAlertOnce(true)
            .build()
        return if (Build.VERSION.SDK_INT >= 29) {
            ForegroundInfo(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else ForegroundInfo(NOTIFICATION_ID, notification)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Downloads", NotificationManager.IMPORTANCE_LOW))
        }
    }
}
