package com.seuusuario.mediabrowser.web

/** Bloqueio simples e opcional por hostname; não substitui uma lista de filtros atualizada. */
object AdBlocker {
    private val blockedHosts = setOf("doubleclick.net", "googlesyndication.com", "popads.net")

    fun shouldBlock(url: String): Boolean {
        val host = runCatching { android.net.Uri.parse(url).host }.getOrNull() ?: return false
        return blockedHosts.any { host == it || host.endsWith(".$it") }
    }
}
