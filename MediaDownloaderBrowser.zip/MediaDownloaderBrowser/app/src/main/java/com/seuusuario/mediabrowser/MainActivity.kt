package com.seuusuario.mediabrowser

import android.os.Bundle
import android.webkit.WebView
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
import com.seuusuario.mediabrowser.core.ExtractorManager
import com.seuusuario.mediabrowser.service.DownloadService
import com.seuusuario.mediabrowser.web.SnifferWebView
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var browser: SnifferWebView
    private lateinit var urlInput: EditText
    private lateinit var status: TextView
    private var detectedUrl: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        urlInput = findViewById(R.id.urlInput)
        status = findViewById(R.id.statusText)
        browser = SnifferWebView(findViewById<WebView>(R.id.browserWebView)) { mediaUrl ->
            runOnUiThread {
                detectedUrl = mediaUrl
                status.text = "Mídia detectada: ${mediaUrl.substringAfterLast('/').take(60)}"
                findViewById<ExtendedFloatingActionButton>(R.id.detectButton).isEnabled = true
            }
        }

        findViewById<Button>(R.id.goButton).setOnClickListener {
            val raw = urlInput.text.toString().trim()
            val url = if (raw.startsWith("http://") || raw.startsWith("https://")) raw else "https://$raw"
            browser.loadUrl(url)
        }

        findViewById<ExtendedFloatingActionButton>(R.id.detectButton).setOnClickListener {
            val source = detectedUrl
            if (source == null) {
                status.text = "Nenhum link direto de mídia detectado nesta página."
            } else {
                enqueueDownload(source)
            }
        }

        browser.webView.settings.javaScriptEnabled = true
        browser.webView.settings.domStorageEnabled = true
        browser.webView.settings.mediaPlaybackRequiresUserGesture = true
        browser.webView.loadUrl("https://example.com")
    }

    private fun enqueueDownload(url: String) {
        val request = OneTimeWorkRequestBuilder<DownloadService>()
            .setInputData(workDataOf(DownloadService.KEY_URL to url))
            .build()
        WorkManager.getInstance(this).enqueue(request)
        status.text = "Download adicionado à fila."
    }

    override fun onDestroy() {
        browser.webView.destroy()
        super.onDestroy()
    }
}
