package com.seuusuario.mediabrowser.core

import com.seuusuario.mediabrowser.extractors.ApiExtractor
import com.seuusuario.mediabrowser.extractors.BaseExtractor
import com.seuusuario.mediabrowser.extractors.DirectLinkExtractor
import com.seuusuario.mediabrowser.extractors.ExtractedMedia

class ExtractorManager(
    private val direct: BaseExtractor = DirectLinkExtractor(),
    private val api: BaseExtractor = ApiExtractor()
) {
    suspend fun extract(url: String): List<ExtractedMedia> {
        // Primeiro tenta links diretos públicos. Integrações de plataforma exigem APIs oficiais.
        return direct.extract(url).ifEmpty { api.extract(url) }
    }
}
