package com.seuusuario.mediabrowser.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "downloads")
data class DownloadItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val sourceUrl: String,
    val destination: String? = null,
    val status: String = "queued",
    val progress: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)
