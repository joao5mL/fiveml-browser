package com.fiveml.browser.util

import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

object Net {
    const val USER_AGENT =
        "Mozilla/5.0 (Linux; Android 15; RMX3710) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/126.0.0.0 Mobile Safari/537.36"

    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .build()
    }
}
