package com.fiveml.browser.downloads

import android.util.Log
import com.fiveml.browser.data.DownloadEntity
import com.fiveml.browser.util.Net
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile

class DownloadFailure(message: String, val retryable: Boolean = false) : IOException(message)

/** Transferência HTTP em streaming, com Range para retomar e escrita progressiva em disco. */
class DownloadEngine(private val speedLimitBytesPerSec: () -> Long) {

    data class Progress(val received: Long, val total: Long, val bytesPerSec: Long)
    class Outcome(val received: Long, val total: Long, val supportsRange: Boolean, val etag: String?, val mime: String?, val disposition: String?)

    suspend fun download(
        item: DownloadEntity,
        target: File,
        cookie: String?,
        userAgent: String,
        onProgress: (Progress) -> Unit,
    ): Outcome {
        target.parentFile?.mkdirs()
        var resumeFrom = if (target.exists() && item.supportsRange) target.length() else 0L
        if (resumeFrom == 0L && target.exists()) target.delete()

        val builder = Request.Builder().url(item.url)
            .header("User-Agent", userAgent)
            .header("Accept", "*/*")
            .header("Accept-Encoding", "identity")
        cookie?.takeIf { it.isNotBlank() }?.let { builder.header("Cookie", it) }
        item.pageUrl?.let {
            builder.header("Referer", it)
            runCatching { java.net.URI(it) }.getOrNull()?.let { u ->
                if (u.scheme != null && u.host != null) builder.header("Origin", "${u.scheme}://${u.host}")
            }
        }
        if (resumeFrom > 0) {
            builder.header("Range", "bytes=$resumeFrom-")
            item.etag?.let { builder.header("If-Range", it) }
        }

        val call = Net.client.newCall(builder.build())
        val cancelHandle = currentCoroutineContext()[Job]?.invokeOnCompletion { if (it != null) call.cancel() }
        try { return call.execute().use { resp ->
            val code = resp.code
            if (code == 416) {
                // Servidor diz que o intervalo não é satisfatório: reinicia do zero
                target.delete()
                throw DownloadFailure("Servidor recusou a retomada; reiniciando", retryable = true)
            }
            if (code !in 200..299) {
                throw DownloadFailure(
                    when (code) {
                        401, 403 -> "Acesso negado pelo servidor (HTTP $code). O link pode ter expirado"
                        404, 410 -> "Arquivo não encontrado (HTTP $code)"
                        else -> "Erro do servidor (HTTP $code)"
                    }, retryable = code >= 500
                )
            }
            val body = resp.body ?: throw DownloadFailure("Resposta sem conteúdo")
            val ctype = resp.header("Content-Type")?.substringBefore(';')?.trim()?.lowercase()
            val expectsMedia = item.mimeType?.startsWith("video/") == true || item.mimeType?.startsWith("audio/") == true ||
                item.fileName.substringAfterLast('.', "").lowercase() in setOf("mp4", "webm", "m4v", "mov", "mkv", "3gp")
            if (expectsMedia && ctype != null && (ctype.startsWith("text/") || ctype == "application/json" || ctype.contains("mpegurl"))) {
                throw DownloadFailure("O servidor retornou '$ctype' em vez de um vídeo (link inválido, expirado ou protegido)")
            }

            val partial = code == 206
            if (resumeFrom > 0 && !partial) {
                // Servidor ignorou o Range: recomeça do início
                resumeFrom = 0
                target.delete()
            }
            val contentLength = body.contentLength()
            val total = when {
                partial -> parseTotalFromContentRange(resp.header("Content-Range")) ?: if (contentLength > 0) resumeFrom + contentLength else -1L
                contentLength > 0 -> contentLength
                else -> -1L
            }
            val acceptsRange = partial || resp.header("Accept-Ranges")?.contains("bytes", true) == true
            val etag = resp.header("ETag")

            var received = resumeFrom
            val raf = RandomAccessFile(target, "rw")
            try {
                raf.seek(resumeFrom)
                if (resumeFrom == 0L) raf.setLength(0)
                val src = body.source()
                val buf = ByteArray(64 * 1024)
                var windowStart = System.nanoTime()
                var windowBytes = 0L
                var lastReport = 0L
                var shownSpeed = 0L
                var throttleStart = System.nanoTime()
                var throttleBytes = 0L
                while (true) {
                    currentCoroutineContext().ensureActive()
                    val n = src.read(buf)
                    if (n < 0) break
                    raf.write(buf, 0, n)
                    received += n; windowBytes += n; throttleBytes += n

                    val limit = speedLimitBytesPerSec()
                    if (limit > 0) {
                        val elapsedMs = (System.nanoTime() - throttleStart) / 1_000_000
                        val expectedMs = throttleBytes * 1000 / limit
                        if (expectedMs > elapsedMs) delay(expectedMs - elapsedMs)
                        if (elapsedMs > 3000) { throttleStart = System.nanoTime(); throttleBytes = 0 }
                    }
                    val now = System.nanoTime()
                    val winMs = (now - windowStart) / 1_000_000
                    if (winMs >= 1000) {
                        shownSpeed = windowBytes * 1000 / winMs
                        windowStart = now; windowBytes = 0
                    }
                    if (now - lastReport > 400_000_000L) {
                        lastReport = now
                        onProgress(Progress(received, total, shownSpeed))
                    }
                }
                raf.fd.sync()
            } catch (e: CancellationException) {
                throw e
            } catch (e: IOException) {
                if (!currentCoroutineContext().isActive) throw CancellationException("Download interrompido")
                Log.w(TAG, "Falha de transferência: ${e.message}")
                throw DownloadFailure("Conexão interrompida: ${e.message ?: "erro de rede"}", retryable = true)
            } finally {
                runCatching { raf.close() }
            }
            onProgress(Progress(received, total, 0))
            if (total > 0 && received != total) {
                throw DownloadFailure("Transferência incompleta: $received de $total bytes", retryable = true)
            }
            Outcome(received, if (total > 0) total else received, acceptsRange, etag, ctype, resp.header("Content-Disposition"))
        } } finally { cancelHandle?.dispose() }
    }

    private fun parseTotalFromContentRange(h: String?): Long? =
        h?.substringAfterLast('/')?.trim()?.toLongOrNull()

    companion object { private const val TAG = "DownloadEngine" }
}
