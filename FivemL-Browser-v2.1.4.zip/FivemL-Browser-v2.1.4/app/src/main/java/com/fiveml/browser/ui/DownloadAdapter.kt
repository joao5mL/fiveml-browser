package com.fiveml.browser.ui

import android.content.ContentResolver
import android.net.Uri
import android.os.Build
import android.util.Size
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.lifecycle.LifecycleCoroutineScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.fiveml.browser.R
import com.fiveml.browser.data.DownloadEntity
import com.fiveml.browser.downloads.DownloadCenter
import com.fiveml.browser.util.Formatters
import com.google.android.material.progressindicator.LinearProgressIndicator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class DownloadRow(
    val e: DownloadEntity,
    val live: DownloadCenter.Live?,
    val selected: Boolean,
    val missing: Boolean,
)

class DownloadAdapter(
    private val scope: LifecycleCoroutineScope,
    private val resolver: ContentResolver,
    private val selectionMode: () -> Boolean,
    private val cb: Callbacks,
) : ListAdapter<DownloadRow, DownloadAdapter.VH>(Diff) {

    interface Callbacks {
        fun onToggleSelect(e: DownloadEntity)
        fun onLongPress(e: DownloadEntity)
        fun onPlay(e: DownloadEntity)
        fun onOpen(e: DownloadEntity)
        fun onShare(e: DownloadEntity)
        fun onPause(e: DownloadEntity)
        fun onResume(e: DownloadEntity)
        fun onRetry(e: DownloadEntity)
        fun onCancel(e: DownloadEntity)
        fun onDelete(e: DownloadEntity)
    }

    object Diff : DiffUtil.ItemCallback<DownloadRow>() {
        override fun areItemsTheSame(a: DownloadRow, b: DownloadRow) = a.e.id == b.e.id
        override fun areContentsTheSame(a: DownloadRow, b: DownloadRow) = a == b
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val thumb: ImageView = v.findViewById(R.id.dlThumb)
        val ext: TextView = v.findViewById(R.id.dlExt)
        val badge: ImageView = v.findViewById(R.id.dlPlayBadge)
        val name: TextView = v.findViewById(R.id.dlName)
        val info: TextView = v.findViewById(R.id.dlInfo)
        val check: CheckBox = v.findViewById(R.id.dlCheck)
        val progress: LinearProgressIndicator = v.findViewById(R.id.dlProgress)
        val error: TextView = v.findViewById(R.id.dlError)
        val play: ImageButton = v.findViewById(R.id.dlPlay)
        val open: ImageButton = v.findViewById(R.id.dlOpen)
        val share: ImageButton = v.findViewById(R.id.dlShare)
        val pause: ImageButton = v.findViewById(R.id.dlPause)
        val resume: ImageButton = v.findViewById(R.id.dlResume)
        val retry: ImageButton = v.findViewById(R.id.dlRetry)
        val cancel: ImageButton = v.findViewById(R.id.dlCancel)
        val delete: ImageButton = v.findViewById(R.id.dlDelete)
        var thumbKey: String? = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_download, parent, false))

    private fun vis(v: View, show: Boolean) { v.visibility = if (show) View.VISIBLE else View.GONE }

    override fun onBindViewHolder(h: VH, position: Int) {
        val row = getItem(position)
        val e = row.e
        val live = row.live
        val received = live?.received ?: e.receivedBytes
        val total = live?.total ?: e.totalBytes
        val ext = e.fileName.substringAfterLast('.', "").uppercase()
        val isVideo = e.mimeType?.startsWith("video/") == true
        val done = e.status == DownloadEntity.STATUS_DONE

        h.name.text = e.fileName
        h.ext.text = ext.ifBlank { "ARQ" }
        h.check.visibility = if (selectionMode()) View.VISIBLE else View.GONE
        h.check.setOnCheckedChangeListener(null)
        h.check.isChecked = row.selected
        h.check.setOnClickListener { cb.onToggleSelect(e) }
        h.itemView.setOnClickListener {
            when {
                selectionMode() -> cb.onToggleSelect(e)
                done && !row.missing -> if (isVideo) cb.onPlay(e) else cb.onOpen(e)
            }
        }
        h.itemView.setOnLongClickListener { cb.onLongPress(e); true }

        // Estados
        val running = e.status == DownloadEntity.STATUS_RUNNING
        val queued = e.status == DownloadEntity.STATUS_QUEUED
        val paused = e.status == DownloadEntity.STATUS_PAUSED
        val failed = e.status == DownloadEntity.STATUS_FAILED

        vis(h.progress, running || queued || paused)
        if (h.progress.visibility == View.VISIBLE) {
            val frac = live?.fraction ?: -1f
            if (frac >= 0f && !queued) {
                h.progress.isIndeterminate = false
                h.progress.setProgressCompat((frac * 100).toInt().coerceIn(0, 100), false)
            } else if (total > 0 && !queued) {
                h.progress.isIndeterminate = false
                h.progress.setProgressCompat(((received * 100) / total).toInt().coerceIn(0, 100), false)
            } else h.progress.isIndeterminate = true
        }

        h.info.text = when {
            done && row.missing -> "Arquivo não encontrado no armazenamento"
            done -> listOf(Formatters.size(e.totalBytes), ext.ifBlank { "Arquivo" }, Formatters.date(e.finishedAt)).joinToString(" · ")
            queued -> "Na fila"
            paused -> "Pausado · " + if (total > 0) "${Formatters.size(received)} de ${Formatters.size(total)}" else Formatters.size(received)
            running -> {
                val f = live?.fraction ?: -1f
                val percent = when {
                    f >= 0f -> "${(f * 100).toInt().coerceIn(0, 100)}% · "
                    total > 0 -> "${(received * 100 / total).coerceIn(0, 100)}% · "
                    else -> ""
                }
                val sizes = if (total > 0) "${Formatters.size(received)} de ${Formatters.size(total)}" else Formatters.size(received)
                val speed = Formatters.speed(live?.speed ?: 0)
                val eta = (live?.etaSeconds ?: -1).let { if (it >= 0) "restam ${Formatters.eta(it)}" else "" }
                (percent + listOf(sizes, speed, eta).filter { it.isNotBlank() }.joinToString(" · "))
            }
            failed -> "Falhou"
            else -> "Cancelado"
        }
        vis(h.error, failed && !e.error.isNullOrBlank()); h.error.text = e.error

        val sel = selectionMode()
        vis(h.play, done && isVideo && !row.missing && !sel)
        vis(h.open, done && !row.missing && !sel)
        vis(h.share, done && !row.missing && !sel)
        vis(h.pause, running && e.kind == DownloadEntity.KIND_FILE && !sel)
        vis(h.resume, paused && !sel)
        vis(h.retry, failed && !sel)
        vis(h.cancel, (running || queued || paused) && !sel)
        vis(h.delete, (done || failed) && !sel)
        h.play.setOnClickListener { cb.onPlay(e) }
        h.open.setOnClickListener { cb.onOpen(e) }
        h.share.setOnClickListener { cb.onShare(e) }
        h.pause.setOnClickListener { cb.onPause(e) }
        h.resume.setOnClickListener { cb.onResume(e) }
        h.retry.setOnClickListener { cb.onRetry(e) }
        h.cancel.setOnClickListener { cb.onCancel(e) }
        h.delete.setOnClickListener { cb.onDelete(e) }

        bindThumb(h, e, done && !row.missing && isVideo)
        vis(h.badge, done && isVideo && !row.missing)
    }

    private fun bindThumb(h: VH, e: DownloadEntity, localVideo: Boolean) {
        val key = "${e.id}:${e.status}:${e.finalUri}"
        if (h.thumbKey == key) return
        h.thumbKey = key
        h.thumb.setImageDrawable(null)
        h.ext.visibility = View.VISIBLE
        if (localVideo && e.finalUri != null) {
            val uri = Uri.parse(e.finalUri)
            scope.launch {
                val bmp = withContext(Dispatchers.IO) {
                    runCatching {
                        if (Build.VERSION.SDK_INT >= 29) resolver.loadThumbnail(uri, Size(192, 192), null) else null
                    }.getOrNull()
                }
                if (bmp != null && h.thumbKey == key) { h.thumb.setImageBitmap(bmp); h.ext.visibility = View.GONE }
            }
        } else if (!e.thumbnailUrl.isNullOrBlank() && e.thumbnailUrl.startsWith("http")) {
            h.thumb.load(e.thumbnailUrl) { listener(onSuccess = { _, _ -> h.ext.visibility = View.GONE }) }
        }
    }
}
