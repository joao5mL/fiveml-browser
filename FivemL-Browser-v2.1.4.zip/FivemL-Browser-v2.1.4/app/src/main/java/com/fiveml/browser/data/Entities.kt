package com.fiveml.browser.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "downloads", indices = [Index("status"), Index("createdAt")])
data class DownloadEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val url: String,
    val pageUrl: String? = null,
    val fileName: String,
    val mimeType: String? = null,
    val kind: String = KIND_FILE,
    val status: String = STATUS_QUEUED,
    val totalBytes: Long = -1,
    val receivedBytes: Long = 0,
    val supportsRange: Boolean = false,
    val etag: String? = null,
    val tempPath: String? = null,
    val finalUri: String? = null,
    val thumbnailUrl: String? = null,
    val error: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val finishedAt: Long = 0,
    val isPrivate: Boolean = false,
) {
    companion object {
        const val KIND_FILE = "file"
        const val KIND_HLS = "hls"
        const val STATUS_QUEUED = "queued"
        const val STATUS_RUNNING = "running"
        const val STATUS_PAUSED = "paused"
        const val STATUS_DONE = "done"
        const val STATUS_FAILED = "failed"
        const val STATUS_CANCELED = "canceled"
    }
}

@Entity(tableName = "history", indices = [Index("visitedAt"), Index("url")])
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val url: String,
    val title: String,
    val visitedAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "bookmarks", indices = [Index(value = ["url"], unique = true)])
data class BookmarkEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val url: String,
    val title: String,
    val position: Int = 0,
    val isShortcut: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "searches", indices = [Index(value = ["query"], unique = true)])
data class SearchEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val query: String,
    val usedAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "adblock_allow")
data class AllowedSiteEntity(@PrimaryKey val host: String)
