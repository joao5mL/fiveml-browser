package com.fiveml.browser.adblock

import android.content.Context
import android.util.Log
import com.fiveml.browser.data.AllowedSiteEntity
import com.fiveml.browser.data.AppDatabase
import com.fiveml.browser.settings.Prefs
import com.fiveml.browser.util.Net
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.File
import java.util.concurrent.atomic.AtomicLong

/**
 * Bloqueio por domínio com lista atualizável e exceções por site.
 * Regra de segurança: nunca bloqueia mídia (vídeo, áudio, HLS, DASH, segmentos) nem o documento principal.
 */
class AdBlocker(private val context: Context, private val prefs: Prefs, private val db: AppDatabase) {
    @Volatile private var hosts: Set<String> = emptySet()
    @Volatile private var allowed: Set<String> = emptySet()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val session = AtomicLong(0)

    val enabled: Boolean get() = prefs.adBlockEnabled
    val totalBlocked: Long get() = prefs.blockedCount
    val sessionBlocked: Long get() = session.get()
    val hostCount: Int get() = hosts.size

    private val mediaPath = Regex("""\.(mp4|m4v|webm|mov|mkv|m3u8|mpd|m4s|ts|aac|mp3|m4a|ogg|opus|vtt|srt|key)(?=$|[?#])""", RegexOption.IGNORE_CASE)
    private val essential = Regex("""(/hls/|/dash/|/manifest|/playlist|/video|/media/|/player|/api/|/graphql|/stream)""", RegexOption.IGNORE_CASE)

    fun load() {
        scope.launch {
            val file = File(context.filesDir, "filters.txt")
            val text = if (file.exists() && file.length() > 0) file.readText()
            else context.assets.open("filters_default.txt").bufferedReader().use { it.readText() }
            hosts = parse(text)
            allowed = db.allow().all().toSet()
        }
    }

    private fun parse(text: String): Set<String> = text.lineSequence()
        .map { it.substringBefore('#').trim() }
        .filter { it.isNotEmpty() }
        .mapNotNull { line ->
            val parts = line.split(Regex("\\s+"))
            val h = if (parts.size >= 2) parts[1] else parts[0]
            h.lowercase().takeIf { it.contains('.') && !it.contains('/') && it != "localhost" }
        }.toHashSet()

    /** Baixa uma lista atualizada. Retorna a quantidade de domínios ou lança exceção. */
    suspend fun updateLists(): Int = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(LIST_URL).header("User-Agent", Net.USER_AGENT).build()
        Net.client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) error("HTTP ${r.code}")
            val text = r.body?.string().orEmpty()
            val parsed = parse(text)
            if (parsed.size < 100) error("Lista recebida inválida")
            val merged = parse(context.assets.open("filters_default.txt").bufferedReader().use { it.readText() }) + parsed
            File(context.filesDir, "filters.txt").writeText(merged.joinToString("\n") { "0.0.0.0 $it" })
            hosts = merged
            prefs.filterListUpdatedAt = System.currentTimeMillis()
            merged.size
        }
    }

    fun isAllowedSite(host: String?): Boolean = host != null && matches(allowed, host)
    fun allowedSites(): List<String> = allowed.sorted()

    fun setSiteAllowed(host: String, allow: Boolean) {
        val h = host.lowercase().removePrefix("www.")
        scope.launch {
            if (allow) db.allow().insert(AllowedSiteEntity(h)) else db.allow().delete(h)
            allowed = db.allow().all().toSet()
        }
    }

    private fun matches(set: Set<String>, host: String): Boolean {
        var h = host.lowercase().removePrefix("www.")
        while (h.contains('.')) {
            if (set.contains(h)) return true
            h = h.substringAfter('.')
        }
        return false
    }

    fun shouldBlock(url: String, host: String?, pageHost: String?, isMainFrame: Boolean, accept: String?): Boolean {
        if (!enabled || isMainFrame || host == null) return false
        if (isAllowedSite(pageHost)) return false
        if (mediaPath.containsMatchIn(url)) return false
        if (accept != null && (accept.startsWith("video/") || accept.startsWith("audio/"))) return false
        if (essential.containsMatchIn(url) && pageHost != null && sameSite(host, pageHost)) return false
        if (!matches(hosts, host)) return false
        session.incrementAndGet()
        prefs.blockedCount = prefs.blockedCount + 1
        return true
    }

    private fun sameSite(a: String, b: String): Boolean {
        fun root(x: String) = x.lowercase().split('.').takeLast(2).joinToString(".")
        return root(a) == root(b)
    }

    companion object {
        private const val TAG = "AdBlocker"
        const val LIST_URL = "https://pgl.yoyo.org/adservers/serverlist.php?hostformat=hosts&showintro=0&mimetype=plaintext"
    }
}
