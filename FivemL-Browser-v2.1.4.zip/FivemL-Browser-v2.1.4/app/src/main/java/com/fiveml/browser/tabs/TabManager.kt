package com.fiveml.browser.tabs

import android.content.Context
import com.fiveml.browser.settings.Prefs
import org.json.JSONArray
import org.json.JSONObject

class TabManager(private val prefs: Prefs) {
    private val _tabs = mutableListOf<Tab>()
    val tabs: List<Tab> get() = _tabs
    var current: Tab? = null; private set
    private var nextId = 1L

    fun create(isPrivate: Boolean, url: String? = null, select: Boolean = true): Tab {
        val t = Tab(nextId++, isPrivate)
        if (url != null) { t.url = url; t.isHome = false }
        _tabs += t
        if (select || current == null) current = t
        return t
    }

    fun select(tab: Tab) { if (_tabs.contains(tab)) current = tab }
    fun indexOf(tab: Tab) = _tabs.indexOf(tab)

    /** Fecha a aba e retorna a aba que ficou ativa (ou null se não restou nenhuma). */
    fun close(tab: Tab): Tab? {
        val i = _tabs.indexOf(tab)
        if (i < 0) return current
        tab.webView?.let { it.stopLoading(); it.destroy() }
        tab.webView = null
        _tabs.removeAt(i)
        if (current === tab) current = _tabs.getOrNull(i.coerceAtMost(_tabs.lastIndex))
        return current
    }

    fun closeAll(onlyPrivate: Boolean = false) {
        _tabs.filter { !onlyPrivate || it.isPrivate }.toList().forEach { close(it) }
    }

    fun duplicate(tab: Tab): Tab = create(tab.isPrivate, tab.url.takeIf { !tab.isHome })

    fun privateCount() = _tabs.count { it.isPrivate }

    /** Só abas normais são persistidas; abas privadas nunca. */
    fun save() {
        val arr = JSONArray()
        _tabs.filter { !it.isPrivate && !it.isHome }.forEach {
            arr.put(JSONObject().put("url", it.url).put("title", it.title))
        }
        prefs.savedTabs = arr.toString()
    }

    fun restore(): List<Pair<String, String>> = runCatching {
        val arr = JSONArray(prefs.savedTabs)
        (0 until arr.length()).map { arr.getJSONObject(it).let { o -> o.getString("url") to o.optString("title") } }
    }.getOrDefault(emptyList())
}
