package com.fiveml.browser

import android.app.Application
import com.fiveml.browser.adblock.AdBlocker
import com.fiveml.browser.data.AppDatabase
import com.fiveml.browser.downloads.DownloadCenter
import com.fiveml.browser.notify.Notifier
import com.fiveml.browser.settings.Prefs

class FivemApp : Application() {
    lateinit var db: AppDatabase; private set
    lateinit var prefs: Prefs; private set
    lateinit var adBlocker: AdBlocker; private set
    lateinit var downloads: DownloadCenter; private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        db = AppDatabase.get(this)
        prefs = Prefs(this)
        Notifier.createChannels(this)
        adBlocker = AdBlocker(this, prefs, db)
        downloads = DownloadCenter(this, db, prefs)
        adBlocker.load()
        downloads.recoverAfterRestart()
    }

    companion object {
        lateinit var instance: FivemApp; private set
    }
}
