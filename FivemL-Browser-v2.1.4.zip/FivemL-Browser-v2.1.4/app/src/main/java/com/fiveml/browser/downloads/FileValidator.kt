package com.fiveml.browser.downloads

import java.io.File
import java.io.RandomAccessFile

/** Validação do arquivo baixado antes de marcá-lo como concluído. */
object FileValidator {
    class Result(val ok: Boolean, val reason: String? = null)

    fun validate(file: File, expectedTotal: Long, claimedMime: String?, fileName: String): Result {
        if (!file.exists()) return Result(false, "Arquivo não encontrado após a gravação")
        if (file.length() <= 0L) return Result(false, "Arquivo vazio")
        if (expectedTotal > 0 && file.length() != expectedTotal) {
            return Result(false, "Tamanho divergente: recebido ${file.length()} de $expectedTotal bytes")
        }
        val ext = fileName.substringAfterLast('.', "").lowercase()
        val isVideoExt = ext in setOf("mp4", "m4v", "mov", "3gp", "webm", "mkv")
        val mime = claimedMime?.lowercase().orEmpty()
        if (isVideoExt || mime.startsWith("video/")) return validateVideo(file, ext)
        return Result(true)
    }

    private fun validateVideo(file: File, ext: String): Result {
        val head = ByteArray(512)
        val n = RandomAccessFile(file, "r").use { it.read(head) }
        if (n < 12) return Result(false, "Arquivo pequeno demais para ser um vídeo")
        val text = String(head, 0, n, Charsets.ISO_8859_1).trimStart().lowercase()
        if (text.startsWith("<!doctype html") || text.startsWith("<html") || text.startsWith("<?xml") ||
            text.startsWith("{") || text.startsWith("#extm3u")
        ) return Result(false, "O servidor retornou texto/HTML em vez de um vídeo")
        return when (ext) {
            "webm", "mkv" -> {
                val ebml = head[0] == 0x1A.toByte() && head[1] == 0x45.toByte() &&
                    head[2] == 0xDF.toByte() && head[3] == 0xA3.toByte()
                if (ebml) Result(true) else Result(false, "Cabeçalho WebM/MKV inválido")
            }
            else -> validateIsoBmff(file)
        }
    }

    /** MP4/MOV: precisa conter 'ftyp' e 'moov' e 'mdat' com tamanho coerente (não só init segment). */
    private fun validateIsoBmff(file: File): Result {
        var hasFtyp = false; var hasMoov = false; var hasMdat = false; var hasMoof = false
        RandomAccessFile(file, "r").use { raf ->
            var pos = 0L
            val len = raf.length()
            var guard = 0
            while (pos + 8 <= len && guard++ < 4096) {
                raf.seek(pos)
                val h = ByteArray(8)
                raf.readFully(h)
                var size = ((h[0].toLong() and 0xFF) shl 24) or ((h[1].toLong() and 0xFF) shl 16) or
                    ((h[2].toLong() and 0xFF) shl 8) or (h[3].toLong() and 0xFF)
                val type = String(h, 4, 4, Charsets.ISO_8859_1)
                var header = 8L
                if (size == 1L) {
                    val ext = ByteArray(8); raf.readFully(ext)
                    size = 0
                    for (b in ext) size = (size shl 8) or (b.toLong() and 0xFF)
                    header = 16
                } else if (size == 0L) size = len - pos
                if (size < header) break
                when (type) { "ftyp" -> hasFtyp = true; "moov" -> hasMoov = true; "mdat" -> hasMdat = true; "moof" -> hasMoof = true }
                pos += size
            }
        }
        if (!hasFtyp) return Result(false, "Cabeçalho MP4 ausente (ftyp)")
        if (!hasMoov) return Result(false, "Estrutura MP4 incompleta (moov ausente)")
        if (hasMoof && !hasMdat) return Result(false, "Arquivo contém apenas segmento de inicialização")
        if (!hasMdat && !hasMoof) return Result(false, "Arquivo MP4 sem dados de mídia (mdat)")
        return Result(true)
    }
}
