package com.fiveml.browser.player

import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.TrackSelectionDialogBuilder
import com.fiveml.browser.FivemApp
import com.fiveml.browser.databinding.ActivityPlayerBinding
import com.fiveml.browser.downloads.DownloadCenter
import com.fiveml.browser.ui.DownloadsActivity
import com.fiveml.browser.ui.UiUtil
import com.fiveml.browser.util.FileNames
import com.fiveml.browser.util.Net
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import android.content.Intent

/** Player integrado (Media3/ExoPlayer): MP4, WebM, HLS, DASH, áudio. O botão de baixar não interrompe a reprodução. */
class PlayerActivity : AppCompatActivity() {
    private lateinit var b: ActivityPlayerBinding
    private var player: ExoPlayer? = null
    private var fullscreen = false
    private lateinit var url: String
    private var title: String = ""
    private var pageUrl: String? = null
    private var kind: FoundMedia.Kind = FoundMedia.Kind.FILE
    private var isPrivate = false
    private var poster: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        com.fiveml.browser.ui.ThemeManager.apply(this)
        super.onCreate(savedInstanceState)
        b = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(b.root)
        url = intent.getStringExtra(EXTRA_URL) ?: return finish()
        title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        pageUrl = intent.getStringExtra(EXTRA_PAGE)
        kind = runCatching { FoundMedia.Kind.valueOf(intent.getStringExtra(EXTRA_KIND).orEmpty()) }.getOrDefault(FoundMedia.Kind.FILE)
        isPrivate = intent.getBooleanExtra(EXTRA_PRIVATE, false)
        poster = intent.getStringExtra(EXTRA_POSTER)
        b.playerTitle.text = title

        b.btnClose.setOnClickListener { finish() }
        b.btnFullscreen.setOnClickListener { toggleFullscreen() }
        b.btnQuality.setOnClickListener { showQuality() }
        b.btnDownload.setOnClickListener { downloadCurrent() }
        b.playerView.setControllerVisibilityListener(androidx.media3.ui.PlayerView.ControllerVisibilityListener { vis ->
            val v = if (vis == View.VISIBLE) View.VISIBLE else View.GONE
            b.topControls.visibility = v
        })
        b.btnDownload.visibility = if (kind == FoundMedia.Kind.DASH || !url.startsWith("http")) View.GONE else View.VISIBLE
        initPlayer()
    }

    private fun initPlayer() {
        val httpFactory = OkHttpDataSource.Factory(Net.client.newBuilder().build()).setUserAgent(Net.USER_AGENT)
            .setDefaultRequestProperties(buildMap { pageUrl?.takeIf { it.startsWith("http") }?.let { put("Referer", it) } })
        val factory = DefaultMediaSourceFactory(DefaultDataSource.Factory(this, httpFactory))
        val p = ExoPlayer.Builder(this).setMediaSourceFactory(factory).build()
        player = p
        b.playerView.player = p
        val mime = when (kind) {
            FoundMedia.Kind.HLS -> MimeTypes.APPLICATION_M3U8
            FoundMedia.Kind.DASH -> MimeTypes.APPLICATION_MPD
            else -> null
        }
        p.setMediaItem(MediaItem.Builder().setUri(Uri.parse(url)).apply { mime?.let { setMimeType(it) } }.build())
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                b.errorText.visibility = View.VISIBLE
                b.errorText.text = "Não foi possível reproduzir este vídeo.\n${error.errorCodeName}"
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isPlaying) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        })
        p.prepare()
        p.playWhenReady = true
    }

    private fun showQuality() {
        val p = player ?: return
        val tracks = p.currentTracks
        if (tracks.groups.none { it.type == C.TRACK_TYPE_VIDEO && it.length > 0 }) {
            UiUtil.toast(this, "Esta fonte não oferece várias qualidades"); return
        }
        TrackSelectionDialogBuilder(this, "Qualidade", p, C.TRACK_TYPE_VIDEO).setAllowAdaptiveSelections(true).build().show()
    }

    private fun downloadCurrent() {
        val name = FileNames.sanitize(title).ifBlank { FileNames.build(null, url, null, "video/mp4") }
        val field = android.widget.EditText(this).apply { setText(FileNames.build(name, url, null, if (kind == FoundMedia.Kind.FILE) null else "video/mp4")); setSelectAllOnFocus(true) }
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = android.widget.FrameLayout(this).apply { setPadding(pad, pad / 2, pad, 0); addView(field) }
        MaterialAlertDialogBuilder(this).setTitle("Baixar").setView(box)
            .setPositiveButton("Baixar") { _, _ ->
                val id = FivemApp.instance.downloads.enqueue(DownloadCenter.Request(
                    url = url, pageUrl = pageUrl?.takeIf { it.startsWith("http") }, fileName = field.text.toString(), mimeType = null,
                    thumbnailUrl = poster, isPrivate = isPrivate, isHls = kind == FoundMedia.Kind.HLS))
                // A reprodução continua; o usuário acessa Downloads quando quiser
                val msg = if (id < 0) "Este download já está em andamento" else "Download iniciado"
                com.google.android.material.snackbar.Snackbar.make(b.root, msg, com.google.android.material.snackbar.Snackbar.LENGTH_LONG)
                    .setAction("Downloads") { startActivity(Intent(this, DownloadsActivity::class.java)) }.show()
            }.setNegativeButton(android.R.string.cancel, null).show()
    }

    private fun toggleFullscreen() {
        fullscreen = !fullscreen
        val c = WindowInsetsControllerCompat(window, window.decorView)
        if (fullscreen) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            c.hide(WindowInsetsCompat.Type.systemBars())
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            c.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    override fun onStop() { super.onStop(); player?.pause() }
    override fun onDestroy() { b.playerView.player = null; player?.release(); player = null; super.onDestroy() }

    companion object {
        const val EXTRA_URL = "url"; const val EXTRA_TITLE = "title"; const val EXTRA_PAGE = "page"
        const val EXTRA_KIND = "kind"; const val EXTRA_PRIVATE = "private"; const val EXTRA_POSTER = "poster"
        const val EXTRA_LOCAL = "local"
    }
}
