package com.fiveml.browser.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.fiveml.browser.FivemApp
import com.fiveml.browser.data.BookmarkEntity
import com.fiveml.browser.databinding.ActivityListBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class BookmarksActivity : AppCompatActivity() {
    private lateinit var appliedTheme: String
    private lateinit var b: ActivityListBinding
    private val dao get() = (application as FivemApp).db.bookmarks()
    private var all: List<BookmarkEntity> = emptyList()
    private var query = ""

    private val adapter = EntryAdapter(
        onClick = { r -> r.url?.let { openInBrowser(it) } },
        onAction = { r -> (r.tag as? BookmarkEntity)?.let { showActions(it) } },
        onLongClick = { r -> (r.tag as? BookmarkEntity)?.let { showActions(it) } },
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        appliedTheme = ThemeManager.apply(this)
        super.onCreate(savedInstanceState)
        b = ActivityListBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.title.text = "Favoritos"
        b.empty.text = "Nenhum favorito"
        b.btnAdd.visibility = View.VISIBLE
        b.btnClearAll.visibility = View.GONE
        b.list.layoutManager = LinearLayoutManager(this)
        b.list.adapter = adapter
        b.btnBack.setOnClickListener { finish() }
        b.btnAdd.setOnClickListener {
            UiUtil.input2(this, "Novo favorito", "Nome", "", "Endereço", "") { name, url ->
                if (url.isBlank()) return@input2
                val full = if (url.contains("://")) url else "https://$url"
                lifecycleScope.launch { dao.insert(BookmarkEntity(url = full, title = name.ifBlank { com.fiveml.browser.util.Urls.displayHost(full) }, position = dao.nextPosition())) }
            }
        }
        b.searchInput.addTextChangedListener { query = it?.toString().orEmpty().trim(); render() }
        lifecycleScope.launch { dao.observeAll().collectLatest { all = it; render() } }
    }

    override fun onResume() {
        super.onResume()
        if (ThemeManager.changed(this, appliedTheme)) recreate()
    }

    private fun render() {
        val list = all.filter { query.isEmpty() || it.title.contains(query, true) || it.url.contains(query, true) }
        adapter.submit(list.map { EntryRow(it.title, it.url, it.url, it, com.fiveml.browser.R.drawable.ic_more) })
        b.empty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun showActions(bm: BookmarkEntity) {
        val opts = arrayOf("Editar", if (bm.isShortcut) "Remover da página inicial" else "Adicionar à página inicial", "Mover para cima", "Mover para baixo", "Excluir")
        MaterialAlertDialogBuilder(this).setTitle(bm.title).setItems(opts) { _, i ->
            when (i) {
                0 -> UiUtil.input2(this, "Editar favorito", "Nome", bm.title, "Endereço", bm.url) { n, u ->
                    lifecycleScope.launch { dao.update(bm.copy(title = n.ifBlank { bm.title }, url = u.ifBlank { bm.url })) }
                }
                1 -> lifecycleScope.launch { dao.update(bm.copy(isShortcut = !bm.isShortcut)) }
                2 -> move(bm, -1)
                3 -> move(bm, 1)
                4 -> UiUtil.confirm(this, "Excluir", "Excluir ${bm.title}?", "Excluir") { lifecycleScope.launch { dao.delete(bm) } }
            }
        }.show()
    }

    private fun move(bm: BookmarkEntity, delta: Int) {
        val list = all.toMutableList()
        val i = list.indexOfFirst { it.id == bm.id }; val j = i + delta
        if (i < 0 || j !in list.indices) return
        list.add(j, list.removeAt(i))
        lifecycleScope.launch { list.forEachIndexed { idx, it -> dao.update(it.copy(position = idx)) } }
    }

    private fun openInBrowser(url: String) {
        startActivity(Intent(this, MainActivity::class.java).setAction(Intent.ACTION_VIEW).setData(Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
        finish()
    }
}
