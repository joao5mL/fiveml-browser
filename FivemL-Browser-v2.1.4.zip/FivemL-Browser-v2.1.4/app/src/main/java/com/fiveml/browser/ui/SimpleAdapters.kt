package com.fiveml.browser.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.fiveml.browser.R
import com.fiveml.browser.data.BookmarkEntity

/** Linha genérica com ícone de site, título, subtítulo e ação à direita. */
class EntryRow(
    val title: String, val subtitle: String, val url: String?, val tag: Any? = null,
    val actionIcon: Int = R.drawable.ic_close,
)

class EntryAdapter(
    private val onClick: (EntryRow) -> Unit,
    private val onAction: (EntryRow) -> Unit,
    private val onLongClick: ((EntryRow) -> Unit)? = null,
) : RecyclerView.Adapter<EntryAdapter.VH>() {
    private var rows: List<EntryRow> = emptyList()

    fun submit(list: List<EntryRow>) { rows = list; notifyDataSetChanged() }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.entryIcon)
        val letter: TextView = v.findViewById(R.id.entryLetter)
        val title: TextView = v.findViewById(R.id.entryTitle)
        val subtitle: TextView = v.findViewById(R.id.entrySubtitle)
        val action: ImageButton = v.findViewById(R.id.entryAction)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_entry, parent, false))

    override fun getItemCount() = rows.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val r = rows[position]
        h.title.text = r.title
        h.subtitle.text = r.subtitle
        h.action.setImageResource(r.actionIcon)
        if (r.url != null) UiUtil.bindIcon(h.icon, h.letter, r.url, r.title)
        else { h.icon.visibility = View.GONE; h.letter.visibility = View.VISIBLE; h.letter.text = r.title.firstOrNull()?.uppercase() ?: "•" }
        h.itemView.setOnClickListener { onClick(r) }
        h.itemView.setOnLongClickListener { onLongClick?.invoke(r); onLongClick != null }
        h.action.setOnClickListener { onAction(r) }
    }
}

class ShortcutAdapter(
    private val onOpen: (BookmarkEntity) -> Unit,
    private val onLong: (BookmarkEntity) -> Unit,
    private val onAdd: () -> Unit,
) : RecyclerView.Adapter<ShortcutAdapter.VH>() {
    private var items: List<BookmarkEntity> = emptyList()
    fun submit(list: List<BookmarkEntity>) { items = list; notifyDataSetChanged() }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.shortcutIcon)
        val letter: TextView = v.findViewById(R.id.shortcutLetter)
        val title: TextView = v.findViewById(R.id.shortcutTitle)
    }

    override fun getItemCount() = items.size + 1
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_shortcut, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        if (position == items.size) {
            h.title.text = "Adicionar"
            h.icon.visibility = View.GONE
            h.letter.visibility = View.VISIBLE
            h.letter.text = "+"
            h.itemView.setOnClickListener { onAdd() }
            h.itemView.setOnLongClickListener(null)
            return
        }
        val b = items[position]
        h.title.text = b.title
        UiUtil.bindIcon(h.icon, h.letter, b.url, b.title)
        h.itemView.setOnClickListener { onOpen(b) }
        h.itemView.setOnLongClickListener { onLong(b); true }
    }
}

class MenuItem(val icon: Int, val label: String, val action: () -> Unit)

class MenuAdapter(private val items: List<MenuItem>, private val dismiss: () -> Unit) : RecyclerView.Adapter<MenuAdapter.VH>() {
    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.menuIcon)
        val label: TextView = v.findViewById(R.id.menuLabel)
    }
    override fun getItemCount() = items.size
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_menu, parent, false))
    override fun onBindViewHolder(h: VH, position: Int) {
        val item = items[position]
        h.icon.setImageResource(item.icon)
        h.label.text = item.label
        h.itemView.setOnClickListener { dismiss(); item.action() }
    }
}
