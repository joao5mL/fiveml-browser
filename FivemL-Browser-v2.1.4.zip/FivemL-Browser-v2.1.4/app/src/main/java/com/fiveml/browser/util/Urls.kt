package com.fiveml.browser.util

import android.net.Uri
import com.fiveml.browser.settings.Prefs
import java.net.URLEncoder

object Urls {
    private val domainLike = Regex("""^(localhost|(\d{1,3}\.){3}\d{1,3}|([a-z0-9-]+\.)+[a-z]{2,})(:\d+)?([/?#].*)?$""", RegexOption.IGNORE_CASE)

    fun isUrl(text: String): Boolean {
        val t = text.trim()
        if (t.isEmpty() || t.contains(' ')) return false
        if (t.startsWith("http://", true) || t.startsWith("https://", true) || t.startsWith("file://", true) || t.startsWith("about:", true)) return true
        return domainLike.matches(t)
    }

    /** Retorna (url, isSearch). */
    fun resolve(raw: String, prefs: Prefs): Pair<String, Boolean> {
        val t = raw.trim()
        if (isUrl(t)) {
            val withScheme = if (t.contains("://") || t.startsWith("about:")) t else "https://$t"
            return withScheme to false
        }
        val base = Prefs.ENGINES[prefs.searchEngine]?.second ?: Prefs.ENGINES.getValue("google").second
        return base + URLEncoder.encode(t, "UTF-8") to true
    }

    fun host(url: String?): String? = runCatching { Uri.parse(url).host?.lowercase() }.getOrNull()

    fun faviconUrl(url: String): String? =
        host(url)?.let { "https://www.google.com/s2/favicons?domain=$it&sz=64" }

    fun displayHost(url: String): String = host(url)?.removePrefix("www.") ?: url
}
