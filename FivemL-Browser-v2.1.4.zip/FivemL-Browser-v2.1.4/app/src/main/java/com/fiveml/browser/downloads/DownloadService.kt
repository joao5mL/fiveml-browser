package com.fiveml.browser.downloads

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.ServiceCompat
import com.fiveml.browser.FivemApp
import com.fiveml.browser.notify.Notifier

/** Serviço em primeiro plano que mantém os downloads ativos com o app em segundo plano. */
class DownloadService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val center = (application as FivemApp).downloads
        startAsForeground(center.activeCount().coerceAtLeast(1))
        when (intent?.action) {
            DownloadCenter.ACTION_PAUSE -> center.pause(intent.getLongExtra(DownloadCenter.EXTRA_ID, -1))
            DownloadCenter.ACTION_RESUME -> center.resume(intent.getLongExtra(DownloadCenter.EXTRA_ID, -1))
            DownloadCenter.ACTION_CANCEL -> center.cancel(intent.getLongExtra(DownloadCenter.EXTRA_ID, -1))
        }
        center.attachService { count ->
            if (count <= 0) {
                stopForeground(STOP_FOREGROUND_DETACH)
                stopSelf()
            } else {
                runCatching {
                    getSystemService(android.app.NotificationManager::class.java)
                        .notify(Notifier.SERVICE_NOTIFICATION_ID, Notifier.foregroundNotification(this, count))
                }
            }
        }
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            if (center.activeCount() == 0) { stopForeground(STOP_FOREGROUND_DETACH); stopSelf() }
        }, 4000)
        return START_NOT_STICKY
    }

    private fun startAsForeground(count: Int) {
        val n = Notifier.foregroundNotification(this, count)
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        ServiceCompat.startForeground(this, Notifier.SERVICE_NOTIFICATION_ID, n, type)
    }

    companion object {
        fun start(context: Context) {
            val i = Intent(context, DownloadService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
        }
    }
}
