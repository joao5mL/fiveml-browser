package com.fiveml.browser.notify

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.fiveml.browser.R
import com.fiveml.browser.data.DownloadEntity
import com.fiveml.browser.downloads.DownloadCenter
import com.fiveml.browser.ui.MainActivity
import com.fiveml.browser.util.Formatters

object Notifier {
    const val CH_PROGRESS = "downloads_progress"
    const val CH_RESULT = "downloads_result"
    const val GROUP = "fiveml_downloads"
    const val SERVICE_NOTIFICATION_ID = 7001
    private const val SUMMARY_ID = 7002

    fun createChannels(context: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_PROGRESS, context.getString(R.string.channel_progress), NotificationManager.IMPORTANCE_LOW)
                .apply { setShowBadge(false) }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_RESULT, context.getString(R.string.channel_result), NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    fun canNotify(context: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun openDownloads(context: Context): PendingIntent {
        val i = Intent(context, MainActivity::class.java)
            .setAction(MainActivity.ACTION_OPEN_DOWNLOADS)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(context, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun action(context: Context, id: Long, act: String, label: String, req: Int): NotificationCompat.Action {
        val i = Intent(context, com.fiveml.browser.downloads.DownloadService::class.java).setAction(act)
            .putExtra(DownloadCenter.EXTRA_ID, id)
        val pi = PendingIntent.getService(context, req, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Action.Builder(0, label, pi).build()
    }

    /** Notificação atualizável de uma tarefa (mesmo id = mesma notificação). */
    fun taskNotification(context: Context, item: DownloadEntity, live: DownloadCenter.Live?): Notification {
        val received = live?.received ?: item.receivedBytes
        val total = live?.total ?: item.totalBytes
        val fraction = live?.fraction ?: -1f
        val determinate = total > 0 || fraction >= 0f
        val percent = when {
            fraction >= 0f -> (fraction * 100).toInt().coerceIn(0, 100)
            total > 0 -> ((received * 100) / total).toInt().coerceIn(0, 100)
            else -> 0
        }
        val stateText = when (item.status) {
            DownloadEntity.STATUS_QUEUED -> context.getString(R.string.state_starting)
            DownloadEntity.STATUS_RUNNING -> context.getString(R.string.state_downloading)
            DownloadEntity.STATUS_PAUSED -> context.getString(R.string.state_paused)
            else -> ""
        }
        val speed = Formatters.speed(live?.speed ?: 0)
        val sizeText = if (total > 0) "${Formatters.size(received)} / ${Formatters.size(total)}" else Formatters.size(received)
        val detail = listOf(stateText, if (determinate) "$percent%" else "", sizeText, speed).filter { it.isNotBlank() }.joinToString(" · ")

        val b = NotificationCompat.Builder(context, CH_PROGRESS)
            .setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle(item.fileName)
            .setContentText(detail)
            .setOnlyAlertOnce(true)
            .setOngoing(item.status != DownloadEntity.STATUS_PAUSED)
            .setGroup(GROUP)
            .setContentIntent(openDownloads(context))
            .setProgress(100, percent, !determinate && item.status == DownloadEntity.STATUS_RUNNING)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
        if (item.status == DownloadEntity.STATUS_PAUSED) {
            b.addAction(action(context, item.id, DownloadCenter.ACTION_RESUME, context.getString(R.string.action_resume), (item.id * 3 + 1).toInt()))
        } else {
            b.addAction(action(context, item.id, DownloadCenter.ACTION_PAUSE, context.getString(R.string.action_pause), (item.id * 3).toInt()))
        }
        b.addAction(action(context, item.id, DownloadCenter.ACTION_CANCEL, context.getString(R.string.action_cancel), (item.id * 3 + 2).toInt()))
        return b.build()
    }

    fun foregroundNotification(context: Context, activeCount: Int): Notification =
        NotificationCompat.Builder(context, CH_PROGRESS)
            .setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle(context.getString(R.string.app_name))
            .setContentText(context.resources.getQuantityString(R.plurals.active_downloads, activeCount, activeCount))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setGroup(GROUP)
            .setGroupSummary(true)
            .setContentIntent(openDownloads(context))
            .build()

    fun update(context: Context, item: DownloadEntity, live: DownloadCenter.Live?) {
        if (!canNotify(context)) return
        NotificationManagerCompat.from(context).notify(item.id.toInt() + 10_000, taskNotification(context, item, live))
    }

    fun cancel(context: Context, id: Long) {
        NotificationManagerCompat.from(context).cancel(id.toInt() + 10_000)
    }

    fun finished(context: Context, item: DownloadEntity) {
        if (!canNotify(context)) return
        val (title, text) = when (item.status) {
            DownloadEntity.STATUS_DONE -> context.getString(R.string.state_done) to "${item.fileName} · ${Formatters.size(item.receivedBytes)}"
            DownloadEntity.STATUS_FAILED -> context.getString(R.string.state_failed) to "${item.fileName}: ${item.error ?: ""}"
            else -> context.getString(R.string.state_canceled) to item.fileName
        }
        val n = NotificationCompat.Builder(context, CH_RESULT)
            .setSmallIcon(if (item.status == DownloadEntity.STATUS_DONE) R.drawable.ic_stat_done else R.drawable.ic_stat_download)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setGroup(GROUP)
            .setContentIntent(openDownloads(context))
            .build()
        NotificationManagerCompat.from(context).notify(item.id.toInt() + 10_000, n)
    }
}
