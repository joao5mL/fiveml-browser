package com.fiveml.browser.player

import android.net.Uri
import android.webkit.JavascriptInterface

data class FoundMedia(
    val url: String,
    val kind: Kind,
    val pageUrl: String?,
    val title: String? = null,
    val poster: String? = null,
    val fromPlayer: Boolean = false,
    val mime: String? = null,
    val foundAt: Long = System.currentTimeMillis(),
) { enum class Kind { FILE, HLS, DASH } }

/** Detecta mídia completa (ignora init segments e segmentos) e recebe dados do <video> ativo via JS. */
object MediaSniffer {
    private val fileExt = Regex("""\.(mp4|webm|m4v|mov|mkv|3gp)(?=$|[?#])""", RegexOption.IGNORE_CASE)
    private val hlsExt = Regex("""\.m3u8(?=$|[?#])""", RegexOption.IGNORE_CASE)
    private val dashExt = Regex("""\.mpd(?=$|[?#])""", RegexOption.IGNORE_CASE)
    private val partialParams = setOf("bytestart", "byteend", "range")

    private fun lastSegment(url: String): String =
        runCatching { Uri.parse(url).lastPathSegment.orEmpty().lowercase() }.getOrDefault("")

    fun isFragment(url: String): Boolean {
        val s = lastSegment(url)
        return s.startsWith("init") || s.startsWith("segment") || s.startsWith("chunk") || s.startsWith("seg-") ||
            s.endsWith(".m4s") || s.endsWith(".ts") || Regex("""^\d+\.(mp4|m4s)$""").matches(s)
    }

    fun classify(url: String): FoundMedia.Kind? {
        if (!(url.startsWith("http://") || url.startsWith("https://"))) return null
        if (isFragment(url)) return null
        return when {
            hlsExt.containsMatchIn(url) -> FoundMedia.Kind.HLS
            dashExt.containsMatchIn(url) -> FoundMedia.Kind.DASH
            fileExt.containsMatchIn(url) -> FoundMedia.Kind.FILE
            else -> null
        }
    }

    /** CDNs que servem só um trecho (bytestart/byteend) precisam do link completo. */
    fun cleanUrl(url: String): String {
        val uri = Uri.parse(url)
        val names = uri.queryParameterNames
        if (names.none { it.lowercase() in partialParams }) return url
        val b = uri.buildUpon().clearQuery()
        for (n in names) { if (n.lowercase() in partialParams) continue; for (v in uri.getQueryParameters(n)) b.appendQueryParameter(n, v) }
        return b.build().toString()
    }

    /** Playlists "master" de HLS costumam ser o que o usuário quer; mantém o último link relevante por página. */
    class Bridge(private val onMedia: (FoundMedia) -> Unit) {
        @JavascriptInterface
        fun onVideo(src: String, pageUrl: String, title: String, poster: String, playing: Boolean) {
            val kind = classify(src) ?: return
            onMedia(FoundMedia(cleanUrl(src), kind, pageUrl, cleanTitle(title), poster.ifBlank { null }, fromPlayer = true))
        }
        @JavascriptInterface
        fun onBlob(pageUrl: String, title: String, poster: String) {
            onMedia(FoundMedia("blob:", FoundMedia.Kind.FILE, pageUrl, cleanTitle(title), poster.ifBlank { null }, fromPlayer = true))
        }
    }

    /** Textos de interface/acessibilidade que nunca são título de vídeo (ex.: "This is a modal window."). */
    private val badTitle = Regex(
        """(this is a modal|modal window|modal dialog|beginning of dialog|end of dialog|escape will cancel|cookie|consent|gdpr|""" +
            """subscribe to|sign in|log in|login|advertisement|publicidade|enable javascript|error occurred|^loading|""" +
            """^video player$|^media player$|^play$|^pause$|^untitled$)""",
        RegexOption.IGNORE_CASE
    )

    /** Retorna o título limpo ou null se for texto de interface. */
    fun cleanTitle(raw: String?): String? {
        val t = raw?.replace(Regex("\\s+"), " ")?.trim().orEmpty()
        if (t.length < 3 || t.length > 200) return null
        if (badTitle.containsMatchIn(t)) return null
        return t
    }

    /**
     * Identifica o vídeo em reprodução (o que está tocando ou o maior visível) e o título dele.
     * Ordem: atributos do <video> > legenda (figcaption) > legenda/descrição visível próxima ao player >
     * og:title/twitter:title > JSON-LD > h1 do conteúdo > título da página. Ignora textos ocultos,
     * de acessibilidade (vjs-control-text, sr-only), modais, banners e comentários.
     */
    val script = """
(function(){
  if (window.__fvInstalled) { if (window.__fvScan) window.__fvScan(); return; }
  window.__fvInstalled = true;
  var BAD = /(this is a modal|modal window|modal dialog|beginning of dialog|end of dialog|escape will cancel|cookie|consent|gdpr|subscribe to|sign in|log in|login|advertisement|publicidade|enable javascript|error occurred|^loading|^video player${'$'}|^media player${'$'}|^play${'$'}|^pause${'$'}|^untitled${'$'})/i;
  var BLOCK = /(vjs-modal|vjs-control-text|vjs-text-track|modal|dialog|popup|cookie|consent|banner|advert|sr-only|visually-hidden|screen-reader|comment|related|recommend|sidebar|footer|navbar|breadcrumb)/i;
  function clean(s){ return (s||'').replace(/\s+/g,' ').trim().slice(0,200); }
  function visible(el){
    if(!el||!el.getBoundingClientRect) return false;
    var r=el.getBoundingClientRect(); if(r.width<24||r.height<8) return false;
    var cs=getComputedStyle(el); if(cs.visibility==='hidden'||cs.display==='none'||parseFloat(cs.opacity)===0) return false;
    return true;
  }
  function blocked(el){
    for(var n=el;n&&n!==document.body&&n!==document.documentElement;n=n.parentElement){
      var c=(typeof n.className==='string'?n.className:'')+' '+(n.id||'');
      if(BLOCK.test(c)) return true;
      var role=n.getAttribute&&n.getAttribute('role');
      if(role==='dialog'||role==='alertdialog'||role==='navigation') return true;
      if(n.getAttribute&&n.getAttribute('aria-hidden')==='true') return true;
    }
    return false;
  }
  function good(t,el){
    t=clean(t); if(t.length<3||t.length>200||BAD.test(t)) return '';
    if(el&&(blocked(el)||!visible(el))) return '';
    return t;
  }
  function meta(p){ var m=document.querySelector('meta[property="'+p+'"],meta[name="'+p+'"]'); return m?good(m.content):''; }
  function ld(){
    try{
      var n=document.querySelectorAll('script[type="application/ld+json"]');
      for(var i=0;i<n.length;i++){
        var j=JSON.parse(n[i].textContent), a=Array.isArray(j)?j:(j&&j['@graph']?j['@graph']:[j]);
        for(var k=0;k<a.length;k++){ var o=a[k]; if(o&&o['@type']==='VideoObject'&&o.name){ var t=good(o.name); if(t) return t; } }
      }
    }catch(e){}
    return '';
  }
  var SEL='[data-e2e*="desc"],[data-testid="tweetText"],[data-testid*="caption"],[class*="caption"],[class*="video-title"],[class*="videoTitle"],[class*="video_title"],[class*="description"],[itemprop="name"],h1,h2';
  function nearby(v){
    var fig=v.closest&&v.closest('figure');
    if(fig){ var fc=fig.querySelector('figcaption'); if(fc){ var t0=good(fc.innerText,fc); if(t0) return t0; } }
    var el=v.parentElement;
    for(var i=0;i<6&&el&&el!==document.body;i++,el=el.parentElement){
      var list=el.querySelectorAll(SEL);
      for(var k=0;k<list.length;k++){
        var c=list[k]; if(c.contains(v)) continue;
        var t=good(c.innerText,c); if(t) return t;
      }
    }
    return '';
  }
  function pageH1(){
    var hs=document.querySelectorAll('main h1,article h1,h1');
    for(var i=0;i<hs.length;i++){ var t=good(hs[i].innerText,hs[i]); if(t) return t; }
    return '';
  }
  function docTitle(){
    var t=clean(document.title).replace(/\s+[-|\u2013\u2014\u00b7]\s+[^-|\u2013\u2014\u00b7]{2,40}${'$'}/,'');
    return good(t)||good(document.title);
  }
  function titleFor(v){
    return good(v.getAttribute('title'))||good(v.getAttribute('aria-label'))||good(v.getAttribute('data-title'))||
      nearby(v)||meta('og:title')||meta('twitter:title')||ld()||pageH1()||docTitle();
  }
  function area(v){ var r=v.getBoundingClientRect(); return Math.max(0,r.width)*Math.max(0,r.height); }
  function scan(){
    var vs=[].slice.call(document.querySelectorAll('video'));
    if(!vs.length) return;
    vs.sort(function(a,b){ var pa=a.paused?0:1, pb=b.paused?0:1; return pb!==pa?pb-pa:area(b)-area(a); });
    var v=vs[0];
    var src=v.currentSrc||v.src||'';
    if(!src){ var s=v.querySelector('source'); if(s) src=s.src; }
    var t=titleFor(v), p=v.poster||meta('og:image');
    if(src&&src.indexOf('blob:')!==0) FivemBridge.onVideo(src,location.href,t,p||'',!v.paused);
    else FivemBridge.onBlob(location.href,t,p||'');
  }
  window.__fvScan=scan;
  document.addEventListener('play',function(){ setTimeout(scan,150); },true);
  document.addEventListener('loadeddata',function(){ setTimeout(scan,150); },true);
  new MutationObserver(function(){ clearTimeout(window.__fvT); window.__fvT=setTimeout(scan,600); }).observe(document.documentElement,{childList:true,subtree:true});
  scan();
})();
""".trimIndent()
}
