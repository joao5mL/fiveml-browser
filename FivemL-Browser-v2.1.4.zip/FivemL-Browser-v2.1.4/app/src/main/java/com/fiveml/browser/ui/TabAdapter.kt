package com.fiveml.browser.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.fiveml.browser.R
import com.fiveml.browser.tabs.Tab

class TabAdapter(
    private val tabs: List<Tab>,
    private val current: Tab?,
    private val onSelect: (Tab) -> Unit,
    private val onClose: (Tab) -> Unit,
) : RecyclerView.Adapter<TabAdapter.VH>() {
    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.tabIcon)
        val title: TextView = v.findViewById(R.id.tabTitle)
        val url: TextView = v.findViewById(R.id.tabUrl)
        val close: ImageButton = v.findViewById(R.id.tabClose)
    }

    override fun getItemCount() = tabs.size
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_tab, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val t = tabs[position]
        h.title.text = (if (t.isPrivate) "Privada · " else "") + t.displayTitle("Nova aba")
        h.url.text = if (t.isHome) "Página inicial" else t.url
        h.icon.setImageBitmap(t.favicon)
        if (t.favicon == null) h.icon.setImageResource(if (t.isPrivate) R.drawable.ic_private else R.drawable.ic_globe)
        h.itemView.alpha = if (t === current) 1f else 0.75f
        h.itemView.setOnClickListener { onSelect(t) }
        h.close.setOnClickListener { onClose(t) }
    }
}
