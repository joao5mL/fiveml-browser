package com.fiveml.browser.ui

import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.fiveml.browser.FivemApp
import com.fiveml.browser.data.BookmarkEntity
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.launch
import java.io.File

/** Página inicial: atalhos de navegação e mídia, favoritos rápidos, pesquisas recentes e papel de parede. */
class HomeController(
    private val activity: MainActivity,
    private val root: View,
    private val onOpen: (String) -> Unit,
    private val onDownloads: () -> Unit,
    private val onImageDownload: () -> Unit,
    private val currentPage: () -> Pair<String, String>?,
) {
    private val app = FivemApp.instance
    private val db = app.db
    private val prefs = app.prefs
    private val adapter: ShortcutAdapter
    private var shortcuts: List<BookmarkEntity> = emptyList()

    private val grid: RecyclerView = root.findViewById(com.fiveml.browser.R.id.shortcutGrid)
    private val recent: ChipGroup = root.findViewById(com.fiveml.browser.R.id.recentChips)

    init {
        adapter = ShortcutAdapter(
            onOpen = { onOpen(it.url) },
            onLong = { showShortcutMenu(it) },
            onAdd = { showAddDialog() },
        )
        grid.layoutManager = GridLayoutManager(activity, 4)
        grid.adapter = adapter
        root.findViewById<View>(com.fiveml.browser.R.id.homeDownloads).setOnClickListener { onDownloads() }
        root.findViewById<View>(com.fiveml.browser.R.id.homeImageDownload).setOnClickListener { onImageDownload() }
        applyPrefs()

        activity.lifecycleScope.launch {
            activity.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { db.bookmarks().observeShortcuts().collect { shortcuts = it; adapter.submit(it) } }
                launch { db.searches().observe().collect { renderRecent(it.map { s -> s.query }) } }
            }
        }
    }

    fun applyPrefs() {
        root.findViewById<View>(com.fiveml.browser.R.id.shortcutsSection).visibility = if (prefs.showShortcutsOnHome) View.VISIBLE else View.GONE
        root.findViewById<View>(com.fiveml.browser.R.id.recentSection).visibility = if (prefs.showSearchHistoryOnHome) View.VISIBLE else View.GONE
        val wp = root.findViewById<ImageView>(com.fiveml.browser.R.id.homeWallpaper)
        val f = prefs.homeWallpaper?.let { File(it) }
        wp.alpha = prefs.wallpaperOpacity / 100f
        when {
            f != null && f.exists() -> { wp.visibility = View.VISIBLE; wp.load(f) }
            Wallpapers.spec(prefs.wallpaperPreset) != null -> { wp.visibility = View.VISIBLE; wp.setImageDrawable(Wallpapers.drawable(prefs.wallpaperPreset)) }
            else -> { wp.visibility = View.GONE; wp.setImageDrawable(null) }
        }
    }

    private fun renderRecent(items: List<String>) {
        recent.removeAllViews()
        val section = root.findViewById<View>(com.fiveml.browser.R.id.recentSection)
        if (items.isEmpty()) { section.visibility = View.GONE; return }
        section.visibility = if (prefs.showSearchHistoryOnHome) View.VISIBLE else View.GONE
        items.take(10).forEach { q ->
            recent.addView(Chip(activity).apply {
                text = q
                isCloseIconVisible = true
                setOnClickListener { onOpen(q) }
                setOnCloseIconClickListener { activity.lifecycleScope.launch { db.searches().let { dao -> /* remove por consulta */ dao.deleteByQuery(q) } } }
            })
        }
    }

    private fun showAddDialog() {
        val page = currentPage()
        UiUtil.input2(activity, "Novo atalho", "Nome", page?.second.orEmpty(), "Endereço", page?.first.orEmpty()) { name, url ->
            if (url.isBlank()) return@input2
            val full = if (url.contains("://")) url else "https://$url"
            activity.lifecycleScope.launch {
                val pos = db.bookmarks().nextPosition()
                db.bookmarks().insert(BookmarkEntity(url = full, title = name.ifBlank { com.fiveml.browser.util.Urls.displayHost(full) }, position = pos, isShortcut = true))
            }
        }
    }

    private fun showShortcutMenu(b: BookmarkEntity) {
        val options = arrayOf("Editar", "Mover para trás", "Mover para frente", "Remover da página inicial")
        MaterialAlertDialogBuilder(activity).setTitle(b.title).setItems(options) { _, which ->
            when (which) {
                0 -> UiUtil.input2(activity, "Editar atalho", "Nome", b.title, "Endereço", b.url) { name, url ->
                    activity.lifecycleScope.launch { db.bookmarks().update(b.copy(title = name.ifBlank { b.title }, url = url.ifBlank { b.url })) }
                }
                1 -> move(b, -1)
                2 -> move(b, +1)
                3 -> activity.lifecycleScope.launch { db.bookmarks().update(b.copy(isShortcut = false)) }
            }
        }.show()
    }

    private fun move(b: BookmarkEntity, delta: Int) {
        val list = shortcuts.toMutableList()
        val i = list.indexOfFirst { it.id == b.id }
        val j = i + delta
        if (i < 0 || j !in list.indices) return
        list.add(j, list.removeAt(i))
        activity.lifecycleScope.launch { list.forEachIndexed { idx, it -> db.bookmarks().update(it.copy(position = idx)) } }
    }
}
