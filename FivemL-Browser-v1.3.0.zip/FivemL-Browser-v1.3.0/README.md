# FivemL Browser 1.3.0

Navegador Android nativo (Kotlin) com gerenciador de downloads próprio. Renderização via Android WebView (Chromium); interface, abas, downloads, player e notificações são componentes nativos.

## Módulos

| Pacote | Responsabilidade |
|---|---|
| `ui` | Navegador, página inicial, menu, Downloads, Histórico, Favoritos, Configurações |
| `tabs` | Abas (normais e privadas) e restauração de sessão |
| `downloads` | Motor HTTP (OkHttp, streaming, Range), HLS, validação, fila, serviço em primeiro plano |
| `player` | Detecção de mídia, identificação do título, player Media3 |
| `adblock` | Bloqueio por domínio, listas atualizáveis, exceções por site |
| `notify` | Canais e notificações atualizáveis por tarefa |
| `storage` | MediaStore (`Movies/FivemL`, `Music/FivemL`, `Download/FivemL`) |
| `data` | Room: downloads, histórico, favoritos, pesquisas, exceções |

## Aparência

- 8 temas (Meia-noite, Oceano, Aurora, Pôr do sol, Grafite, Carmesim, Dourado, Claro), todos com fundo em gradiente. Definidos como styles com atributos `fv*` em `res/values/themes.xml`; aplicados por `ui/ThemeManager`.
- Papel de parede da página inicial: 10 gradientes gerados em código (`ui/Wallpapers`), imagem da galeria e opacidade ajustável (0–100%).
- Acesso: Menu › Aparência, ou Configurações › Tema e papel de parede.

## Downloads

- Escrita progressiva em arquivo temporário; nada é carregado inteiro em memória.
- Pausa/retomada com `Range` quando o servidor suporta; reinício automático quando não suporta.
- Conclusão somente após: transferência completa, tamanho coerente, arquivo não vazio e validação estrutural (MP4/MOV: `ftyp`, `moov`, `mdat`; WebM/MKV: cabeçalho EBML; respostas HTML/JSON/texto são rejeitadas).
- HLS sem criptografia: manifesto → melhor variante → segmentos → remux com `MediaMuxer` para MP4. Conteúdo com `EXT-X-KEY`, transmissões ao vivo e DASH não são baixados.
- Só após validação o arquivo é publicado no MediaStore.

## Versão

- Versão do aplicativo: **1.3.0** (versionCode `20130`).
- Esta distribuição mantém os recursos existentes e corrige a identificação de mídia no menu de contexto.

## Build

JDK 17, Gradle 8.9, Android Gradle Plugin 8.5.2, Kotlin 1.9.24.

```
gradle wrapper --gradle-version 8.9
./gradlew assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`. O workflow `.github/workflows/build.yml` gera `FivemL-Browser-1.3.0.apk`.

## Nome do arquivo

O título do vídeo é obtido pelo script de `player/MediaSniffer` na ordem: atributos do `<video>`, `figcaption`, legenda/descrição visível próxima ao player, `og:title`/`twitter:title`, JSON-LD `VideoObject`, `h1` do conteúdo e título da página. Textos ocultos, de acessibilidade (ex.: video.js "This is a modal window."), modais, banners de cookies e comentários são descartados. Sem título válido, usa-se o nome do arquivo da URL, depois o título da página e, por último, domínio + data. Nomes repetidos recebem sufixo numérico.
