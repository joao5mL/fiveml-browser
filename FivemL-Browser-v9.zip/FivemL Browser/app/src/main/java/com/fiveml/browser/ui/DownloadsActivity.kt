package com.fiveml.browser.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.SimpleItemAnimator
import com.fiveml.browser.FivemApp
import com.fiveml.browser.R
import com.fiveml.browser.data.DownloadEntity
import com.fiveml.browser.databinding.ActivityDownloadsBinding
import com.fiveml.browser.downloads.DownloadCenter
import com.fiveml.browser.player.FoundMedia
import com.fiveml.browser.player.PlayerActivity
import com.fiveml.browser.storage.MediaStorage
import com.google.android.material.chip.Chip
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Tela própria do gerenciador de downloads. Só abre por ação do usuário. */
class DownloadsActivity : AppCompatActivity(), DownloadAdapter.Callbacks {
    private lateinit var b: ActivityDownloadsBinding
    private val app get() = application as FivemApp
    private lateinit var adapter: DownloadAdapter

    private enum class Status { ALL, ACTIVE, DONE, FAILED }
    private enum class Format { ALL, VIDEO, AUDIO, IMAGE, DOC, OTHER }
    private enum class Sort { DATE, NAME, SIZE }

    private var status = Status.ALL
    private var format = Format.ALL
    private var sort = Sort.DATE
    private var query = ""
    private var selecting = false
    private val selected = HashSet<Long>()
    private var all: List<DownloadEntity> = emptyList()
    private var live: Map<Long, DownloadCenter.Live> = emptyMap()
    private var missing: Set<Long> = emptySet()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityDownloadsBinding.inflate(layoutInflater)
        setContentView(b.root)

        adapter = DownloadAdapter(lifecycleScope, contentResolver, { selecting }, this)
        b.list.layoutManager = LinearLayoutManager(this)
        b.list.adapter = adapter
        (b.list.itemAnimator as? SimpleItemAnimator)?.supportsChangeAnimations = false

        b.btnBack.setOnClickListener { onBackPressedDispatcher.onBackPressed() }
        b.btnSearch.setOnClickListener {
            b.searchInput.visibility = if (b.searchInput.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            if (b.searchInput.visibility == View.VISIBLE) UiUtil.showKeyboard(b.searchInput) else { b.searchInput.setText(""); UiUtil.hideKeyboard(b.searchInput) }
        }
        b.searchInput.addTextChangedListener { query = it?.toString().orEmpty().trim(); render() }
        b.btnSort.setOnClickListener { showSortDialog() }
        b.btnSelect.setOnClickListener { setSelecting(!selecting) }
        b.btnSelectAll.setOnClickListener { visibleRows().forEach { selected += it.id }; render() }
        b.btnDeleteSelected.setOnClickListener { deleteSelected() }

        addChips(b.statusChips, listOf("Todos" to Status.ALL, "Em andamento" to Status.ACTIVE, "Concluídos" to Status.DONE, "Falhas" to Status.FAILED)) { status = it; render() }
        addChips(b.formatChips, listOf("Todos formatos" to Format.ALL, "Vídeo" to Format.VIDEO, "Áudio" to Format.AUDIO, "Imagem" to Format.IMAGE, "Documento" to Format.DOC, "Outros" to Format.OTHER)) { format = it; render() }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                combine(app.db.downloads().observeAll(), app.downloads.live) { list, l -> list to l }.collect { (list, l) ->
                    all = list; live = l
                    missing = withContext(Dispatchers.IO) {
                        list.filter { it.status == DownloadEntity.STATUS_DONE && it.finalUri != null && !MediaStorage.exists(this@DownloadsActivity, Uri.parse(it.finalUri)) }.map { it.id }.toSet()
                    }
                    render()
                }
            }
        }
    }

    private fun <T> addChips(group: com.google.android.material.chip.ChipGroup, items: List<Pair<String, T>>, onSel: (T) -> Unit) {
        items.forEachIndexed { i, (label, value) ->
            val chip = Chip(this).apply { text = label; isCheckable = true; isChecked = i == 0; id = View.generateViewId() }
            chip.setOnClickListener { chip.isChecked = true; onSel(value) }
            group.addView(chip)
        }
    }

    private fun extOf(e: DownloadEntity) = e.fileName.substringAfterLast('.', "").lowercase()
    private fun formatOf(e: DownloadEntity): Format {
        val ext = extOf(e); val m = e.mimeType.orEmpty()
        return when {
            m.startsWith("video/") || ext in setOf("mp4", "webm", "mkv", "mov", "3gp", "m4v") -> Format.VIDEO
            m.startsWith("audio/") || ext in setOf("mp3", "m4a", "aac", "ogg", "opus", "wav", "flac") -> Format.AUDIO
            m.startsWith("image/") || ext in setOf("jpg", "jpeg", "png", "gif", "webp") -> Format.IMAGE
            ext in setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "epub", "zip", "apk") -> Format.DOC
            else -> Format.OTHER
        }
    }

    private fun visibleRows(): List<DownloadEntity> {
        var l = all.filter { e ->
            when (status) {
                Status.ALL -> true
                Status.ACTIVE -> e.status in listOf(DownloadEntity.STATUS_RUNNING, DownloadEntity.STATUS_QUEUED, DownloadEntity.STATUS_PAUSED)
                Status.DONE -> e.status == DownloadEntity.STATUS_DONE
                Status.FAILED -> e.status == DownloadEntity.STATUS_FAILED
            }
        }
        if (format != Format.ALL) l = l.filter { formatOf(it) == format }
        if (query.isNotEmpty()) l = l.filter { it.fileName.contains(query, true) }
        return when (sort) {
            Sort.DATE -> l.sortedByDescending { it.createdAt }
            Sort.NAME -> l.sortedBy { it.fileName.lowercase() }
            Sort.SIZE -> l.sortedByDescending { maxOf(it.totalBytes, it.receivedBytes) }
        }
    }

    private fun render() {
        val rows = visibleRows()
        adapter.submitList(rows.map { DownloadRow(it, live[it.id], selected.contains(it.id), missing.contains(it.id)) })
        b.empty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
        b.selectionBar.visibility = if (selecting) View.VISIBLE else View.GONE
        b.selectionCount.text = "${selected.size} selecionado(s)"
        b.title.text = if (selecting) "Selecionar" else "Downloads"
        // Estado de seleção afeta a exibição dos botões de cada item
        b.list.post { adapter.notifyItemRangeChanged(0, adapter.itemCount) }
    }

    private fun setSelecting(on: Boolean) { selecting = on; if (!on) selected.clear(); render() }

    private fun showSortDialog() {
        val names = arrayOf("Data (mais recentes)", "Nome (A–Z)", "Tamanho (maiores)")
        MaterialAlertDialogBuilder(this).setTitle("Ordenar por").setSingleChoiceItems(names, sort.ordinal) { d, i -> sort = Sort.values()[i]; render(); d.dismiss() }.show()
    }

    private fun deleteSelected() {
        if (selected.isEmpty()) return
        UiUtil.confirm(this, "Excluir arquivos", "Excluir ${selected.size} item(ns) e os arquivos baixados?", "Excluir") {
            selected.toList().forEach { app.downloads.remove(it, deleteFile = true) }
            setSelecting(false)
        }
    }

    override fun onBackPressed() { if (selecting) setSelecting(false) else super.onBackPressed() }

    // ── Callbacks ──
    override fun onToggleSelect(e: DownloadEntity) { if (!selected.add(e.id)) selected.remove(e.id); render() }
    override fun onLongPress(e: DownloadEntity) { if (!selecting) { selecting = true }; selected += e.id; render() }

    override fun onPlay(e: DownloadEntity) {
        val uri = e.finalUri ?: return
        startActivity(Intent(this, PlayerActivity::class.java).putExtra(PlayerActivity.EXTRA_URL, uri)
            .putExtra(PlayerActivity.EXTRA_TITLE, e.fileName).putExtra(PlayerActivity.EXTRA_KIND, FoundMedia.Kind.FILE.name))
    }

    override fun onOpen(e: DownloadEntity) {
        val uri = Uri.parse(e.finalUri ?: return)
        try {
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, e.mimeType ?: "*/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (ex: Exception) { UiUtil.toast(this, "Nenhum aplicativo disponível para abrir este arquivo") }
    }

    override fun onShare(e: DownloadEntity) {
        val uri = Uri.parse(e.finalUri ?: return)
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType(e.mimeType ?: "*/*")
            .putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Compartilhar"))
    }

    override fun onPause(e: DownloadEntity) = app.downloads.pause(e.id)
    override fun onResume(e: DownloadEntity) = app.downloads.resume(e.id)
    override fun onRetry(e: DownloadEntity) = app.downloads.retry(e.id)
    override fun onCancel(e: DownloadEntity) = UiUtil.confirm(this, "Cancelar download", "Cancelar e descartar ${e.fileName}?", "Cancelar download") { app.downloads.cancel(e.id) }
    override fun onDelete(e: DownloadEntity) = UiUtil.confirm(this, "Excluir", "Excluir ${e.fileName}?", "Excluir") { app.downloads.remove(e.id, deleteFile = true) }
}
