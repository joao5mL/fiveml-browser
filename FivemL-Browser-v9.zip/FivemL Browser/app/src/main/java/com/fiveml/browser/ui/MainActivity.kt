package com.fiveml.browser.ui

import android.Manifest
import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Message
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.JsResult
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.fiveml.browser.FivemApp
import com.fiveml.browser.R
import com.fiveml.browser.data.BookmarkEntity
import com.fiveml.browser.data.HistoryEntity
import com.fiveml.browser.data.SearchEntity
import com.fiveml.browser.databinding.ActivityMainBinding
import com.fiveml.browser.downloads.DownloadCenter
import com.fiveml.browser.player.FoundMedia
import com.fiveml.browser.player.MediaSniffer
import com.fiveml.browser.player.PlayerActivity
import com.fiveml.browser.tabs.Tab
import com.fiveml.browser.tabs.TabManager
import com.fiveml.browser.util.FileNames
import com.fiveml.browser.util.Net
import com.fiveml.browser.util.Urls
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import okhttp3.Request
import org.json.JSONArray
import java.io.ByteArrayInputStream
import java.net.URLEncoder

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val app get() = application as FivemApp
    private val prefs get() = app.prefs
    private val db get() = app.db
    private lateinit var tabs: TabManager
    private lateinit var home: HomeController

    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var suggestJob: Job? = null
    private var programmaticText = false
    private var pendingAfterPermission: (() -> Unit)? = null

    private val suggestionAdapter = EntryAdapter(onClick = { openInput(it.title) }, onAction = { fillAddress(it.title) })

    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        pendingAfterPermission?.invoke(); pendingAfterPermission = null
    }
    private val filePicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        val uris = if (r.resultCode == RESULT_OK && data != null) {
            data.clipData?.let { c -> Array(c.itemCount) { c.getItemAt(it).uri } } ?: data.data?.let { arrayOf(it) }
        } else null
        fileCallback?.onReceiveValue(uris); fileCallback = null
    }
    private val wallpaperPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val out = java.io.File(filesDir, "wallpaper.img")
            contentResolver.openInputStream(uri)?.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
            prefs.homeWallpaper = out.absolutePath
            home.applyPrefs()
        }
    }

    private val current: Tab? get() = tabs.current

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        tabs = TabManager(prefs)
        CookieManager.getInstance().setAcceptCookie(true)

        home = HomeController(this, b.home.root, onOpen = { openInput(it) }, onFocusSearch = { focusAddress() },
            currentPage = { current?.takeIf { !it.isHome }?.let { t -> t.url to t.title } })

        b.suggestions.layoutManager = LinearLayoutManager(this)
        b.suggestions.adapter = suggestionAdapter
        setupToolbar()
        setupBack()

        if (prefs.restoreTabs) {
            val saved = tabs.restore()
            saved.forEach { tabs.create(false, it.first, select = false).also { t -> t.title = it.second; t.pendingLoad = true } }
            tabs.tabs.firstOrNull()?.let { tabs.select(it) }
        }
        if (tabs.tabs.isEmpty()) tabs.create(false)
        showTab(tabs.current!!)
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        when (intent?.action) {
            ACTION_OPEN_DOWNLOADS -> startActivity(Intent(this, DownloadsActivity::class.java))
            Intent.ACTION_VIEW -> intent.data?.toString()?.let { openUrlInNewTab(it) }
            Intent.ACTION_SEND -> intent.getStringExtra(Intent.EXTRA_TEXT)?.let { openInput(it.trim()) }
        }
        intent?.action = null
    }

    // ───────────────────────── Barra e navegação ─────────────────────────

    private fun setupToolbar() {
        b.addressInput.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO || (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)) {
                openInput(v.text.toString()); true
            } else false
        }
        b.addressInput.setOnFocusChangeListener { _, focused ->
            if (focused) { showSuggestions(); refreshSuggestions(b.addressInput.text.toString()) } else hideSuggestions()
            updateAddressButtons()
        }
        b.addressInput.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, bf: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                updateAddressButtons()
                if (!programmaticText && b.addressInput.hasFocus()) refreshSuggestions(s?.toString().orEmpty())
            }
        })
        b.btnClear.setOnClickListener { b.addressInput.setText("") }
        b.btnPaste.setOnClickListener { pasteFromClipboard() }
        b.btnReload.setOnClickListener {
            val t = current ?: return@setOnClickListener
            if (t.loading) t.webView?.stopLoading() else if (!t.isHome) t.webView?.reload()
        }
        b.btnBack.setOnClickListener { goBack() }
        b.btnForward.setOnClickListener { current?.webView?.takeIf { it.canGoForward() }?.goForward() }
        b.btnHome.setOnClickListener { goHome() }
        b.btnTabs.setOnClickListener { showTabsSheet() }
        b.btnMenu.setOnClickListener { showMenu() }
        b.fabMedia.setOnClickListener { onMediaFabClick() }
    }

    private fun pasteFromClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()?.trim()
        if (text.isNullOrBlank()) UiUtil.toast(this, "Área de transferência vazia") else { setAddressText(text); b.addressInput.requestFocus(); b.addressInput.setSelection(text.length) }
    }

    private fun focusAddress() {
        b.addressInput.requestFocus()
        UiUtil.showKeyboard(b.addressInput)
    }

    private fun fillAddress(text: String) { setAddressText(text); b.addressInput.setSelection(text.length) }

    private fun setAddressText(text: String) {
        programmaticText = true
        b.addressInput.setText(text)
        programmaticText = false
    }

    private fun updateAddressButtons() {
        val focused = b.addressInput.hasFocus()
        val hasText = b.addressInput.text.isNotEmpty()
        b.btnClear.visibility = if (focused && hasText) View.VISIBLE else View.GONE
        b.btnPaste.visibility = if (!hasText) View.VISIBLE else View.GONE
        b.btnReload.visibility = if (focused) View.GONE else View.VISIBLE
        val t = current
        b.btnReload.setImageResource(if (t?.loading == true) R.drawable.ic_close else R.drawable.ic_refresh)
    }

    private fun showSuggestions() { b.suggestions.visibility = View.VISIBLE }
    private fun hideSuggestions() { b.suggestions.visibility = View.GONE; suggestJob?.cancel() }

    private fun refreshSuggestions(query: String) {
        suggestJob?.cancel()
        suggestJob = lifecycleScope.launch {
            val q = query.trim()
            val local = mutableListOf<EntryRow>()
            if (q.isNotEmpty()) {
                db.searches().suggest(q).forEach { local += EntryRow(it.query, "Pesquisa recente", null) }
                db.history().search(q).take(4).forEach { local += EntryRow(it.url, it.title, it.url) }
            } else {
                db.searches().suggest("").take(6).forEach { local += EntryRow(it.query, "Pesquisa recente", null) }
            }
            suggestionAdapter.submit(local)
            if (q.length >= 2 && !Urls.isUrl(q) && !(current?.isPrivate ?: false)) {
                delay(250)
                val remote = fetchSuggestions(q)
                suggestionAdapter.submit((remote.map { EntryRow(it, "Sugestão", null) } + local).distinctBy { it.title })
            }
        }
    }

    private suspend fun fetchSuggestions(q: String): List<String> = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        try {
            val url = "https://suggestqueries.google.com/complete/search?client=firefox&q=" + URLEncoder.encode(q, "UTF-8")
            Net.client.newCall(Request.Builder().url(url).build()).execute().use { r ->
                val arr = JSONArray(r.body?.string().orEmpty()).getJSONArray(1)
                (0 until minOf(arr.length(), 6)).map { arr.getString(it) }
            }
        } catch (e: Exception) { emptyList() }
    }

    fun openInput(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return
        val (url, isSearch) = Urls.resolve(text, prefs)
        if (isSearch && current?.isPrivate != true) lifecycleScope.launch { db.searches().insert(SearchEntity(query = text)) }
        b.addressInput.clearFocus()
        UiUtil.hideKeyboard(b.addressInput)
        loadUrl(url)
    }

    private fun loadUrl(url: String) {
        val t = current ?: return
        t.isHome = false
        t.url = url
        ensureWebView(t)
        showTab(t)
        t.webView?.loadUrl(url)
    }

    private fun openUrlInNewTab(url: String, private: Boolean = false) {
        val t = tabs.create(private, url)
        ensureWebView(t)
        showTab(t)
        t.webView?.loadUrl(url)
    }

    private fun goBack() {
        val t = current ?: return
        val w = t.webView
        if (w != null && !t.isHome && w.canGoBack()) w.goBack() else if (!t.isHome) goHome()
    }

    private fun goHome() {
        val t = current ?: return
        t.isHome = true; t.url = ""; t.title = ""
        t.media.clear(); t.playerMedia = null
        showTab(t)
    }

    private fun setupBack() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    customView != null -> exitFullscreen()
                    b.addressInput.hasFocus() -> { b.addressInput.clearFocus(); UiUtil.hideKeyboard(b.addressInput) }
                    current?.isHome == false -> goBack()
                    else -> finish()
                }
            }
        })
    }

    // ───────────────────────── Abas e WebView ─────────────────────────

    private fun showTab(tab: Tab) {
        tabs.select(tab)
        b.webContainer.removeAllViews()
        b.suggestions.visibility = View.GONE
        if (tab.isHome) {
            b.home.root.visibility = View.VISIBLE
            b.webContainer.visibility = View.GONE
            setAddressText("")
        } else {
            ensureWebView(tab)
            b.home.root.visibility = View.GONE
            b.webContainer.visibility = View.VISIBLE
            tab.webView?.let { w -> (w.parent as? ViewGroup)?.removeView(w); b.webContainer.addView(w, ViewGroup.LayoutParams(-1, -1)) }
            setAddressText(tab.url)
            if (tab.pendingLoad) { tab.pendingLoad = false; tab.webView?.loadUrl(tab.url) }
        }
        applyPrivateStyle(tab)
        updateChrome()
        updateFab()
    }

    private fun applyPrivateStyle(tab: Tab) {
        val c = ContextCompat.getColor(this, if (tab.isPrivate) R.color.bg_main else R.color.bg_secondary)
        b.topBar.setBackgroundColor(c)
        b.siteIcon.setImageResource(if (tab.isPrivate) R.drawable.ic_private else R.drawable.ic_globe)
        b.addressInput.hint = if (tab.isPrivate) "Navegação privada" else getString(R.string.home_title)
    }

    private fun updateChrome() {
        val t = current ?: return
        b.tabCount.text = tabs.tabs.size.toString()
        val w = t.webView
        b.btnBack.alpha = if (!t.isHome) 1f else 0.35f
        b.btnForward.alpha = if (w != null && w.canGoForward() && !t.isHome) 1f else 0.35f
        b.progress.visibility = if (t.loading && !t.isHome) View.VISIBLE else View.GONE
        b.progress.progress = t.progress
        updateAddressButtons()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun ensureWebView(tab: Tab) {
        if (tab.webView != null) return
        val w = WebView(this)
        configure(w, tab)
        tab.webView = w
    }

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    private fun configure(w: WebView, tab: Tab) {
        if (tab.isPrivate && WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            runCatching {
                androidx.webkit.ProfileStore.getInstance().getOrCreateProfile(PRIVATE_PROFILE)
                WebViewCompat.setProfile(w, PRIVATE_PROFILE)
            }
        }
        w.settings.apply {
            javaScriptEnabled = prefs.javascriptEnabled
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = true
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(true)
            builtInZoomControls = true
            displayZoomControls = false
            loadWithOverviewMode = true
            useWideViewPort = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = if (tab.isPrivate) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
            if (prefs.desktopMode) {
                userAgentString = Net.USER_AGENT.replace("Mobile Safari", "Safari").replace("Android 15; RMX3710", "X11; Linux x86_64")
            }
            setSupportZoom(true)
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, prefs.thirdPartyCookies)
        w.addJavascriptInterface(MediaSniffer.Bridge { m -> runOnUiThread { onJsMedia(tab, m) } }, "FivemBridge")
        w.setDownloadListener { url, _, cd, mime, _ ->
            val name = FileNames.build(null, url, cd, mime)
            val kind = MediaSniffer.classify(url) ?: FoundMedia.Kind.FILE
            runOnUiThread { showDownloadDialog(FoundMedia(url, kind, tab.url, null, null, false, mime), tab, name) }
        }
        w.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                tab.loading = true; tab.progress = 5; tab.url = url; tab.isHome = false
                tab.media.clear(); tab.playerMedia = null
                if (tab === current) { setAddressText(url); updateChrome(); updateFab() }
            }
            override fun onPageFinished(view: WebView, url: String) {
                tab.loading = false; tab.url = url; tab.title = view.title.orEmpty()
                view.evaluateJavascript(MediaSniffer.script, null)
                if (!tab.isPrivate && url.startsWith("http")) lifecycleScope.launch {
                    db.history().insert(HistoryEntity(url = url, title = tab.title.ifBlank { url }))
                }
                if (tab === current) updateChrome()
            }
            override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
                tab.url = url
                if (tab === current && !b.addressInput.hasFocus()) setAddressText(url)
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.scheme == "http" || u.scheme == "https" || u.scheme == "about" || u.scheme == "blob" || u.scheme == "data") return false
                if (request.isForMainFrame || request.hasGesture()) runCatching {
                    startActivity(Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME).apply { addCategory(Intent.CATEGORY_BROWSABLE); component = null; selector = null })
                }.onFailure { if (it !is ActivityNotFoundException) UiUtil.toast(this@MainActivity, "Não foi possível abrir o link") }
                return true
            }
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val url = request.url.toString()
                val pageHost = Urls.host(tab.url)
                if (app.adBlocker.shouldBlock(url, request.url.host, pageHost, request.isForMainFrame, request.requestHeaders["Accept"])) {
                    return WebResourceResponse("text/plain", "utf-8", 403, "Blocked", emptyMap(), ByteArrayInputStream(ByteArray(0)))
                }
                MediaSniffer.classify(url)?.let { kind ->
                    runOnUiThread { addSniffed(tab, MediaSniffer.cleanUrl(url), kind) }
                }
                return null
            }
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: android.webkit.WebResourceError) {
                if (!request.isForMainFrame) return
                val html = "<html><body style='background:#0B0C0F;color:#F1F2F4;font-family:sans-serif;padding:32px'>" +
                    "<h2>Não foi possível abrir a página</h2><p style='color:#9298A3'>${error.description}</p>" +
                    "<p style='color:#9298A3'>${request.url}</p></body></html>"
                view.loadDataWithBaseURL(request.url.toString(), html, "text/html", "utf-8", request.url.toString())
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                tab.progress = newProgress
                if (newProgress >= 100) tab.loading = false
                if (tab === current) updateChrome()
            }
            override fun onReceivedTitle(view: WebView, title: String?) {
                tab.title = title.orEmpty()
                if (!tab.isPrivate && tab.url.startsWith("http")) lifecycleScope.launch { db.history().updateTitle(tab.url, tab.title) }
            }
            override fun onReceivedIcon(view: WebView, icon: Bitmap?) { tab.favicon = icon }
            override fun onShowCustomView(view: View, callback: CustomViewCallback) { enterFullscreen(view, callback) }
            override fun onHideCustomView() { exitFullscreen() }
            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                if (!isUserGesture) return false  // bloqueia pop-ups automáticos
                val newTab = tabs.create(tab.isPrivate, "about:blank")
                ensureWebView(newTab)
                (resultMsg.obj as WebView.WebViewTransport).webView = newTab.webView
                resultMsg.sendToTarget()
                showTab(newTab)
                return true
            }
            override fun onCloseWindow(window: WebView) { tabs.tabs.firstOrNull { it.webView === window }?.let { closeTab(it) } }
            override fun onShowFileChooser(wv: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = cb
                return try { filePicker.launch(params.createIntent()); true } catch (e: Exception) { fileCallback = null; false }
            }
            override fun onJsAlert(view: WebView, url: String, message: String, result: JsResult): Boolean {
                MaterialAlertDialogBuilder(this@MainActivity).setMessage(message)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }.setOnCancelListener { result.cancel() }.show()
                return true
            }
            override fun onJsConfirm(view: WebView, url: String, message: String, result: JsResult): Boolean {
                MaterialAlertDialogBuilder(this@MainActivity).setMessage(message)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                    .setNegativeButton(android.R.string.cancel) { _, _ -> result.cancel() }.setOnCancelListener { result.cancel() }.show()
                return true
            }
            override fun onPermissionRequest(request: android.webkit.PermissionRequest) { request.deny() }
        }
    }

    private fun showTabsSheet() {
        val dialog = BottomSheetDialog(this)
        val v = layoutInflater.inflate(R.layout.sheet_tabs, null)
        val list = v.findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.tabsList)
        val title = v.findViewById<TextView>(R.id.tabsTitle)
        list.layoutManager = LinearLayoutManager(this)
        fun refresh() {
            title.text = "Abas (${tabs.tabs.size})"
            list.adapter = TabAdapter(tabs.tabs, current, { t -> dialog.dismiss(); showTab(t) }, { t -> closeTab(t); if (tabs.tabs.isEmpty()) dialog.dismiss() else refresh() })
        }
        refresh()
        v.findViewById<View>(R.id.btnNewTab).setOnClickListener { dialog.dismiss(); newTab(false) }
        v.findViewById<View>(R.id.btnNewPrivate).setOnClickListener { dialog.dismiss(); newTab(true) }
        v.findViewById<View>(R.id.btnCloseAll).setOnClickListener {
            tabs.closeAll(); dialog.dismiss(); newTab(false); endPrivateSessionIfNeeded()
        }
        dialog.setContentView(v)
        dialog.show()
    }

    private fun newTab(private: Boolean) {
        val t = tabs.create(private)
        showTab(t)
        focusAddress()
    }

    private fun closeTab(tab: Tab) {
        val wasPrivate = tab.isPrivate
        val next = tabs.close(tab)
        if (next == null) showTab(tabs.create(false)) else showTab(next)
        if (wasPrivate) endPrivateSessionIfNeeded()
    }

    /** Ao fechar a última aba privada, descarta o armazenamento isolado da sessão privada. */
    private fun endPrivateSessionIfNeeded() {
        if (tabs.privateCount() > 0) return
        if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            runCatching { androidx.webkit.ProfileStore.getInstance().deleteProfile(PRIVATE_PROFILE) }
        }
        app.downloads.clearPrivate()
    }

    // ───────────────────────── Vídeos e downloads ─────────────────────────

    private fun addSniffed(tab: Tab, url: String, kind: FoundMedia.Kind) {
        if (tab.media.containsKey(url)) return
        if (tab.media.size >= 24) tab.media.remove(tab.media.keys.first())
        tab.media[url] = FoundMedia(url, kind, tab.url)
        if (tab === current) updateFab()
    }

    private fun onJsMedia(tab: Tab, m: FoundMedia) {
        tab.playerMedia = m
        if (m.url != "blob:") tab.media[m.url] = m
        if (tab === current) updateFab()
    }

    /** Lista candidatos; o vídeo em reprodução vem primeiro. */
    private fun candidates(tab: Tab): List<FoundMedia> {
        val player = tab.playerMedia?.takeIf { it.url != "blob:" }
        val rest = tab.media.values.filter { it.url != player?.url }.sortedByDescending { it.foundAt }.take(8)
        return listOfNotNull(player) + rest
    }

    private fun titleFor(tab: Tab, m: FoundMedia): String? {
        m.title?.takeIf { it.isNotBlank() }?.let { return it }
        val p = tab.playerMedia
        if (p != null && (p.url == "blob:" || p.url == m.url)) return p.title
        return null
    }

    private fun updateFab() {
        val t = current
        val list = if (t == null || t.isHome) emptyList() else candidates(t)
        if (list.isEmpty()) { b.fabMedia.visibility = View.GONE; return }
        b.fabMedia.text = if (list.size > 1) "Vídeos (${list.size})" else "Baixar vídeo"
        b.fabMedia.visibility = View.VISIBLE
    }

    private fun onMediaFabClick() {
        val t = current ?: return
        val list = candidates(t)
        when {
            list.isEmpty() -> UiUtil.toast(this, "Nenhum vídeo detectado nesta página")
            list.size == 1 -> showDownloadDialog(list[0], t, nameFor(t, list[0]))
            else -> {
                val labels = list.map { m -> (titleFor(t, m) ?: FileNames.sanitize(Uri.parse(m.url).lastPathSegment.orEmpty())).ifBlank { Urls.displayHost(m.url) } + " · " + kindLabel(m.kind) }
                MaterialAlertDialogBuilder(this).setTitle("Vídeos desta página")
                    .setItems(labels.toTypedArray()) { _, i -> showDownloadDialog(list[i], t, nameFor(t, list[i])) }.show()
            }
        }
    }

    private fun kindLabel(k: FoundMedia.Kind) = when (k) { FoundMedia.Kind.FILE -> "arquivo"; FoundMedia.Kind.HLS -> "HLS"; FoundMedia.Kind.DASH -> "DASH" }

    private fun nameFor(tab: Tab, m: FoundMedia): String {
        val title = titleFor(tab, m)
        val name = FileNames.build(title, m.url, null, m.mime ?: if (m.kind == FoundMedia.Kind.FILE) null else "video/mp4")
        if (title == null && FileNames.isGeneric(name)) {
            val page = tab.title.takeIf { it.isNotBlank() }
            if (page != null) return FileNames.build(page, m.url, null, "video/mp4")
        }
        return name
    }

    private fun showDownloadDialog(m: FoundMedia, tab: Tab, suggested: String) {
        if (m.url == "blob:" || m.url.startsWith("blob:")) {
            MaterialAlertDialogBuilder(this).setTitle("Vídeo não baixável")
                .setMessage("Este player usa um fluxo interno do navegador sem um endereço de arquivo. O FivemL só baixa quando o link do vídeo é identificável.")
                .setPositiveButton(android.R.string.ok, null).show()
            return
        }
        val field = EditText(this).apply { setText(suggested); setSelectAllOnFocus(true); isSingleLine = false; maxLines = 3 }
        val box = LinearLayout(this).apply {
            val p = (20 * resources.displayMetrics.density).toInt(); setPadding(p, p / 2, p, 0); orientation = LinearLayout.VERTICAL
            addView(TextView(context).apply { text = "Nome do arquivo (${kindLabel(m.kind)} · ${Urls.displayHost(m.url)})"; setTextColor(getColor(R.color.text_secondary)); textSize = 12f })
            addView(field)
        }
        val builder = MaterialAlertDialogBuilder(this).setTitle(if (m.kind == FoundMedia.Kind.DASH) "Vídeo DASH" else "Baixar").setView(box)
            .setNeutralButton("Assistir") { _, _ -> playMedia(m, field.text.toString(), tab) }
            .setNegativeButton(android.R.string.cancel, null)
        if (m.kind == FoundMedia.Kind.DASH) {
            builder.setMessage("O download de DASH não é suportado. Você pode assistir no player integrado.")
        } else {
            builder.setPositiveButton("Baixar") { _, _ -> startDownload(m, field.text.toString(), tab) }
        }
        builder.show()
    }

    private fun playMedia(m: FoundMedia, name: String, tab: Tab) {
        startActivity(Intent(this, PlayerActivity::class.java)
            .putExtra(PlayerActivity.EXTRA_URL, m.url).putExtra(PlayerActivity.EXTRA_TITLE, name)
            .putExtra(PlayerActivity.EXTRA_PAGE, tab.url).putExtra(PlayerActivity.EXTRA_KIND, m.kind.name)
            .putExtra(PlayerActivity.EXTRA_PRIVATE, tab.isPrivate).putExtra(PlayerActivity.EXTRA_POSTER, m.poster))
    }

    private fun startDownload(m: FoundMedia, rawName: String, tab: Tab) {
        val name = FileNames.sanitize(rawName).ifBlank { "video" }
        val proceed = {
            val cookie = runCatching { CookieManager.getInstance().getCookie(m.url) }.getOrNull()
            val id = app.downloads.enqueue(DownloadCenter.Request(
                url = m.url, pageUrl = tab.url.takeIf { it.startsWith("http") }, fileName = name, mimeType = m.mime,
                thumbnailUrl = m.poster, isPrivate = tab.isPrivate, isHls = m.kind == FoundMedia.Kind.HLS, cookie = cookie))
            val msg = if (id < 0) "Este download já está em andamento" else "Download iniciado: $name"
            Snackbar.make(b.root, msg, Snackbar.LENGTH_LONG).setAction("Downloads") { startActivity(Intent(this, DownloadsActivity::class.java)) }.show()
        }
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED && !prefs.notificationsAsked) {
            prefs.notificationsAsked = true
            pendingAfterPermission = proceed
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else proceed()
    }

    // ───────────────────────── Menu ─────────────────────────

    private fun showMenu() {
        val dialog = BottomSheetDialog(this)
        val v = layoutInflater.inflate(R.layout.sheet_menu, null)
        val t = current
        val page = t?.takeIf { !it.isHome }
        val items = listOf(
            MenuItem(R.drawable.ic_download, "Downloads") { startActivity(Intent(this, DownloadsActivity::class.java)) },
            MenuItem(R.drawable.ic_history, "Histórico") { startActivity(Intent(this, HistoryActivity::class.java).putExtra("open_in_new", true)) },
            MenuItem(R.drawable.ic_star, "Favoritos") { startActivity(Intent(this, BookmarksActivity::class.java)) },
            MenuItem(R.drawable.ic_tabs, "Abas") { showTabsSheet() },
            MenuItem(R.drawable.ic_private, "Nova aba privada") { newTab(true) },
            MenuItem(R.drawable.ic_shield, "Bloqueador") { showAdBlockDialog() },
            MenuItem(R.drawable.ic_star_border, "Favoritar página") { addBookmark(false) },
            MenuItem(R.drawable.ic_add, "Atalho na inicial") { addBookmark(true) },
            MenuItem(R.drawable.ic_share, "Compartilhar") { sharePage() },
            MenuItem(R.drawable.ic_globe, if (prefs.desktopMode) "Modo celular" else "Modo desktop") { toggleDesktop() },
            MenuItem(R.drawable.ic_play, "Vídeos da página") { if (page != null) onMediaFabClick() else UiUtil.toast(this, "Abra uma página primeiro") },
            MenuItem(R.drawable.ic_delete, "Limpar dados") { showClearDataDialog() },
            MenuItem(R.drawable.ic_paste, "Personalizar início") { showHomeCustomization() },
            MenuItem(R.drawable.ic_settings, "Configurações") { startActivity(Intent(this, SettingsActivity::class.java)) },
        )
        val grid = v.findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.menuGrid)
        grid.layoutManager = androidx.recyclerview.widget.GridLayoutManager(this, 4)
        grid.adapter = MenuAdapter(items) { dialog.dismiss() }
        dialog.setContentView(v)
        dialog.show()
    }

    private fun addBookmark(shortcut: Boolean) {
        val t = current?.takeIf { !it.isHome } ?: return UiUtil.toast(this, "Abra uma página primeiro")
        lifecycleScope.launch {
            val existing = db.bookmarks().findByUrl(t.url)
            if (existing == null) {
                db.bookmarks().insert(BookmarkEntity(url = t.url, title = t.title.ifBlank { Urls.displayHost(t.url) }, position = db.bookmarks().nextPosition(), isShortcut = shortcut))
                UiUtil.toast(this@MainActivity, if (shortcut) "Atalho adicionado" else "Favorito adicionado")
            } else {
                db.bookmarks().update(existing.copy(isShortcut = existing.isShortcut || shortcut))
                UiUtil.toast(this@MainActivity, if (shortcut) "Atalho adicionado" else "Já está nos favoritos")
            }
        }
    }

    private fun sharePage() {
        val t = current?.takeIf { !it.isHome } ?: return UiUtil.toast(this, "Abra uma página primeiro")
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
            .putExtra(Intent.EXTRA_SUBJECT, t.title).putExtra(Intent.EXTRA_TEXT, t.url), "Compartilhar página"))
    }

    private fun toggleDesktop() {
        prefs.desktopMode = !prefs.desktopMode
        tabs.tabs.forEach { t -> t.webView?.settings?.userAgentString = if (prefs.desktopMode)
            Net.USER_AGENT.replace("Mobile Safari", "Safari").replace("Android 15; RMX3710", "X11; Linux x86_64") else null }
        current?.takeIf { !it.isHome }?.webView?.reload()
    }

    private fun showAdBlockDialog() {
        val blocker = app.adBlocker
        val host = Urls.host(current?.url)?.removePrefix("www.")
        val siteAllowed = blocker.isAllowedSite(host)
        val msg = "Bloqueios nesta sessão: ${blocker.sessionBlocked}\nTotal: ${blocker.totalBlocked}\nDomínios na lista: ${blocker.hostCount}" +
            (if (host != null) "\n\nSite atual: $host" else "")
        val b2 = MaterialAlertDialogBuilder(this).setTitle("Bloqueador de anúncios").setMessage(msg)
            .setPositiveButton(if (blocker.enabled) "Desativar" else "Ativar") { _, _ -> app.prefs.adBlockEnabled = !blocker.enabled; current?.webView?.reload() }
            .setNegativeButton("Fechar", null)
        if (host != null) b2.setNeutralButton(if (siteAllowed) "Bloquear neste site" else "Permitir neste site") { _, _ ->
            blocker.setSiteAllowed(host, !siteAllowed); current?.webView?.postDelayed({ current?.webView?.reload() }, 250)
        }
        b2.show()
    }

    private fun showClearDataDialog() {
        val labels = arrayOf("Histórico de navegação", "Pesquisas recentes", "Cookies", "Cache e arquivos temporários", "Dados de sites (armazenamento local)")
        val checked = booleanArrayOf(true, true, false, true, false)
        MaterialAlertDialogBuilder(this).setTitle("Limpar dados")
            .setMultiChoiceItems(labels, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Limpar") { _, _ ->
                lifecycleScope.launch {
                    if (checked[0]) db.history().clear()
                    if (checked[1]) db.searches().clear()
                }
                if (checked[2]) CookieManager.getInstance().removeAllCookies(null)
                if (checked[3]) { tabs.tabs.forEach { it.webView?.clearCache(true) }; cacheDir.deleteRecursively() }
                if (checked[4]) WebStorage.getInstance().deleteAllData()
                UiUtil.toast(this, "Dados limpos")
            }.setNegativeButton(android.R.string.cancel, null).show()
    }

    private fun showHomeCustomization() {
        val items = arrayOf(
            "Escolher papel de parede", "Remover papel de parede (fundo escuro)",
            (if (prefs.showShortcutsOnHome) "Ocultar" else "Mostrar") + " atalhos",
            (if (prefs.showSearchHistoryOnHome) "Ocultar" else "Mostrar") + " pesquisas recentes",
        )
        MaterialAlertDialogBuilder(this).setTitle("Página inicial").setItems(items) { _, i ->
            when (i) {
                0 -> wallpaperPicker.launch("image/*")
                1 -> { prefs.homeWallpaper?.let { java.io.File(it).delete() }; prefs.homeWallpaper = null; home.applyPrefs() }
                2 -> { prefs.showShortcutsOnHome = !prefs.showShortcutsOnHome; home.applyPrefs() }
                3 -> { prefs.showSearchHistoryOnHome = !prefs.showSearchHistoryOnHome; home.applyPrefs() }
            }
        }.show()
    }

    // ───────────────────────── Tela cheia ─────────────────────────

    private fun enterFullscreen(view: View, callback: WebChromeClient.CustomViewCallback) {
        if (customView != null) { callback.onCustomViewHidden(); return }
        customView = view; customCallback = callback
        b.fullscreenContainer.addView(view, ViewGroup.LayoutParams(-1, -1))
        b.fullscreenContainer.visibility = View.VISIBLE
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    private fun exitFullscreen() {
        val v = customView ?: return
        b.fullscreenContainer.removeView(v)
        b.fullscreenContainer.visibility = View.GONE
        customView = null
        customCallback?.onCustomViewHidden(); customCallback = null
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowInsetsControllerCompat(window, window.decorView).show(WindowInsetsCompat.Type.systemBars())
    }

    // ───────────────────────── Ciclo de vida ─────────────────────────

    override fun onPause() { super.onPause(); tabs.save(); CookieManager.getInstance().flush() }
    override fun onResume() { super.onResume(); home.refreshEngine(); home.applyPrefs(); updateChrome() }

    override fun onDestroy() {
        tabs.tabs.forEach { it.webView?.let { w -> (w.parent as? ViewGroup)?.removeView(w); w.destroy() }; it.webView = null }
        super.onDestroy()
    }

    companion object {
        const val ACTION_OPEN_DOWNLOADS = "com.fiveml.browser.OPEN_DOWNLOADS"
        const val PRIVATE_PROFILE = "fiveml_private"
    }
}
