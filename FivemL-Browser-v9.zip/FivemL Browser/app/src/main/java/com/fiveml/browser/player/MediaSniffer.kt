package com.fiveml.browser.player

import android.net.Uri
import android.webkit.JavascriptInterface

data class FoundMedia(
    val url: String,
    val kind: Kind,
    val pageUrl: String?,
    val title: String? = null,
    val poster: String? = null,
    val fromPlayer: Boolean = false,
    val mime: String? = null,
    val foundAt: Long = System.currentTimeMillis(),
) { enum class Kind { FILE, HLS, DASH } }

/** Detecta mídia completa (ignora init segments e segmentos) e recebe dados do <video> ativo via JS. */
object MediaSniffer {
    private val fileExt = Regex("""\.(mp4|webm|m4v|mov|mkv|3gp)(?=$|[?#])""", RegexOption.IGNORE_CASE)
    private val hlsExt = Regex("""\.m3u8(?=$|[?#])""", RegexOption.IGNORE_CASE)
    private val dashExt = Regex("""\.mpd(?=$|[?#])""", RegexOption.IGNORE_CASE)
    private val partialParams = setOf("bytestart", "byteend", "range")

    private fun lastSegment(url: String): String =
        runCatching { Uri.parse(url).lastPathSegment.orEmpty().lowercase() }.getOrDefault("")

    fun isFragment(url: String): Boolean {
        val s = lastSegment(url)
        return s.startsWith("init") || s.startsWith("segment") || s.startsWith("chunk") || s.startsWith("seg-") ||
            s.endsWith(".m4s") || s.endsWith(".ts") || Regex("""^\d+\.(mp4|m4s)$""").matches(s)
    }

    fun classify(url: String): FoundMedia.Kind? {
        if (!(url.startsWith("http://") || url.startsWith("https://"))) return null
        if (isFragment(url)) return null
        return when {
            hlsExt.containsMatchIn(url) -> FoundMedia.Kind.HLS
            dashExt.containsMatchIn(url) -> FoundMedia.Kind.DASH
            fileExt.containsMatchIn(url) -> FoundMedia.Kind.FILE
            else -> null
        }
    }

    /** CDNs que servem só um trecho (bytestart/byteend) precisam do link completo. */
    fun cleanUrl(url: String): String {
        val uri = Uri.parse(url)
        val names = uri.queryParameterNames
        if (names.none { it.lowercase() in partialParams }) return url
        val b = uri.buildUpon().clearQuery()
        for (n in names) { if (n.lowercase() in partialParams) continue; for (v in uri.getQueryParameters(n)) b.appendQueryParameter(n, v) }
        return b.build().toString()
    }

    /** Playlists "master" de HLS costumam ser o que o usuário quer; mantém o último link relevante por página. */
    class Bridge(private val onMedia: (FoundMedia) -> Unit) {
        @JavascriptInterface
        fun onVideo(src: String, pageUrl: String, title: String, poster: String, playing: Boolean) {
            val kind = classify(src) ?: return
            onMedia(FoundMedia(cleanUrl(src), kind, pageUrl, title.ifBlank { null }, poster.ifBlank { null }, fromPlayer = playing || true))
        }
        @JavascriptInterface
        fun onBlob(pageUrl: String, title: String, poster: String) {
            onMedia(FoundMedia("blob:", FoundMedia.Kind.FILE, pageUrl, title.ifBlank { null }, poster.ifBlank { null }, fromPlayer = true))
        }
    }

    /**
     * Identifica o vídeo em reprodução (o maior <video> visível ou o que está tocando) e o título dele
     * pela ordem: legenda/descrição próxima > atributos do player > og:title > JSON-LD > título da página.
     */
    val script = """
(function(){
  if (window.__fvInstalled) { if (window.__fvScan) window.__fvScan(); return; }
  window.__fvInstalled = true;
  function clean(s){ return (s||'').replace(/\s+/g,' ').trim().slice(0,200); }
  function meta(p){ var m=document.querySelector('meta[property="'+p+'"],meta[name="'+p+'"]'); return m?clean(m.content):''; }
  function ld(){
    try{ var n=document.querySelectorAll('script[type="application/ld+json"]');
      for(var i=0;i<n.length;i++){ var j=JSON.parse(n[i].textContent); var a=Array.isArray(j)?j:[j];
        for(var k=0;k<a.length;k++){ var o=a[k]; if(o&&(o['@type']==='VideoObject'||(o['@graph']&&0))&&o.name) return clean(o.name); } } }catch(e){}
    return '';
  }
  function nearby(v){
    var sel='[data-e2e*="desc"],[data-testid="tweetText"],[data-testid*="caption"],[class*="caption"],[class*="description"],[class*="video-title"],[class*="videoTitle"],h1,h2';
    var el=v;
    for(var i=0;i<6&&el;i++,el=el.parentElement){
      var c=el.querySelector&&el.querySelector(sel);
      if(c&&clean(c.innerText).length>2&&!c.contains(document.body)) return clean(c.innerText);
    }
    return '';
  }
  function titleFor(v){
    return nearby(v)||clean(v.getAttribute('title'))||clean(v.getAttribute('aria-label'))||clean(v.getAttribute('data-title'))||
      meta('og:title')||ld()||clean(document.title);
  }
  function area(v){ var r=v.getBoundingClientRect(); return Math.max(0,r.width)*Math.max(0,r.height); }
  function scan(){
    var vs=[].slice.call(document.querySelectorAll('video'));
    if(!vs.length) return;
    vs.sort(function(a,b){ var pa=a.paused?0:1, pb=b.paused?0:1; return pb!==pa?pb-pa:area(b)-area(a); });
    var v=vs[0];
    var src=v.currentSrc||v.src||'';
    if(!src){ var s=v.querySelector('source'); if(s) src=s.src; }
    var t=titleFor(v), p=v.poster||meta('og:image');
    if(src&&src.indexOf('blob:')!==0) FivemBridge.onVideo(src,location.href,t,p||'',!v.paused);
    else FivemBridge.onBlob(location.href,t,p||'');
  }
  window.__fvScan=scan;
  document.addEventListener('play',function(){ setTimeout(scan,150); },true);
  document.addEventListener('loadeddata',function(){ setTimeout(scan,150); },true);
  new MutationObserver(function(){ clearTimeout(window.__fvT); window.__fvT=setTimeout(scan,600); }).observe(document.documentElement,{childList:true,subtree:true});
  scan();
})();
""".trimIndent()
}
