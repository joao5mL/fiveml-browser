package com.fiveml.browser.ui

import android.content.Context
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import coil.load
import com.fiveml.browser.R
import com.fiveml.browser.util.Urls
import com.google.android.material.dialog.MaterialAlertDialogBuilder

object UiUtil {
    /** Mostra o favicon do site; enquanto não carrega, exibe a inicial do título. */
    fun bindIcon(icon: ImageView, letter: TextView, url: String, title: String) {
        letter.text = (title.firstOrNull() ?: Urls.displayHost(url).firstOrNull() ?: '•').uppercaseChar().toString()
        icon.visibility = View.GONE
        letter.visibility = View.VISIBLE
        val fav = Urls.faviconUrl(url) ?: return
        icon.load(fav) {
            listener(onSuccess = { _, _ -> icon.visibility = View.VISIBLE; letter.visibility = View.GONE })
        }
    }

    fun toast(context: Context, msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

    fun hideKeyboard(view: View) {
        (view.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(view.windowToken, 0)
    }

    fun showKeyboard(view: EditText) {
        view.requestFocus()
        (view.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(view, InputMethodManager.SHOW_IMPLICIT)
    }

    fun confirm(context: Context, title: String, message: String, positive: String, onYes: () -> Unit) {
        MaterialAlertDialogBuilder(context).setTitle(title).setMessage(message)
            .setPositiveButton(positive) { _, _ -> onYes() }
            .setNegativeButton(android.R.string.cancel, null).show()
    }

    /** Diálogo com um ou dois campos de texto. */
    fun input2(
        context: Context, title: String, hint1: String, value1: String, hint2: String?, value2: String,
        onOk: (String, String) -> Unit,
    ) {
        val layout = android.widget.LinearLayout(context).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            val pad = (20 * context.resources.displayMetrics.density).toInt()
            setPadding(pad, pad / 2, pad, 0)
        }
        val e1 = EditText(context).apply { hint = hint1; setText(value1); setSingleLine(); setSelectAllOnFocus(true) }
        layout.addView(e1)
        var e2: EditText? = null
        if (hint2 != null) {
            e2 = EditText(context).apply { hint = hint2; setText(value2); setSingleLine(); inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI }
            layout.addView(e2)
        }
        MaterialAlertDialogBuilder(context).setTitle(title).setView(layout)
            .setPositiveButton(android.R.string.ok) { _, _ -> onOk(e1.text.toString().trim(), e2?.text?.toString()?.trim().orEmpty()) }
            .setNegativeButton(android.R.string.cancel, null).show()
    }

    fun iconFor(ext: String): Int = R.drawable.ic_download
}
