package com.fiveml.browser.ui

import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.fiveml.browser.BuildConfig
import com.fiveml.browser.FivemApp
import com.fiveml.browser.settings.Prefs
import com.fiveml.browser.util.Formatters
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import kotlinx.coroutines.launch

/** Configurações agrupadas por categoria. Todas as opções têm efeito real no app. */
class SettingsActivity : AppCompatActivity() {
    private val app get() = application as FivemApp
    private val prefs get() = app.prefs
    private lateinit var content: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(getColor(com.fiveml.browser.R.color.bg_main)) }
        val bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(getColor(com.fiveml.browser.R.color.bg_secondary))
            minimumHeight = dp(56)
        }
        val back = android.widget.ImageButton(this).apply {
            setImageResource(com.fiveml.browser.R.drawable.ic_back); setColorFilter(getColor(com.fiveml.browser.R.color.text_primary))
            setBackgroundResource(android.R.color.transparent); setPadding(dp(14), dp(14), dp(14), dp(14))
            setOnClickListener { finish() }
        }
        bar.addView(back, LinearLayout.LayoutParams(dp(52), dp(52)))
        bar.addView(TextView(this).apply { text = "Configurações"; textSize = 19f; setTextColor(getColor(com.fiveml.browser.R.color.text_primary)); setTypeface(typeface, android.graphics.Typeface.BOLD) })
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(24)) }
        root.addView(ScrollView(this).apply { addView(content) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        build()
    }

    private fun build() {
        content.removeAllViews()
        section("Aparência e página inicial")
        switch("Mostrar atalhos na página inicial", "Exibe seus atalhos personalizados", prefs.showShortcutsOnHome) { prefs.showShortcutsOnHome = it }
        switch("Mostrar pesquisas recentes", "Exibe o histórico de pesquisas na página inicial", prefs.showSearchHistoryOnHome) { prefs.showSearchHistoryOnHome = it }
        switch("Restaurar abas ao abrir", "Reabre as abas normais da última sessão", prefs.restoreTabs) { prefs.restoreTabs = it }
        info("Tema", "Escuro (padrão do FivemL). O papel de parede é alterado em Menu › Personalizar início.")

        section("Pesquisa")
        val engineName = Prefs.ENGINES[prefs.searchEngine]?.first ?: "Google"
        row("Mecanismo de pesquisa", engineName) {
            val keys = Prefs.ENGINES.keys.toList()
            MaterialAlertDialogBuilder(this).setTitle("Mecanismo de pesquisa")
                .setSingleChoiceItems(Prefs.ENGINES.values.map { it.first }.toTypedArray(), keys.indexOf(prefs.searchEngine)) { d, i -> prefs.searchEngine = keys[i]; d.dismiss(); build() }.show()
        }

        section("Downloads")
        row("Downloads simultâneos", prefs.maxParallelDownloads.toString()) {
            MaterialAlertDialogBuilder(this).setTitle("Downloads simultâneos")
                .setSingleChoiceItems(arrayOf("1", "2", "3", "4", "5", "6"), prefs.maxParallelDownloads - 1) { d, i -> prefs.maxParallelDownloads = i + 1; d.dismiss(); build() }.show()
        }
        row("Limite de velocidade", if (prefs.speedLimitKbps == 0) "Sem limite" else "${prefs.speedLimitKbps} KB/s") {
            val opts = intArrayOf(0, 256, 512, 1024, 2048, 5120)
            MaterialAlertDialogBuilder(this).setTitle("Limite de velocidade")
                .setItems(opts.map { if (it == 0) "Sem limite" else "$it KB/s" }.toTypedArray()) { _, i -> prefs.speedLimitKbps = opts[i]; build() }.show()
        }
        switch("Somente Wi-Fi", "Não baixa usando dados móveis", prefs.wifiOnly) { prefs.wifiOnly = it }
        info("Pasta de armazenamento", "Vídeos: Movies/FivemL · Áudio: Music/FivemL · Outros: Download/FivemL")

        section("Notificações")
        row("Permissão de notificações", if (com.fiveml.browser.notify.Notifier.canNotify(this)) "Concedida" else "Não concedida — toque para ajustar") {
            startActivity(android.content.Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, packageName))
        }

        section("Bloqueador de anúncios")
        switch("Ativar bloqueador", "Bloqueia domínios de anúncios e rastreadores. Nunca bloqueia vídeo, áudio ou streaming.", prefs.adBlockEnabled) { prefs.adBlockEnabled = it }
        row("Atualizar listas de filtros", if (prefs.filterListUpdatedAt == 0L) "Usando lista padrão (${app.adBlocker.hostCount} domínios)" else "Atualizada em ${Formatters.date(prefs.filterListUpdatedAt)}") {
            lifecycleScope.launch {
                runCatching { app.adBlocker.updateLists() }
                    .onSuccess { UiUtil.toast(this@SettingsActivity, "Lista atualizada: $it domínios"); build() }
                    .onFailure { UiUtil.toast(this@SettingsActivity, "Falha ao atualizar: ${it.message}") }
            }
        }
        row("Sites com exceção", app.adBlocker.allowedSites().let { if (it.isEmpty()) "Nenhum" else it.joinToString(", ") }) {
            val sites = app.adBlocker.allowedSites()
            if (sites.isEmpty()) UiUtil.toast(this, "Use Menu › Bloqueador para liberar um site")
            else MaterialAlertDialogBuilder(this).setTitle("Remover exceção").setItems(sites.toTypedArray()) { _, i -> app.adBlocker.setSiteAllowed(sites[i], false); content.postDelayed({ build() }, 300) }.show()
        }
        info("Estatísticas", "Total bloqueado: ${app.adBlocker.totalBlocked}")

        section("Privacidade")
        switch("Cookies de terceiros", "Permite cookies de outros domínios nas páginas", prefs.thirdPartyCookies) { prefs.thirdPartyCookies = it }
        row("Limpar histórico", "Remove todos os sites visitados") {
            UiUtil.confirm(this, "Limpar histórico", "Remover todo o histórico?", "Limpar") { lifecycleScope.launch { app.db.history().clear() } }
        }
        row("Limpar pesquisas recentes", "") { lifecycleScope.launch { app.db.searches().clear(); UiUtil.toast(this@SettingsActivity, "Pesquisas removidas") } }
        row("Limpar cookies", "") { android.webkit.CookieManager.getInstance().removeAllCookies { UiUtil.toast(this, "Cookies removidos") } }
        row("Limpar cache", "") { android.webkit.WebView(this).apply { clearCache(true); destroy() }; cacheDir.deleteRecursively(); UiUtil.toast(this, "Cache limpo") }
        info("Navegação privada", "Abas privadas não salvam histórico, pesquisas nem downloads na lista. O armazenamento é isolado quando o WebView do aparelho suporta perfis.")

        section("Reprodução multimídia")
        info("Player integrado", "Reproduz MP4, WebM, HLS e DASH, com tela cheia, controle de qualidade quando a fonte oferece e áudio.")

        section("Avançado")
        switch("JavaScript", "Necessário para a maioria dos sites. Aplica-se a novas abas.", prefs.javascriptEnabled) { prefs.javascriptEnabled = it }
        switch("Modo desktop", "Solicita a versão para computador dos sites", prefs.desktopMode) { prefs.desktopMode = it }

        section("Sobre o FivemL")
        info("FivemL Browser", "Versão ${BuildConfig.VERSION_NAME}\nMotor de renderização: Android WebView (Chromium)")
    }

    private fun section(title: String) {
        content.addView(TextView(this).apply {
            text = title.uppercase(); textSize = 12f; letterSpacing = 0.1f
            setTextColor(getColor(com.fiveml.browser.R.color.accent_dim)); setPadding(dp(20), dp(24), dp(20), dp(6))
        })
    }

    private fun row(title: String, subtitle: String, onClick: () -> Unit) {
        content.addView(textBlock(title, subtitle).apply { setOnClickListener { onClick() }; isClickable = true; setBackgroundResource(resolveSelectable()) })
    }

    private fun info(title: String, subtitle: String) { content.addView(textBlock(title, subtitle)) }

    private fun resolveSelectable(): Int {
        val tv = android.util.TypedValue(); theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true); return tv.resourceId
    }

    private fun textBlock(title: String, subtitle: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(12), dp(20), dp(12))
        addView(TextView(context).apply { text = title; textSize = 15f; setTextColor(getColor(com.fiveml.browser.R.color.text_primary)) })
        if (subtitle.isNotBlank()) addView(TextView(context).apply { text = subtitle; textSize = 12.5f; setTextColor(getColor(com.fiveml.browser.R.color.text_secondary)) })
    }

    private fun switch(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, 0, dp(16), 0) }
        row.addView(textBlock(title, subtitle), LinearLayout.LayoutParams(0, -2, 1f))
        val sw = MaterialSwitch(this).apply { isChecked = checked; setOnCheckedChangeListener { _, c -> onChange(c) } }
        row.addView(sw)
        row.setOnClickListener { sw.toggle() }
        content.addView(row, ViewGroup.LayoutParams(-1, -2))
    }
}
