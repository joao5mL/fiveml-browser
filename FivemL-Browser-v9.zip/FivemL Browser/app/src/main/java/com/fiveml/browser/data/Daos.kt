package com.fiveml.browser.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface DownloadDao {
    @Query("SELECT * FROM downloads WHERE isPrivate = 0 ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE id = :id")
    suspend fun get(id: Long): DownloadEntity?

    @Query("SELECT * FROM downloads WHERE status IN ('queued','running')")
    suspend fun activeOrQueued(): List<DownloadEntity>

    @Query("SELECT * FROM downloads WHERE url = :url AND status IN ('queued','running','paused') LIMIT 1")
    suspend fun findInProgressByUrl(url: String): DownloadEntity?

    @Query("UPDATE downloads SET status = 'paused' WHERE status IN ('running','queued')")
    suspend fun markInterruptedAsPaused()

    @Insert suspend fun insert(item: DownloadEntity): Long
    @Update suspend fun update(item: DownloadEntity)
    @Query("DELETE FROM downloads WHERE id = :id") suspend fun delete(id: Long)
    @Query("DELETE FROM downloads WHERE isPrivate = 1") suspend fun deletePrivate()
}

@Dao
interface HistoryDao {
    @Query("SELECT * FROM history ORDER BY visitedAt DESC LIMIT 1000")
    fun observe(): Flow<List<HistoryEntity>>

    @Query("SELECT * FROM history WHERE title LIKE '%' || :q || '%' OR url LIKE '%' || :q || '%' ORDER BY visitedAt DESC LIMIT 500")
    suspend fun search(q: String): List<HistoryEntity>

    @Insert suspend fun insert(item: HistoryEntity)
    @Query("DELETE FROM history WHERE id = :id") suspend fun delete(id: Long)
    @Query("DELETE FROM history") suspend fun clear()
    @Query("UPDATE history SET title = :title WHERE url = :url AND visitedAt = (SELECT MAX(visitedAt) FROM history WHERE url = :url)")
    suspend fun updateTitle(url: String, title: String)
}

@Dao
interface BookmarkDao {
    @Query("SELECT * FROM bookmarks ORDER BY position ASC, createdAt ASC")
    fun observeAll(): Flow<List<BookmarkEntity>>

    @Query("SELECT * FROM bookmarks WHERE isShortcut = 1 ORDER BY position ASC, createdAt ASC")
    fun observeShortcuts(): Flow<List<BookmarkEntity>>

    @Query("SELECT * FROM bookmarks WHERE url = :url LIMIT 1")
    suspend fun findByUrl(url: String): BookmarkEntity?

    @Query("SELECT COALESCE(MAX(position), 0) + 1 FROM bookmarks")
    suspend fun nextPosition(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(item: BookmarkEntity): Long
    @Update suspend fun update(item: BookmarkEntity)
    @Delete suspend fun delete(item: BookmarkEntity)
    @Query("DELETE FROM bookmarks WHERE url = :url") suspend fun deleteByUrl(url: String)
}

@Dao
interface SearchDao {
    @Query("SELECT * FROM searches ORDER BY usedAt DESC LIMIT 50")
    fun observe(): Flow<List<SearchEntity>>

    @Query("SELECT * FROM searches WHERE query LIKE :prefix || '%' ORDER BY usedAt DESC LIMIT 6")
    suspend fun suggest(prefix: String): List<SearchEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(item: SearchEntity)
    @Query("DELETE FROM searches WHERE id = :id") suspend fun delete(id: Long)
    @Query("DELETE FROM searches WHERE query = :q") suspend fun deleteByQuery(q: String)
    @Query("DELETE FROM searches") suspend fun clear()
}

@Dao
interface AllowDao {
    @Query("SELECT host FROM adblock_allow") suspend fun all(): List<String>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(item: AllowedSiteEntity)
    @Query("DELETE FROM adblock_allow WHERE host = :host") suspend fun delete(host: String)
}
