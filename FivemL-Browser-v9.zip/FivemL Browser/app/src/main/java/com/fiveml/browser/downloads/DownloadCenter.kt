package com.fiveml.browser.downloads

import android.content.Context
import android.util.Log
import android.webkit.CookieManager
import com.fiveml.browser.data.AppDatabase
import com.fiveml.browser.data.DownloadEntity
import com.fiveml.browser.notify.Notifier
import com.fiveml.browser.settings.Prefs
import com.fiveml.browser.storage.MediaStorage
import com.fiveml.browser.util.FileNames
import com.fiveml.browser.util.Net
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/** Orquestra fila, concorrência, pausa/retomada, validação e publicação dos downloads. */
class DownloadCenter(
    private val context: Context,
    private val db: AppDatabase,
    private val prefs: Prefs,
) {
    data class Live(val received: Long, val total: Long, val speed: Long, val etaSeconds: Long, val fraction: Float = -1f)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val dao = db.downloads()
    private val jobs = ConcurrentHashMap<Long, Job>()
    private val _live = MutableStateFlow<Map<Long, Live>>(emptyMap())
    val live: StateFlow<Map<Long, Live>> = _live.asStateFlow()
    private val engine = DownloadEngine { prefs.speedLimitKbps * 1024L / maxOf(1, jobs.size) }
    private val hls = HlsDownloader()
    private var serviceCallback: ((Int) -> Unit)? = null
    private val lock = Any()
    private val cookies = ConcurrentHashMap<Long, String>()

    fun attachService(cb: (Int) -> Unit) { serviceCallback = cb }
    fun activeCount(): Int = jobs.size

    private fun notifyService() { serviceCallback?.invoke(jobs.size) }

    data class Request(
        val url: String, val pageUrl: String?, val fileName: String, val mimeType: String?,
        val thumbnailUrl: String?, val isPrivate: Boolean, val isHls: Boolean, val cookie: String? = null,
    )

    /** Enfileira um download. Retorna o id ou -1 se já houver o mesmo link em andamento. */
    fun enqueue(req: Request): Long = kotlinx.coroutines.runBlocking {
        dao.findInProgressByUrl(req.url)?.let { return@runBlocking -1L }
        val id = dao.insert(
            DownloadEntity(
                url = req.url, pageUrl = req.pageUrl, fileName = FileNames.sanitize(req.fileName).ifBlank { "arquivo" },
                mimeType = req.mimeType, kind = if (req.isHls) DownloadEntity.KIND_HLS else DownloadEntity.KIND_FILE,
                thumbnailUrl = req.thumbnailUrl, isPrivate = req.isPrivate,
            )
        )
        req.cookie?.let { cookies[id] = it }
        DownloadService.start(context)
        schedule()
        id
    }

    private fun schedule() {
        scope.launch {
            val queued = dao.activeOrQueued().filter { it.status == DownloadEntity.STATUS_QUEUED && !jobs.containsKey(it.id) }
            for (item in queued) {
                if (jobs.size >= prefs.maxParallelDownloads) break
                start(item)
            }
            if (jobs.isEmpty()) notifyService()
        }
    }

    private fun start(initial: DownloadEntity) {
        val job = scope.launch { execute(initial) }
        jobs[initial.id] = job
        notifyService()
    }

    private suspend fun execute(initial: DownloadEntity) {
        var item = initial.copy(status = DownloadEntity.STATUS_RUNNING, error = null)
        dao.update(item)
        Notifier.update(context, item, null)
        try {
            if (prefs.wifiOnly && !isWifi()) throw DownloadFailure("Aguardando Wi-Fi (opção 'somente Wi-Fi' ativa)")
            val cookie = cookies[item.id] ?: runCatching { CookieManager.getInstance().getCookie(item.url) }.getOrNull()
            val ua = Net.USER_AGENT
            if (item.kind == DownloadEntity.KIND_HLS) item = runHls(item, cookie, ua) else item = runFile(item, cookie, ua)
            finish(item)
        } catch (e: CancellationException) {
            kotlinx.coroutines.withContext(kotlinx.coroutines.NonCancellable) {
                val current = dao.get(item.id)
                if (current != null && current.status == DownloadEntity.STATUS_RUNNING) {
                    dao.update(current.copy(status = DownloadEntity.STATUS_PAUSED))
                }
            }
            throw e
        } catch (e: DownloadFailure) {
            fail(item.id, e.message ?: "Falha no download")
        } catch (e: Exception) {
            Log.e(TAG, "Erro inesperado no download ${item.id}", e)
            fail(item.id, e.message ?: e.javaClass.simpleName)
        } finally {
            jobs.remove(item.id)
            _live.value = _live.value - item.id
            notifyService()
            schedule()
        }
    }

    private suspend fun runFile(start: DownloadEntity, cookie: String?, ua: String): DownloadEntity {
        var item = start
        val tmp = File(MediaStorage.tempDir(context), "dl_${item.id}.part")
        var attempts = 0
        var startedAt = System.currentTimeMillis()
        while (true) {
            try {
                val outcome = engine.download(item, tmp, cookie, ua) { p ->
                    val elapsed = (System.currentTimeMillis() - startedAt).coerceAtLeast(1)
                    val eta = if (p.total > 0 && p.bytesPerSec > 0) (p.total - p.received) / p.bytesPerSec else -1
                    publishLive(item, Live(p.received, p.total, p.bytesPerSec, eta))
                }
                item = item.copy(
                    receivedBytes = outcome.received, totalBytes = outcome.total, supportsRange = outcome.supportsRange,
                    etag = outcome.etag, tempPath = tmp.absolutePath,
                    mimeType = item.mimeType ?: outcome.mime,
                )
                // Nome do servidor só entra se o nome atual for genérico
                if (FileNames.isGeneric(item.fileName)) {
                    val better = FileNames.build(null, item.url, outcome.disposition, outcome.mime)
                    if (!FileNames.isGeneric(better)) item = item.copy(fileName = better)
                }
                return item
            } catch (e: DownloadFailure) {
                if (!e.retryable || ++attempts > 4) throw e
                item = item.copy(supportsRange = item.supportsRange || tmp.exists() && tmp.length() > 0)
                dao.update(item.copy(receivedBytes = if (tmp.exists()) tmp.length() else 0))
                delay(1500L * attempts)
                startedAt = System.currentTimeMillis()
            }
        }
    }

    private suspend fun runHls(item: DownloadEntity, cookie: String?, ua: String): DownloadEntity {
        val work = File(MediaStorage.tempDir(context), "hls_${item.id}")
        work.deleteRecursively()
        val res = hls.download(item, work, cookie, ua) { done, total, bytes ->
            publishLive(item, Live(bytes, -1, 0, -1, fraction = done.toFloat() / total))
        }
        val name = if (item.fileName.endsWith(".mp4", true)) item.fileName else item.fileName.substringBeforeLast('.', item.fileName) + ".mp4"
        return item.copy(
            fileName = name, mimeType = "video/mp4", receivedBytes = res.totalBytes, totalBytes = res.totalBytes,
            tempPath = res.file.absolutePath,
        )
    }

    private fun publishLive(item: DownloadEntity, l: Live) {
        _live.value = _live.value + (item.id to l)
        Notifier.update(context, item.copy(status = DownloadEntity.STATUS_RUNNING), l)
    }

    private suspend fun finish(item: DownloadEntity) {
        val file = File(item.tempPath ?: throw DownloadFailure("Arquivo temporário ausente"))
        val check = FileValidator.validate(file, item.totalBytes.takeIf { item.kind == DownloadEntity.KIND_FILE } ?: -1, item.mimeType, item.fileName)
        if (!check.ok) {
            file.delete()
            throw DownloadFailure(check.reason ?: "Arquivo inválido")
        }
        val mime = MediaStorage.mimeFor(item.fileName, item.mimeType)
        val uri = try {
            MediaStorage.publish(context, file, item.fileName, mime)
        } catch (e: Exception) {
            throw DownloadFailure("Erro ao gravar no armazenamento: ${e.message}")
        }
        val size = MediaStorage.size(context, uri)
        if (size <= 0) {
            MediaStorage.delete(context, uri)
            throw DownloadFailure("O arquivo gravado não pôde ser verificado")
        }
        val done = item.copy(
            status = DownloadEntity.STATUS_DONE, finalUri = uri.toString(), receivedBytes = size, totalBytes = size,
            mimeType = mime, finishedAt = System.currentTimeMillis(), error = null, tempPath = null,
        )
        dao.update(done)
        Notifier.finished(context, done)
    }

    private suspend fun fail(id: Long, reason: String) {
        val cur = dao.get(id) ?: return
        val updated = cur.copy(status = DownloadEntity.STATUS_FAILED, error = reason, finishedAt = System.currentTimeMillis())
        dao.update(updated)
        Notifier.finished(context, updated)
    }

    fun pause(id: Long) {
        scope.launch {
            val item = dao.get(id) ?: return@launch
            if (item.kind == DownloadEntity.KIND_HLS) return@launch  // HLS não retoma; apenas cancelar
            jobs[id]?.cancel()
            jobs[id]?.join()
            val cur = dao.get(id) ?: return@launch
            val paused = cur.copy(status = DownloadEntity.STATUS_PAUSED, receivedBytes = tempLength(cur))
            dao.update(paused)
            Notifier.update(context, paused, null)
        }
    }

    fun pauseAll() {
        scope.launch {
            jobs.keys.toList().forEach { id ->
                val job = jobs[id]; job?.cancel(); job?.join()
                dao.get(id)?.let { dao.update(it.copy(status = DownloadEntity.STATUS_PAUSED)) }
            }
        }
    }

    fun resume(id: Long) {
        scope.launch {
            val item = dao.get(id) ?: return@launch
            if (item.status != DownloadEntity.STATUS_PAUSED && item.status != DownloadEntity.STATUS_FAILED) return@launch
            val partial = tempLength(item)
            dao.update(item.copy(status = DownloadEntity.STATUS_QUEUED, error = null, receivedBytes = partial))
            DownloadService.start(context)
            schedule()
        }
    }

    fun retry(id: Long) {
        scope.launch {
            val item = dao.get(id) ?: return@launch
            tempFile(item)?.delete()
            dao.update(item.copy(status = DownloadEntity.STATUS_QUEUED, error = null, receivedBytes = 0, supportsRange = false, etag = null))
            DownloadService.start(context)
            schedule()
        }
    }

    fun cancel(id: Long) {
        scope.launch {
            val job = jobs[id]; job?.cancel(); job?.join()
            val item = dao.get(id) ?: return@launch
            tempFile(item)?.delete()
            File(MediaStorage.tempDir(context), "hls_$id").deleteRecursively()
            Notifier.cancel(context, id)
            dao.delete(id)
        }
    }

    /** Remove o registro e, se pedido, o arquivo público. */
    fun remove(id: Long, deleteFile: Boolean) {
        scope.launch {
            val item = dao.get(id) ?: return@launch
            jobs[id]?.let { it.cancel(); it.join() }
            tempFile(item)?.delete()
            if (deleteFile) item.finalUri?.let { MediaStorage.delete(context, android.net.Uri.parse(it)) }
            Notifier.cancel(context, id)
            dao.delete(id)
        }
    }

    fun clearPrivate() { scope.launch { dao.deletePrivate() } }

    private fun tempFile(item: DownloadEntity): File? = File(MediaStorage.tempDir(context), "dl_${item.id}.part").takeIf { it.exists() }
    private fun tempLength(item: DownloadEntity): Long = tempFile(item)?.length() ?: 0L

    /** Após reinício do app/aparelho, tarefas interrompidas ficam pausadas e podem ser retomadas. */
    fun recoverAfterRestart() {
        scope.launch {
            dao.markInterruptedAsPaused()
        }
    }

    private fun isWifi(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) ||
            caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_ETHERNET)
    }

    companion object {
        private const val TAG = "DownloadCenter"
        const val EXTRA_ID = "download_id"
        const val ACTION_PAUSE = "com.fiveml.browser.PAUSE"
        const val ACTION_RESUME = "com.fiveml.browser.RESUME"
        const val ACTION_CANCEL = "com.fiveml.browser.CANCEL"
    }
}
