# FivemL Browser

Navegador Android nativo (Kotlin) com gerenciador de downloads próprio. Renderização via Android WebView (Chromium); interface, abas, downloads, player e notificações são componentes nativos.

## Módulos

| Pacote | Responsabilidade |
|---|---|
| `ui` | Navegador, página inicial, menu, Downloads, Histórico, Favoritos, Configurações |
| `tabs` | Abas (normais e privadas) e restauração de sessão |
| `downloads` | Motor HTTP (OkHttp, streaming, Range), HLS, validação, fila, serviço em primeiro plano |
| `player` | Detecção de mídia, identificação do título, player Media3 |
| `adblock` | Bloqueio por domínio, listas atualizáveis, exceções por site |
| `notify` | Canais e notificações atualizáveis por tarefa |
| `storage` | MediaStore (`Movies/FivemL`, `Music/FivemL`, `Download/FivemL`) |
| `data` | Room: downloads, histórico, favoritos, pesquisas, exceções |

## Downloads

- Escrita progressiva em arquivo temporário; nada é carregado inteiro em memória.
- Pausa/retomada com `Range` quando o servidor suporta; reinício automático quando não suporta.
- Conclusão somente após: transferência completa, tamanho coerente, arquivo não vazio e validação estrutural (MP4/MOV: `ftyp`, `moov`, `mdat`; WebM/MKV: cabeçalho EBML; respostas HTML/JSON/texto são rejeitadas).
- HLS sem criptografia: manifesto → melhor variante → segmentos → remux com `MediaMuxer` para MP4. Conteúdo com `EXT-X-KEY`, transmissões ao vivo e DASH não são baixados.
- Só após validação o arquivo é publicado no MediaStore.

## Build

JDK 17, Gradle 8.9, Android Gradle Plugin 8.5.2, Kotlin 1.9.24.

```
gradle wrapper --gradle-version 8.9
./gradlew assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`. O workflow `.github/workflows/build.yml` gera `FivemL-Browser.apk`.
