# FivemL Browser 1.3.2

Navegador Android nativo em Kotlin, com motor Android WebView (Chromium), interface Material 3, gerenciador de downloads próprio e player Media3. Esta atualização preserva os módulos existentes e amplia a experiência de abas e a camada de privacidade.

## Módulos

| Pacote | Responsabilidade |
|---|---|
| `ui` | Navegador, página inicial, menu, Downloads, Histórico, Favoritos, Configurações e cartões de abas |
| `tabs` | Abas normais/privadas, restauração de sessão e miniaturas temporárias das páginas |
| `downloads` | Motor HTTP (OkHttp, streaming, Range), HLS, validação, fila e serviço em primeiro plano |
| `player` | Detecção de mídia e player Media3 para formatos suportados |
| `adblock` | Bloqueio por domínio, listas atualizáveis e exceções por site |
| `notify` | Canais e notificações de downloads |
| `storage` | MediaStore (`Movies/FivemL`, `Music/FivemL`, `Download/FivemL`) |
| `data` | Room: downloads, histórico, favoritos, pesquisas e exceções |

## Novidades 1.3.2

- **Abas em grade de cartões:** miniaturas visuais das páginas, favicon, domínio, número da aba, estado ativo e identificação de abas privadas.
- **Ações de abas:** fechar individualmente, alternar entre páginas, criar aba normal/privada e fechar todas.
- **Menu personalizável:** posição superior ou inferior, configurada em Configurações › Personalizar menu.
- **Privacidade reforçada:** Safe Browsing configurável, bloqueio de conteúdo misto inseguro, geolocalização desativada no WebView e bloqueio de acesso universal/arquivo por URLs.
- **Proteção ampliada contra rastreadores:** lista local estendida para pixels, analytics, telemetria e scripts de rastreamento; exceções por site continuam disponíveis.
- **Ícone atualizado** e versão incrementada para `1.3.2` (`versionCode` `20132`).

## Aparência

- 8 temas, fundos em gradiente e papel de parede personalizável.
- Miniaturas das abas são temporárias e mantidas em memória; abas privadas continuam fora da restauração de sessão.

## Downloads

- Escrita progressiva em arquivo temporário; pausa/retomada quando o servidor suporta `Range`.
- Validação estrutural antes de publicar o arquivo no MediaStore.
- HLS sem criptografia: manifesto, variante, segmentos e remux para MP4. Conteúdo protegido/criptografado não é baixado.

## Build

JDK 17, Gradle 8.9, Android Gradle Plugin 8.5.2, Kotlin 1.9.24.

```bash
gradle wrapper --gradle-version 8.9
./gradlew assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`. O workflow do GitHub lê automaticamente `versionName` e `versionCode` de `app/build.gradle.kts` e nomeia o artefato conforme a versão.

## Identificador Android

O `applicationId` permanece `com.fiveml.browser` para preservar compatibilidade com instalações existentes e evitar criar um segundo aplicativo separado. Ele pode ser migrado depois que o identificador desejado for definido.
