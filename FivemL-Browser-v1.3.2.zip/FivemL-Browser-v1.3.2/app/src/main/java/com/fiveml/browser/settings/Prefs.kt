package com.fiveml.browser.settings

import android.content.Context
import android.content.SharedPreferences

class Prefs(context: Context) {
    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("fiveml_prefs", Context.MODE_PRIVATE)

    var searchEngine: String
        get() = sp.getString("search_engine", "google") ?: "google"
        set(v) = sp.edit().putString("search_engine", v).apply()
    var adBlockEnabled: Boolean
        get() = sp.getBoolean("adblock", true)
        set(v) = sp.edit().putBoolean("adblock", v).apply()
    var blockedCount: Long
        get() = sp.getLong("blocked_count", 0)
        set(v) = sp.edit().putLong("blocked_count", v).apply()
    var javascriptEnabled: Boolean
        get() = sp.getBoolean("js", true)
        set(v) = sp.edit().putBoolean("js", v).apply()
    var thirdPartyCookies: Boolean
        get() = sp.getBoolean("third_party_cookies", false)
        set(v) = sp.edit().putBoolean("third_party_cookies", v).apply()
    var desktopMode: Boolean
        get() = sp.getBoolean("desktop", false)
        set(v) = sp.edit().putBoolean("desktop", v).apply()
    var maxParallelDownloads: Int
        get() = sp.getInt("max_parallel", 3)
        set(v) = sp.edit().putInt("max_parallel", v.coerceIn(1, 6)).apply()
    var wifiOnly: Boolean
        get() = sp.getBoolean("wifi_only", false)
        set(v) = sp.edit().putBoolean("wifi_only", v).apply()
    var speedLimitKbps: Int
        get() = sp.getInt("speed_limit", 0)
        set(v) = sp.edit().putInt("speed_limit", v.coerceAtLeast(0)).apply()
    var themeId: String
        get() = sp.getString("theme", "midnight") ?: "midnight"
        set(v) = sp.edit().putString("theme", v).apply()
    var wallpaperPreset: String
        get() = sp.getString("wallpaper_preset", "") ?: ""
        set(v) = sp.edit().putString("wallpaper_preset", v).apply()
    var wallpaperOpacity: Int
        get() = sp.getInt("wallpaper_opacity", 85)
        set(v) = sp.edit().putInt("wallpaper_opacity", v.coerceIn(0, 100)).apply()
    /** Posição do menu principal: top ou bottom. */
    var menuPosition: String
        get() = sp.getString("menu_position", "top") ?: "top"
        set(v) = sp.edit().putString("menu_position", if (v == "bottom") "bottom" else "top").apply()
    var safeBrowsingEnabled: Boolean
        get() = sp.getBoolean("safe_browsing", true)
        set(v) = sp.edit().putBoolean("safe_browsing", v).apply()
    var restoreOnce: Boolean
        get() = sp.getBoolean("restore_once", false)
        set(v) = sp.edit().putBoolean("restore_once", v).apply()
    var homeWallpaper: String?
        get() = sp.getString("wallpaper", null)
        set(v) = sp.edit().putString("wallpaper", v).apply()
    var showSearchHistoryOnHome: Boolean
        get() = sp.getBoolean("home_history", true)
        set(v) = sp.edit().putBoolean("home_history", v).apply()
    var showShortcutsOnHome: Boolean
        get() = sp.getBoolean("home_shortcuts", true)
        set(v) = sp.edit().putBoolean("home_shortcuts", v).apply()
    var restoreTabs: Boolean
        get() = sp.getBoolean("restore_tabs", true)
        set(v) = sp.edit().putBoolean("restore_tabs", v).apply()
    var savedTabs: String
        get() = sp.getString("saved_tabs", "[]") ?: "[]"
        set(v) = sp.edit().putString("saved_tabs", v).apply()
    var filterListUpdatedAt: Long
        get() = sp.getLong("filters_updated", 0)
        set(v) = sp.edit().putLong("filters_updated", v).apply()
    var notificationsAsked: Boolean
        get() = sp.getBoolean("notif_asked", false)
        set(v) = sp.edit().putBoolean("notif_asked", v).apply()

    companion object {
        val ENGINES = linkedMapOf(
            "google" to Pair("Google", "https://www.google.com/search?q="),
            "duckduckgo" to Pair("DuckDuckGo", "https://duckduckgo.com/?q="),
            "bing" to Pair("Bing", "https://www.bing.com/search?q="),
            "brave" to Pair("Brave", "https://search.brave.com/search?q="),
            "ecosia" to Pair("Ecosia", "https://www.ecosia.org/search?q="),
        )
    }
}
