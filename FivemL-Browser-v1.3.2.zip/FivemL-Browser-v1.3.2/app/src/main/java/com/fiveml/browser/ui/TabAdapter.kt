package com.fiveml.browser.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.fiveml.browser.R
import com.fiveml.browser.tabs.Tab
import com.fiveml.browser.util.Urls
import com.google.android.material.card.MaterialCardView

/** Grade visual de abas no estilo de cartões, com miniaturas e estado ativo. */
class TabAdapter(
    private val tabs: List<Tab>,
    private val current: Tab?,
    private val onSelect: (Tab) -> Unit,
    private val onClose: (Tab) -> Unit,
) : RecyclerView.Adapter<TabAdapter.VH>() {
    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val card: MaterialCardView = v.findViewById(R.id.tabCard)
        val preview: ImageView = v.findViewById(R.id.tabPreview)
        val icon: ImageView = v.findViewById(R.id.tabIcon)
        val title: TextView = v.findViewById(R.id.tabTitle)
        val url: TextView = v.findViewById(R.id.tabUrl)
        val index: TextView = v.findViewById(R.id.tabIndex)
        val status: TextView = v.findViewById(R.id.tabStatus)
        val close: ImageButton = v.findViewById(R.id.tabClose)
    }

    override fun getItemCount() = tabs.size
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_tab, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val tab = tabs[position]
        val active = tab === current
        h.title.text = tab.displayTitle("Nova aba")
        h.url.text = when {
            tab.isHome -> "Página inicial"
            tab.isPrivate -> "Privada · ${Urls.displayHost(tab.url)}"
            else -> Urls.displayHost(tab.url)
        }
        h.preview.setImageBitmap(tab.preview)
        h.preview.visibility = if (tab.preview != null) View.VISIBLE else View.INVISIBLE
        h.icon.setImageBitmap(tab.favicon)
        if (tab.favicon == null) h.icon.setImageResource(if (tab.isPrivate) R.drawable.ic_private else R.drawable.ic_globe)
        h.index.text = "${position + 1}"
        h.status.visibility = if (active || tab.isPrivate) View.VISIBLE else View.GONE
        h.status.text = when { active -> "ATIVA"; tab.isPrivate -> "PRIVADA"; else -> "" }
        val context = h.itemView.context
        val accent = UiUtil.attr(context, R.attr.fvAccent)
        val border = UiUtil.attr(context, R.attr.fvBorder)
        h.card.strokeWidth = (if (active) 2 else 1) * context.resources.displayMetrics.density.toInt().coerceAtLeast(1)
        h.card.strokeColor = if (active) accent else border
        h.card.cardElevation = if (active) 5f else 2f
        h.itemView.alpha = if (active) 1f else 0.96f
        h.itemView.setOnClickListener { onSelect(tab) }
        h.close.setOnClickListener { onClose(tab) }
    }
}
