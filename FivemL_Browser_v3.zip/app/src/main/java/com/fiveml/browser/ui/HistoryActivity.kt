package com.fiveml.browser.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.fiveml.browser.R
import com.fiveml.browser.data.db.BrowserDatabase
import com.fiveml.browser.data.db.HistoryEntity
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class HistoryActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private val historyList = mutableListOf<HistoryEntity>()
    private lateinit var adapter: HistoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        recyclerView = findViewById(R.id.recyclerViewHistory)
        recyclerView.layoutManager = LinearLayoutManager(this)
        
        adapter = HistoryAdapter(historyList) { historyItem ->
            // Ao clicar no histórico, pode retornar a URL para a MainActivity
            val resultIntent = intent.putExtra("SELECTED_URL", historyItem.url)
            setResult(RESULT_OK, resultIntent)
            finish()
        }
        recyclerView.adapter = adapter

        loadHistory()
    }

    private fun loadHistory() {
        val dao = BrowserDatabase.getDatabase(this).browserDao()
        lifecycleScope.launch {
            dao.getAllHistory().collectLatest { list ->
                historyList.clear()
                historyList.addAll(list)
                adapter.notifyDataSetChanged()
            }
        }
    }
}

class HistoryAdapter(
    private val items: List<HistoryEntity>,
    private val onClick: (HistoryEntity) -> Unit
) : RecyclerView.Adapter<HistoryAdapter.HistoryViewHolder>() {

    class HistoryViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvTitle: TextView = view.findViewById(R.id.tvTitle)
        val tvUrl: TextView = view.findViewById(R.id.tvUrl)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistoryViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_history, parent, false)
        return HistoryViewHolder(view)
    }

    override fun onBindViewHolder(holder: HistoryViewHolder, position: Int) {
        val item = items[position]
        holder.tvTitle.text = item.title.ifEmpty { item.url }
        holder.tvUrl.text = item.url
        holder.itemView.setOnClickListener { onClick(item) }
    }

    override fun getItemCount(): Int = items.size
}
