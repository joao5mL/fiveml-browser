package com.fiveml.browser.web

import android.graphics.Bitmap
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import com.fiveml.browser.extractors.RegexRules

class SnifferClient(
    private val onVideoDetected: (String) -> Unit,
    private val onTitleChanged: (String, String) -> Unit = { _, _ -> }
) : WebViewClient() {

    override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
        val url = request?.url?.toString() ?: return null
        if (AdBlocker.isAd(url)) return AdBlocker.createEmptyResource()
        if (RegexRules.isVideoUrl(url)) onVideoDetected(url)
        return super.shouldInterceptRequest(view, request)
    }

    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
        val uri = request?.url ?: return false
        val scheme = uri.scheme?.lowercase()
        if (scheme == "http" || scheme == "https") {
            view?.loadUrl(uri.toString())
            return true
        }
        return true
    }

    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
        super.onPageStarted(view, url, favicon)
    }

    override fun onPageFinished(view: WebView?, url: String?) {
        super.onPageFinished(view, url)
        if (view != null && !url.isNullOrBlank()) onTitleChanged(url, view.title.orEmpty())
    }
}
