package com.fiveml.browser.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.fiveml.browser.R
import com.fiveml.browser.data.DownloadItem

class DownloadAdapter(private val downloadList: List<DownloadItem>) :
    RecyclerView.Adapter<DownloadAdapter.DownloadViewHolder>() {

    class DownloadViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvFileName: TextView = itemView.findViewById(R.id.tvFileName)
        val tvStatus: TextView = itemView.findViewById(R.id.tvStatus)
        val progressBar: ProgressBar = itemView.findViewById(R.id.progressBar)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DownloadViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_download, parent, false)
        return DownloadViewHolder(view)
    }

    override fun onBindViewHolder(holder: DownloadViewHolder, position: Int) {
        val item = downloadList[position]
        holder.tvFileName.text = item.fileName
        holder.tvStatus.text = item.status
        holder.progressBar.progress = item.progress
    }

    override fun getItemCount(): Int = downloadList.size
}
