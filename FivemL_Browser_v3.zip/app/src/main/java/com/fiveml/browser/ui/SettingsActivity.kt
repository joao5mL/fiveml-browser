package com.fiveml.browser.ui

import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.Switch
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.fiveml.browser.R

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val toolbar = findViewById<Toolbar>(R.id.toolbarSettings)
        setSupportActionBar(toolbar)
        supportActionBar?.title = "Configurações do Browser"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        val sharedPreferences = getSharedPreferences("browser_prefs", Context.MODE_PRIVATE)
        
        val switchDesktop = findViewById<Switch>(R.id.switchDesktopMode)
        val switchJs = findViewById<Switch>(R.id.switchJavaScript)
        val btnClearCache = findViewById<Button>(R.id.btnClearCache)

        // Carrega estados salvos
        switchDesktop.isChecked = sharedPreferences.getBoolean("desktop_mode", false)
        switchJs.isChecked = sharedPreferences.getBoolean("js_enabled", true)

        // Salva mudanças em tempo real
        switchDesktop.setOnCheckedChangeListener { _, isChecked ->
            sharedPreferences.edit().putBoolean("desktop_mode", isChecked).apply()
            Toast.makeText(this, "Modo Desktop ${if (isChecked) "Ativado" else "Desativado"}", Toast.LENGTH_SHORT).show()
        }

        switchJs.setOnCheckedChangeListener { _, isChecked ->
            sharedPreferences.edit().putBoolean("js_enabled", isChecked).apply()
        }

        btnClearCache.setOnClickListener {
            // Limpa o cache local do app
            cacheDir.deleteRecursively()
            Toast.makeText(this, "Cache limpo com sucesso!", Toast.LENGTH_SHORT).show()
        }
    }
}
