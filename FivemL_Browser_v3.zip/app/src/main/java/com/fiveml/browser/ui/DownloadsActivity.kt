package com.fiveml.browser.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.fiveml.browser.R
import com.fiveml.browser.data.DownloadItem

class DownloadsActivity : AppCompatActivity() {

    private lateinit var recyclerViewDownloads: RecyclerView
    private lateinit var downloadAdapter: DownloadAdapter
    private val downloadList = mutableListOf<DownloadItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_downloads)

        recyclerViewDownloads = findViewById(R.id.recyclerViewDownloads)
        recyclerViewDownloads.layoutManager = LinearLayoutManager(this)

        // Exemplo inicial de item ou lista vazia para gerenciamento
        downloadAdapter = DownloadAdapter(downloadList)
        recyclerViewDownloads.adapter = downloadAdapter
    }
}
