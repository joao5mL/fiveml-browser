package com.fiveml.browser.web

import android.content.Context
import android.util.AttributeSet
import android.webkit.WebSettings
import android.webkit.WebView

data class DetectedMedia(val url: String, val type: String, val quality: String = "Automática")

class SnifferWebView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : WebView(context, attrs, defStyleAttr) {

    var onMediaDetected: ((DetectedMedia) -> Unit)? = null
    var onPageTitleChanged: ((String) -> Unit)? = null

    init {
        settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadsImagesAutomatically = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
            setSupportMultipleWindows(false)
            javaScriptCanOpenWindowsAutomatically = false
        }
        webViewClient = SnifferClient(
            onVideoDetected = { url ->
                val extension = url.substringBefore('?').substringAfterLast('.', "mídia").lowercase()
                post { onMediaDetected?.invoke(DetectedMedia(url, extension)) }
            },
            onTitleChanged = { url, title -> post { onPageTitleChanged?.invoke(title) } }
        )
    }

    fun setSnifferListener(onVideoDetected: (String) -> Unit) {
        onMediaDetected = { media -> onVideoDetected(media.url) }
    }
}
