package com.fiveml.browser.data

data class DownloadItem(
    val id: String,
    val fileName: String,
    val url: String,
    var progress: Int = 0,
    var status: String = "Aguardando..."
)
