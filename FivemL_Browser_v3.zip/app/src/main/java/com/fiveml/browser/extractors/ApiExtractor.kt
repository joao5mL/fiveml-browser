package com.fiveml.browser.extractors

class ApiExtractor : BaseExtractor {

    override fun canExtract(url: String): Boolean {
        // Pode ser expandido para plataformas específicas no futuro (Ex: TikTok/Instagram via API)
        return false
    }

    override suspend fun extract(url: String): String? {
        // Implementação futura para chamadas de API externas de download
        return null
    }
}
