package com.fiveml.browser.tab

import android.webkit.WebView

data class TabItem(
    val id: String = System.currentTimeMillis().toString(),
    var title: String = "Nova Aba",
    var url: String = "about:blank",
    var webView: WebView? = null,
    var favicon: android.graphics.Bitmap? = null
)
