package com.fiveml.browser.web

import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream

object AdBlocker {
    private val blockedAdsDomains = listOf(
        "doubleclick.net",
        "googlesyndication.com",
        "adservice.google.com",
        "facebook.com/tr/",
        "adnxs.com",
        "googletagmanager.com/gtm.js"
    )

    fun isAd(url: String): Boolean {
        val lowerUrl = url.lowercase()
        return blockedAdsDomains.any { lowerUrl.contains(it) }
    }

    fun createEmptyResource(): WebResourceResponse {
        return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream("".byteInputStream()))
    }
}
