package com.fiveml.browser.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.fiveml.browser.R
import com.fiveml.browser.tab.TabItem

class TabsActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: TabsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tabs)

        recyclerView = findViewById(R.id.recyclerViewTabs)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Aqui você integrará com o seu TabManager global/singleton se preferir, 
        // ou receberá os dados por Intent. Por enquanto, configuramos a estrutura visual.
        
        findViewById<View>(R.id.btnAddNewTab).setOnClickListener {
            setResult(RESULT_OK, intent.putExtra("ACTION", "NEW_TAB"))
            finish()
        }
    }
}

class TabsAdapter(
    private val tabs: List<TabItem>,
    private val onTabClick: (Int) -> Unit,
    private val onCloseClick: (Int) -> Unit
) : RecyclerView.Adapter<TabsAdapter.TabViewHolder>() {

    class TabViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvTitle: TextView = view.findViewById(R.id.tvTabTitle)
        val tvUrl: TextView = view.findViewById(R.id.tvTabUrl)
        val btnClose: ImageButton = view.findViewById(R.id.btnCloseTab)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TabViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_tab_card, parent, false)
        return TabViewHolder(view)
    }

    override fun onBindViewHolder(holder: TabViewHolder, position: Int) {
        val tab = tabs[position]
        holder.tvTitle.text = tab.title
        holder.tvUrl.text = tab.url
        
        holder.itemView.setOnClickListener { onTabClick(position) }
        holder.btnClose.setOnClickListener { onCloseClick(position) }
    }

    override fun getItemCount(): Int = tabs.size
}
