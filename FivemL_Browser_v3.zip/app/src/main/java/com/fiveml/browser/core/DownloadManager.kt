package com.fiveml.browser.core

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream

class DownloadManager(private val context: Context) {
    private val client = OkHttpClient()

    suspend fun downloadFile(url: String, fileName: String, onProgress: (Int) -> Unit): Boolean =
        withContext(Dispatchers.IO) {
            var insertedUri: android.net.Uri? = null
            try {
                val request = Request.Builder().url(url).header("User-Agent", "Mozilla/5.0").build()
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) return@withContext false
                    val body = response.body ?: return@withContext false
                    val safeName = fileName.substringAfterLast('/').substringAfterLast('\\')
                        .replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "download.bin" }
                    val contentType = body.contentType()?.toString() ?: "application/octet-stream"
                    val output = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val values = ContentValues().apply {
                            put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                            put(MediaStore.Downloads.MIME_TYPE, contentType)
                            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/FivemL Browser")
                            put(MediaStore.Downloads.IS_PENDING, 1)
                        }
                        insertedUri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                            ?: return@withContext false
                        context.contentResolver.openOutputStream(insertedUri!!, "w")
                            ?: return@withContext false
                    } else {
                        val directory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                        if (!directory.exists()) directory.mkdirs()
                        FileOutputStream(File(directory, safeName))
                    }

                    output.use { stream ->
                        body.byteStream().use { input ->
                            val buffer = ByteArray(16 * 1024)
                            var copied = 0L
                            val total = body.contentLength()
                            while (true) {
                                val count = input.read(buffer)
                                if (count < 0) break
                                stream.write(buffer, 0, count)
                                copied += count
                                if (total > 0L) onProgress(((copied * 100) / total).toInt().coerceIn(0, 100))
                            }
                            stream.flush()
                        }
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val completed = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
                        context.contentResolver.update(insertedUri!!, completed, null, null)
                    }
                    true
                }
            } catch (exception: Exception) {
                insertedUri?.let { runCatching { context.contentResolver.delete(it, null, null) } }
                exception.printStackTrace()
                false
            }
        }
}
