package com.fiveml.browser.extractors

interface BaseExtractor {
    fun canExtract(url: String): Boolean
    suspend fun extract(url: String): String? // Retorna a URL direta do vídeo pronta para download
}
