package com.fiveml.browser.extractors

object RegexRules {
    // Padrões de extensão ou termos comuns em URLs de streaming e arquivos de vídeo diretos
    private val videoPatterns = listOf(
        ".mp4",
        ".m3u8",
        ".ts",
        ".webm",
        ".m4v",
        "googlevideo.com/videoplayback", // Vídeos diretos do YouTube/Google
        "mime=video"
    )

    fun isVideoUrl(url: String): Boolean {
        val lowerUrl = url.lowercase()
        return videoPatterns.any { lowerUrl.contains(it) }
    }
}
