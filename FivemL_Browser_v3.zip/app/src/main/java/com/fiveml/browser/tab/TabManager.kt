package com.fiveml.browser.tab

class TabManager {
    private val tabs = mutableListOf<TabItem>()
    private var currentTabIndex = -1

    fun getTabs(): List<TabItem> = tabs

    fun getCurrentTab(): TabItem? {
        return if (currentTabIndex in tabs.indices) tabs[currentTabIndex] else null
    }

    fun addTab(tab: TabItem): Int {
        tabs.add(tab)
        currentTabIndex = tabs.size - 1
        return currentTabIndex
    }

    fun removeTab(index: Int): TabItem? {
        if (index !in tabs.indices) return null
        
        val removed = tabs.removeAt(index)
        
        // Ajusta o índice atual após remoção
        if (tabs.isEmpty()) {
            currentTabIndex = -1
        } else if (currentTabIndex >= tabs.size) {
            currentTabIndex = tabs.size - 1
        }
        return removed
    }

    fun switchTab(index: Int): TabItem? {
        if (index in tabs.indices) {
            currentTabIndex = index
            return getCurrentTab()
        }
        return null
    }

    fun getTabCount(): Int = tabs.size
}
