package com.fiveml.browser.extractors

class DirectLinkExtractor : BaseExtractor {

    override fun canExtract(url: String): Boolean {
        return RegexRules.isVideoUrl(url)
    }

    override suspend fun extract(url: String): String? {
        // Se já for uma URL direta de vídeo, retorna ela mesma para download
        return if (canExtract(url)) url else null
    }
}
