# FivemL Browser — GitHub Actions build (Fixed v3)

This package keeps the Android app source and updates the Android build toolchain to a mutually compatible set:

- Android Gradle Plugin 8.5.2
- Gradle 8.7
- Kotlin 1.9.24
- KSP 1.9.24-1.0.20
- Java 17
- Room 2.6.1

## Build

Push the project files to the repository root (or upload this ZIP and use the included workflow). Run **Criar APK de depuração** under GitHub Actions. The workflow locates the Android project, runs `:app:assembleDebug`, and uploads `app-debug.apk` as an artifact.

The build has not been executed in this environment; the GitHub Actions result is still needed to verify compilation end-to-end.
