package com.fiveml.browser.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.fiveml.browser.R
import com.fiveml.browser.service.DownloadService
import com.fiveml.browser.web.SnifferWebView

class MainActivity : AppCompatActivity() {

    private lateinit var webView: SnifferWebView
    private lateinit var etUrl: EditText
    private lateinit var btnGo: Button
    private lateinit var btnDownload: Button
    private lateinit var btnViewDownloads: Button

    private var detectedVideoUrl: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        etUrl = findViewById(R.id.etUrl)
        btnGo = findViewById(R.id.btnGo)
        btnDownload = findViewById(R.id.btnDownload)
        btnViewDownloads = findViewById(R.id.btnViewDownloads)

        // Configura o Sniffer para capturar vídeos ao navegar
        webView.setSnifferListener { videoUrl ->
            detectedVideoUrl = videoUrl
            runOnUiThread {
                btnDownload.isEnabled = true
                Toast.makeText(this, "Vídeo detectado!", Toast.LENGTH_SHORT).show()
            }
        }

        // Carrega página inicial padrão
        webView.loadUrl("https://www.google.com")

        btnGo.setOnClickListener {
            var url = etUrl.text.toString().trim()
            if (url.isNotEmpty()) {
                if (!url.startsWith("http://") && !url.startsWith("https://")) {
                    url = "https://$url"
                }
                webView.loadUrl(url)
            }
        }

        btnDownload.setOnClickListener {
            detectedVideoUrl?.let { url ->
                val intent = Intent(this, DownloadService::class.java).apply {
                    putExtra(DownloadService.EXTRA_URL, url)
                    putExtra(DownloadService.EXTRA_FILENAME, "video_${System.currentTimeMillis()}.mp4")
                }
                startService(intent)
                Toast.makeText(this, "Download iniciado em segundo plano...", Toast.LENGTH_SHORT).show()
            }
        }

        btnViewDownloads.setOnClickListener {
            val intent = Intent(this, DownloadsActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
