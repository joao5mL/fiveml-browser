package com.fiveml.browser

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.fiveml.browser.data.db.BrowserDatabase
import com.fiveml.browser.data.db.HistoryEntity
import com.fiveml.browser.extractors.MediaSniffer
import com.fiveml.browser.ui.HistoryActivity
import com.fiveml.browser.ui.SettingsActivity
import com.fiveml.browser.ui.TabsActivity
import com.fiveml.browser.web.SnifferWebView
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var etUrl: EditText
    private lateinit var webViewContainer: FrameLayout
    private lateinit var layoutMediaSniffer: LinearLayout
    private lateinit var tvMediaDetected: TextView
    private lateinit var btnDownloadMedia: Button

    private var currentWebView: SnifferWebView? = null
    private var detectedMediaUrl: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etUrl = findViewById(R.id.etUrl)
        webViewContainer = findViewById(R.id.webViewContainer)
        layoutMediaSniffer = findViewById(R.id.layoutMediaSniffer)
        tvMediaDetected = findViewById(R.id.tvMediaDetected)
        btnDownloadMedia = findViewById(R.id.btnDownloadMedia)

        setupWebView()
        setupListeners()

        // Carrega página inicial padrão
        loadUrl("https://www.google.com")
    }

    private fun setupWebView() {
        currentWebView = SnifferWebView(this)
        
        // Aplica preferências salvas (Modo Desktop / JS)
        val prefs = getSharedPreferences("browser_prefs", Context.MODE_PRIVATE)
        val isDesktop = prefs.getBoolean("desktop_mode", false)
        val isJsEnabled = prefs.getBoolean("js_enabled", true)

        currentWebView?.settings?.javaScriptEnabled = isJsEnabled
        if (isDesktop) {
            currentWebView?.settings?.userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        }

        // Callbacks do Sniffer e da Página
        currentWebView?.onMediaDetected = { media ->
            detectedMediaUrl = media.url
            layoutMediaSniffer.visibility = LinearLayout.VISIBLE
            tvMediaDetected.text = "Vídeo detectado (${media.quality}): ${media.type}"
        }

        currentWebView?.onPageTitleChanged = { title ->
            saveToHistory(currentWebView?.url ?: "", title)
        }

        webViewContainer.removeAllViews()
        webViewContainer.addView(currentWebView)
    }

    private fun setupListeners() {
        etUrl.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) {
                var input = etUrl.text.toString().trim()
                if (!input.startsWith("http://") && !input.startsWith("https://")) {
                    input = if (input.contains(".") && !input.contains(" ")) {
                        "https://$input"
                    } else {
                        "https://www.google.com/search?q=${java.net.URLEncoder.encode(input, "UTF-8")}"
                    }
                }
                loadUrl(input)
                true
            } else {
                false
            }
        }

        findViewById<ImageButton>(R.id.btnTabs).setOnClickListener {
            val intent = Intent(this, TabsActivity::class.java)
            startActivity(intent)
        }

        findViewById<ImageButton>(R.id.btnMenu).setOnClickListener {
            val intent = Intent(this, SettingsActivity::class.java)
            startActivity(intent)
        }

        btnDownloadMedia.setOnClickListener {
            detectedMediaUrl?.let { url ->
                Toast.makeText(this, "Link de vídeo copiado / Capturando...", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadUrl(url: String) {
        etUrl.setText(url)
        layoutMediaSniffer.visibility = LinearLayout.GONE
        detectedMediaUrl = null
        currentWebView?.loadUrl(url)
    }

    private fun saveToHistory(url: String, title: String) {
        if (url.isBlank() || url == "about:blank") return
        val dao = BrowserDatabase.getDatabase(this).browserDao()
        lifecycleScope.launch {
            dao.insertHistory(HistoryEntity(url = url, title = title))
        }
    }

    override fun onBackPressed() {
        if (currentWebView?.canGoBack() == true) {
            currentWebView?.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
