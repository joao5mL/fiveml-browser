package com.fiveml.browser.web

import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import com.fiveml.browser.extractors.RegexRules

class SnifferClient(private val onVideoDetected: (String) -> Unit) : WebViewClient() {

    override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
        val url = request?.url.toString()

        // 1. Bloqueia anúncios e popups indesejados
        if (AdBlocker.isAd(url)) {
            return AdBlocker.createEmptyResource()
        }

        // 2. Se a URL passar nas regras de vídeo, notifica a Activity
        if (RegexRules.isVideoUrl(url)) {
            onVideoDetected(url)
        }

        return super.shouldInterceptRequest(view, request)
    }

    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
        request?.url?.toString()?.let { view?.loadUrl(it) }
        return true
    }
}
